import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../blocs/app_cubit.dart';
import '../../blocs/entry_cubit.dart';
import '../../blocs/customer_cubit.dart';
import '../../l10n/app_localizations.dart';
import '../../services/ad_service.dart';
import '../../db/models/milk_entry.dart';
import '../../db/dao/customer_dao.dart';
import '../../db/dao/entry_dao.dart';
import 'theme/dairy_theme.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final CustomerDao _customerDao = CustomerDao();
  final EntryDao _entryDao = EntryDao();

  // Today's shift status
  List<MilkEntry> _todayEntries = [];

  @override
  void initState() {
    super.initState();
    // Load home data and customer data on init
    context.read<EntryCubit>().loadHomeData();
    if (context.read<AppCubit>().state.isDoodhwalaMode) {
      context.read<CustomerCubit>().loadCustomers();
    }
    _loadTodayEntries();
  }

  Future<void> _loadTodayEntries() async {
    final today = DateFormat('dd-MM-yyyy').format(DateTime.now());
    final entries = await _entryDao.getEntriesByDate(today);
    if (mounted) {
      setState(() => _todayEntries = entries);
    }
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<AppCubit, AppState>(
      builder: (context, appState) {
        return Scaffold(
          appBar: AppBar(
            title: Text(AppLocalizations.get(context, 'appName')),
            actions: [
              if (appState.isDoodhwalaMode)
                IconButton(
                  icon: const Icon(Icons.people_alt_rounded),
                  tooltip: AppLocalizations.get(context, 'customers'),
                  onPressed: () {
                    Navigator.pushNamed(context, '/customers').then((_) {
                      context.read<EntryCubit>().loadHomeData();
                      context.read<CustomerCubit>().loadCustomers();
                      _loadTodayEntries();
                    });
                  },
                ),
              IconButton(
                icon: const Icon(Icons.analytics_outlined),
                tooltip: AppLocalizations.get(context, 'monthlyReport'),
                onPressed: () {
                  AdService.instance.showInterstitialAd(() {
                    Navigator.pushNamed(context, '/report');
                  });
                },
              ),
              IconButton(
                icon: const Icon(Icons.settings_rounded),
                tooltip: AppLocalizations.get(context, 'settings'),
                onPressed: () {
                  Navigator.pushNamed(context, '/settings').then((_) {
                    context.read<EntryCubit>().loadHomeData();
                    if (appState.isDoodhwalaMode) {
                      context.read<CustomerCubit>().loadCustomers();
                    }
                    _loadTodayEntries();
                  });
                },
              ),
            ],
          ),
          body: BlocBuilder<EntryCubit, EntryState>(
            builder: (context, entryState) {
              if (entryState is EntryLoading) {
                return const Center(child: CircularProgressIndicator());
              }

              List<MilkEntry> recentEntries = [];
              Map<String, double> monthlyTotals = {
                'totalLitres': 0.0,
                'totalAmount': 0.0,
              };

              if (entryState is EntryListLoaded) {
                recentEntries = entryState.entries;
                monthlyTotals = entryState.monthlyTotals;
              }

              return Column(
                children: [
                  Expanded(
                    child: RefreshIndicator(
                      onRefresh: () async {
                        context.read<EntryCubit>().loadHomeData();
                        if (appState.isDoodhwalaMode) {
                          context.read<CustomerCubit>().loadCustomers();
                        }
                        await _loadTodayEntries();
                      },
                      child: ListView(
                        padding: const EdgeInsets.all(16),
                        children: [
                          // 1. "आज" section — today's status
                          _buildTodayCard(context, appState),
                          const SizedBox(height: 14),

                          // 2. Monthly summary — 3-tile grid
                          _buildMonthlySummary(context, monthlyTotals, appState),
                          const SizedBox(height: 14),

                          // 3. Big entry button
                          _buildBigEntryButton(context),
                          const SizedBox(height: 14),

                          // 3.5 Dairy products quick link
                          _buildDairyProductLink(context),
                          const SizedBox(height: 14),

                          // 4. Customer section (दूधवाला mode)
                          if (appState.isDoodhwalaMode) ...[
                            _buildCustomerSection(context),
                            const SizedBox(height: 20),
                          ],

                          // 5. Recent entries
                          _buildRecentEntriesHeader(context),
                          const SizedBox(height: 8),
                          if (recentEntries.isEmpty)
                            _buildEmptyState(context)
                          else
                            _buildRecentEntriesList(context, recentEntries, appState),

                          // Bottom padding for nav bar
                          SizedBox(height: MediaQuery.of(context).padding.bottom + 8),
                        ],
                      ),
                    ),
                  ),
                  AdService.instance.getBannerAdWidget(),
                ],
              );
            },
          ),
        );
      },
    );
  }

  /// "आज" Card — shows today's date + shift status (✅/❌)
  Widget _buildTodayCard(BuildContext context, AppState appState) {
    final now = DateTime.now();
    final dayNames = ['', 'सोमवार', 'मंगलवार', 'बुधवार', 'गुरुवार', 'शुक्रवार', 'शनिवार', 'रविवार'];
    final monthNames = ['', 'जनवरी', 'फ़रवरी', 'मार्च', 'अप्रैल', 'मई', 'जून', 'जुलाई', 'अगस्त', 'सितंबर', 'अक्टूबर', 'नवंबर', 'दिसंबर'];
    final dateStr = '${now.day} ${monthNames[now.month]} ${now.year} (${dayNames[now.weekday]})';

    // Check which shifts are done today
    final morningDone = _todayEntries.any((e) => e.shift == 'M');
    final eveningDone = _todayEntries.any((e) => e.shift == 'E');
    final morningEntry = _todayEntries.where((e) => e.shift == 'M').toList();
    final eveningEntry = _todayEntries.where((e) => e.shift == 'E').toList();

    double morningTotal = 0, eveningTotal = 0;
    double morningAmount = 0, eveningAmount = 0;
    for (final e in morningEntry) {
      morningTotal += e.qtyL;
      morningAmount += e.amount;
    }
    for (final e in eveningEntry) {
      eveningTotal += e.qtyL;
      eveningAmount += e.amount;
    }

    final nf = NumberFormat('#,##,##0', 'en_IN');

    return Card(
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.calendar_today_rounded, size: 18, color: DairyTheme.primaryTeal),
                const SizedBox(width: 8),
                Text('📅 आज — $dateStr',
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
              ],
            ),
            const Divider(height: 20),
            // Morning shift
            _buildShiftRow(
              icon: Icons.wb_sunny_rounded,
              color: Colors.orange[700]!,
              label: 'सुबह',
              isDone: morningDone,
              qty: morningTotal,
              amount: morningAmount,
              nf: nf,
            ),
            const SizedBox(height: 8),
            // Evening shift
            _buildShiftRow(
              icon: Icons.nights_stay_rounded,
              color: Colors.indigo[700]!,
              label: 'शाम',
              isDone: eveningDone,
              qty: eveningTotal,
              amount: eveningAmount,
              nf: nf,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildShiftRow({
    required IconData icon,
    required Color color,
    required String label,
    required bool isDone,
    required double qty,
    required double amount,
    required NumberFormat nf,
  }) {
    return Row(
      children: [
        Icon(icon, color: color, size: 20),
        const SizedBox(width: 8),
        Text('$label:', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 15, color: color)),
        const SizedBox(width: 8),
        Expanded(
          child: isDone
              ? Text(
                  '${qty.toStringAsFixed(1)} ली × ₹${(qty > 0 ? amount / qty : 0.0).toStringAsFixed(1)} = ₹${nf.format(amount)}',
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                )
              : Text(
                  '— एंट्री नहीं हुई —',
                  style: TextStyle(color: Colors.grey[500], fontStyle: FontStyle.italic, fontSize: 14),
                ),
        ),
        Icon(
          isDone ? Icons.check_circle_rounded : Icons.cancel_rounded,
          color: isDone ? Colors.green : Colors.red[300],
          size: 22,
        ),
      ],
    );
  }

  /// Monthly summary — 3-tile grid (Issue 3)
  Widget _buildMonthlySummary(BuildContext context, Map<String, double> totals, AppState appState) {
    final nf = NumberFormat('#,##,##0', 'en_IN');
    final litres = totals['totalLitres'] ?? 0.0;
    final amount = totals['totalAmount'] ?? 0.0;

    final monthNames = ['', 'जनवरी', 'फ़रवरी', 'मार्च', 'अप्रैल', 'मई', 'जून', 'जुलाई', 'अगस्त', 'सितंबर', 'अक्टूबर', 'नवंबर', 'दिसंबर'];
    final currentMonthName = monthNames[DateTime.now().month];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 8),
          child: Text(
            '📊 $currentMonthName का हिसाब',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: DairyTheme.primaryTeal),
          ),
        ),
        Row(
          children: [
            _summaryTile(
              icon: Icons.local_drink_rounded,
              color: DairyTheme.milkAccent,
              label: 'कुल दूध',
              value: '${litres.toStringAsFixed(1)} ली',
            ),
            const SizedBox(width: 10),
            _summaryTile(
              icon: Icons.currency_rupee_rounded,
              color: DairyTheme.primaryTeal,
              label: 'कुल ₹',
              value: '₹${nf.format(amount)}',
            ),
            if (appState.isDoodhwalaMode) ...[
              const SizedBox(width: 10),
              BlocBuilder<CustomerCubit, CustomerState>(
                builder: (context, state) {
                  double totalDue = 0;
                  if (state is CustomerListLoaded) {
                    state.dues.values.forEach((d) {
                      if (d > 0) totalDue += d;
                    });
                  }
                  return _summaryTile(
                    icon: Icons.account_balance_wallet_rounded,
                    color: totalDue > 0 ? Colors.red[700]! : Colors.green[700]!,
                    label: 'बकाया',
                    value: '₹${nf.format(totalDue)}',
                  );
                },
              ),
            ],
          ],
        ),
      ],
    );
  }

  Widget _summaryTile({
    required IconData icon,
    required Color color,
    required String label,
    required String value,
  }) {
    return Expanded(
      child: Card(
        elevation: 0,
        color: color.withOpacity(0.08),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 10),
          child: Column(
            children: [
              Icon(icon, color: color, size: 24),
              const SizedBox(height: 6),
              Text(
                value,
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17, color: color),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 2),
              Text(label, style: TextStyle(fontSize: 12, color: Colors.grey[600])),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBigEntryButton(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 65,
      child: ElevatedButton.icon(
        icon: const Icon(Icons.add_circle, size: 28, color: Colors.white),
        label: Text(
          AppLocalizations.get(context, 'todayEntry'),
          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
        onPressed: () {
          Navigator.pushNamed(context, '/entry').then((_) {
            context.read<EntryCubit>().loadHomeData();
            if (context.read<AppCubit>().state.isDoodhwalaMode) {
              context.read<CustomerCubit>().loadCustomers();
            }
            _loadTodayEntries();
          });
        },
      ),
    );
  }

  /// Dairy products quick link card (Issue 6)
  Widget _buildDairyProductLink(BuildContext context) {
    return Card(
      child: InkWell(
        onTap: () => Navigator.pushNamed(context, '/dairy_products'),
        borderRadius: BorderRadius.circular(18),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
          child: Row(
            children: [
              CircleAvatar(
                backgroundColor: DairyTheme.amber.withOpacity(0.15),
                child: const Icon(Icons.set_meal_rounded, color: DairyTheme.amber),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('🧀 डेयरी प्रोडक्ट',
                        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                    Text('खोवा • पनीर • घी • दही — कैल्कुलेटर और हिसाब',
                        style: TextStyle(fontSize: 13, color: Colors.grey[600])),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right_rounded, color: Colors.grey),
            ],
          ),
        ),
      ),
    );
  }

  /// Customer section — full-width vertical cards (Issue 5 — wider)
  Widget _buildCustomerSection(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              '👥 ${AppLocalizations.get(context, 'customers')}',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: DairyTheme.primaryTeal),
            ),
            TextButton.icon(
              icon: const Icon(Icons.people_alt_rounded, size: 18),
              label: const Text('सभी देखें'),
              onPressed: () {
                Navigator.pushNamed(context, '/customers').then((_) {
                  context.read<CustomerCubit>().loadCustomers();
                  context.read<EntryCubit>().loadHomeData();
                });
              },
            ),
          ],
        ),
        const SizedBox(height: 4),
        BlocBuilder<CustomerCubit, CustomerState>(
          builder: (context, state) {
            if (state is CustomerListLoaded) {
              final list = state.customers;
              if (list.isEmpty) {
                return InkWell(
                  onTap: () => Navigator.pushNamed(context, '/customers').then((_) {
                    context.read<CustomerCubit>().loadCustomers();
                  }),
                  child: Card(
                    child: Padding(
                      padding: const EdgeInsets.all(20),
                      child: Row(
                        children: [
                          Icon(Icons.add_circle_outline, color: DairyTheme.primaryTeal),
                          const SizedBox(width: 12),
                          const Text('कोई ग्राहक नहीं। यहाँ से जोड़ें',
                              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                        ],
                      ),
                    ),
                  ),
                );
              }

              // Show top 5 customers with most due
              final sortedList = List.of(list);
              sortedList.sort((a, b) {
                final dueA = (state.dues[a.id] ?? 0.0).abs();
                final dueB = (state.dues[b.id] ?? 0.0).abs();
                return dueB.compareTo(dueA);
              });
              final displayList = sortedList.take(5).toList();
              final nf = NumberFormat('#,##,##0', 'en_IN');

              return Column(
                children: displayList.map((customer) {
                  final due = state.dues[customer.id] ?? 0.0;
                  final isDue = due > 0;
                  final isAdv = due < 0;
                  final dueColor = isDue ? Colors.red[800] : isAdv ? Colors.green[800] : Colors.grey[600];
                  final dueText = isDue
                      ? '₹${nf.format(due.abs())} बाकी'
                      : isAdv
                          ? '₹${nf.format(due.abs())} एडवांस'
                          : '₹0';

                  return Card(
                    margin: const EdgeInsets.symmetric(vertical: 3),
                    child: ListTile(
                      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 2),
                      leading: CircleAvatar(
                        backgroundColor: DairyTheme.milkAccent.withOpacity(0.12),
                        child: Text(
                          customer.name.isNotEmpty ? customer.name[0] : '?',
                          style: const TextStyle(fontWeight: FontWeight.bold, color: DairyTheme.milkAccent),
                        ),
                      ),
                      title: Text(customer.name,
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                      subtitle: Text(
                        '${customer.defaultQtyL.toStringAsFixed(1)} ली/रोज',
                        style: TextStyle(fontSize: 13, color: Colors.grey[600]),
                      ),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: dueColor?.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Text(
                              dueText,
                              style: TextStyle(color: dueColor, fontWeight: FontWeight.bold, fontSize: 13),
                            ),
                          ),
                          if (customer.phone != null && customer.phone!.isNotEmpty) ...[
                            const SizedBox(width: 4),
                            IconButton(
                              icon: Icon(Icons.call_rounded, color: Colors.green[700], size: 20),
                              padding: EdgeInsets.zero,
                              constraints: const BoxConstraints(minWidth: 36, minHeight: 36),
                              onPressed: () async {
                                final uri = Uri.parse('tel:${customer.phone}');
                                if (await canLaunchUrl(uri)) {
                                  await launchUrl(uri);
                                }
                              },
                            ),
                          ],
                        ],
                      ),
                      onTap: () {
                        Navigator.pushNamed(
                          context,
                          '/customer_detail',
                          arguments: customer,
                        ).then((_) {
                          context.read<EntryCubit>().loadHomeData();
                          context.read<CustomerCubit>().loadCustomers();
                        });
                      },
                    ),
                  );
                }).toList(),
              );
            }
            return const SizedBox.shrink();
          },
        ),
      ],
    );
  }

  Widget _buildRecentEntriesHeader(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 4),
      child: Text(
        '📋 ${AppLocalizations.get(context, 'recentEntries')}',
        style: Theme.of(context).textTheme.titleMedium?.copyWith(
              color: Theme.of(context).primaryColor,
              fontWeight: FontWeight.bold,
            ),
      ),
    );
  }

  Widget _buildEmptyState(BuildContext context) {
    return Card(
      elevation: 0,
      color: Colors.grey.shade100,
      child: Padding(
        padding: const EdgeInsets.all(32.0),
        child: Column(
          children: [
            Icon(Icons.history_toggle_off_rounded, size: 48, color: Colors.grey[400]),
            const SizedBox(height: 12),
            Text(
              AppLocalizations.get(context, 'noEntries'),
              style: TextStyle(color: Colors.grey[600], fontSize: 16, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRecentEntriesList(
    BuildContext context,
    List<MilkEntry> entries,
    AppState appState,
  ) {
    final nf = NumberFormat('#,##,##0', 'en_IN');

    // Group entries by date for timeline feel
    final grouped = <String, List<MilkEntry>>{};
    for (final entry in entries) {
      grouped.putIfAbsent(entry.date, () => []).add(entry);
    }

    return Column(
      children: grouped.entries.map((group) {
        final date = group.key;
        final dateEntries = group.value;
        final today = DateFormat('dd-MM-yyyy').format(DateTime.now());
        final yesterday = DateFormat('dd-MM-yyyy').format(DateTime.now().subtract(const Duration(days: 1)));
        final dateLabel = date == today ? '📅 आज' : date == yesterday ? '📅 कल' : '📅 $date';

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 4, top: 8, bottom: 4),
              child: Text(dateLabel, style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Colors.grey[600])),
            ),
            ...dateEntries.map((entry) {
              final shift = entry.shift == 'M'
                  ? AppLocalizations.get(context, 'morning')
                  : AppLocalizations.get(context, 'evening');
              final shiftIcon = entry.shift == 'M' ? Icons.wb_sunny_rounded : Icons.nights_stay_rounded;
              final shiftColor = entry.shift == 'M' ? Colors.orange[800] : Colors.indigo[800];

              return Dismissible(
                key: ValueKey(entry.id),
                direction: DismissDirection.endToStart,
                background: Container(
                  alignment: Alignment.centerRight,
                  padding: const EdgeInsets.only(right: 20),
                  decoration: BoxDecoration(
                    color: Colors.red[100],
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: const Icon(Icons.delete_forever_rounded, color: Colors.red, size: 28),
                ),
                confirmDismiss: (direction) async {
                  return await _confirmDeleteInline(context, entry);
                },
                child: Card(
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: shiftColor?.withOpacity(0.1),
                      child: Icon(shiftIcon, color: shiftColor),
                    ),
                    title: FutureBuilder<String>(
                      future: _getCustomerName(entry.customerId, appState),
                      builder: (context, snapshot) {
                        return Text(
                          snapshot.data ?? 'किसान खाता',
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
                        );
                      },
                    ),
                    subtitle: Text(
                      '$shift',
                      style: TextStyle(fontSize: 13, color: Colors.grey[600]),
                    ),
                    trailing: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          '${entry.qtyL.toStringAsFixed(1)} ली',
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
                        ),
                        Text(
                          '₹${nf.format(entry.amount)}',
                          style: TextStyle(
                            color: DairyTheme.primaryTeal,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                    onLongPress: () {
                      _showEntryActions(context, entry);
                    },
                  ),
                ),
              );
            }),
          ],
        );
      }).toList(),
    );
  }

  Future<bool?> _confirmDeleteInline(BuildContext context, MilkEntry entry) async {
    return showDialog<bool>(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          title: Text(AppLocalizations.get(context, 'warning')),
          content: const Text('क्या आप इस एंट्री को हमेशा के लिए हटाना चाहते हैं?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: Text(AppLocalizations.get(context, 'no')),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red[700]),
              onPressed: () {
                if (entry.id != null) {
                  context.read<EntryCubit>().deleteEntry(entry.id!);
                }
                Navigator.pop(ctx, true);
              },
              child: Text(AppLocalizations.get(context, 'yes')),
            ),
          ],
        );
      },
    );
  }

  Future<String> _getCustomerName(int? id, AppState appState) async {
    if (id == null || !appState.isDoodhwalaMode) {
      return 'किसान खाता';
    }
    final customers = await _customerDao.getCustomerById(id);
    return customers?.name ?? 'अनजान ग्राहक';
  }

  void _showEntryActions(BuildContext context, MilkEntry entry) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) {
        return SafeArea(
          child: Wrap(
            children: [
              ListTile(
                leading: const Icon(Icons.edit_rounded, color: Colors.blue),
                title: Text(AppLocalizations.get(context, 'edit')),
                onTap: () {
                  Navigator.pop(ctx);
                  Navigator.pushNamed(context, '/entry', arguments: entry).then((_) {
                    context.read<EntryCubit>().loadHomeData();
                    if (context.read<AppCubit>().state.isDoodhwalaMode) {
                      context.read<CustomerCubit>().loadCustomers();
                    }
                    _loadTodayEntries();
                  });
                },
              ),
              ListTile(
                leading: const Icon(Icons.delete_forever_rounded, color: Colors.red),
                title: Text(AppLocalizations.get(context, 'delete')),
                onTap: () {
                  Navigator.pop(ctx);
                  _confirmDelete(context, entry);
                },
              ),
            ],
          ),
        );
      },
    );
  }

  void _confirmDelete(BuildContext context, MilkEntry entry) {
    showDialog(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          title: Text(AppLocalizations.get(context, 'warning')),
          content: const Text('क्या आप इस एंट्री को हमेशा के लिए हटाना चाहते हैं?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: Text(AppLocalizations.get(context, 'no')),
            ),
            ElevatedButton(
              onPressed: () {
                if (entry.id != null) {
                  context.read<EntryCubit>().deleteEntry(entry.id!);
                }
                Navigator.pop(ctx);
              },
              child: Text(AppLocalizations.get(context, 'yes')),
            ),
          ],
        );
      },
    );
  }
}
