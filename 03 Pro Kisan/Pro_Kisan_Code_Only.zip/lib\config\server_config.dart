/// Server configuration for Pro Kisan app.
/// ─────────────────────────────────────────
/// अपने VPS का domain यहाँ डालें:
class ServerConfig {
  /// आपके Hostinger VPS का base URL
  /// उदाहरण: 'https://yourdomain.com' या 'http://123.45.67.89'
  static const String baseUrl = 'https://yourdomain.com';

  /// API endpoints
  static String get sujhavUrl => '$baseUrl/api/sujhav.php';
  static String get noticesUrl => '$baseUrl/api/notices.php';
}
