import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:share_plus/share_plus.dart';
import 'package:in_app_review/in_app_review.dart';
import 'theme/dairy_theme.dart';
import '../l10n/app_localizations.dart';
// ignore_for_file: deprecated_member_use

/// ---------------------------------------------------------------------------
///  About Us — App Info + Developer Details
/// ---------------------------------------------------------------------------
class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  Future<void> _launchUrl(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  Future<void> _sendEmail(BuildContext context) async {
    final isHi = AppLocalizations.isHindiLike(context);
    final subject = isHi ? 'प्रो किसान ऐप — सुझाव' : 'Pro Kisan App — Suggestion';
    final uri = Uri.parse('mailto:all.chandansingh@gmail.com?subject=${Uri.encodeComponent(subject)}');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    }
  }

  @override
  Widget build(BuildContext context) {
    String t(String k) => AppLocalizations.get(context, k);
    final isHi = AppLocalizations.isHindiLike(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(t('moreAbout').replaceAll('ℹ️ ', '')),
        backgroundColor: DairyTheme.primaryTeal,
        foregroundColor: Colors.white,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const SizedBox(height: 10),

            // ── App Icon & Name ──
            Container(
              width: 100,
              height: 100,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [DairyTheme.primaryTeal, DairyTheme.secondaryTeal],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(24),
                boxShadow: [
                  BoxShadow(color: DairyTheme.primaryTeal.withValues(alpha: 0.3), blurRadius: 20, offset: const Offset(0, 8)),
                ],
              ),
              child: const Icon(Icons.agriculture_rounded, size: 50, color: Colors.white),
            ),
            const SizedBox(height: 16),
            Text(t('appName'), style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: DairyTheme.textDark)),
            const SizedBox(height: 4),
            Text(t('aboutVersion'), style: TextStyle(fontSize: 13, color: Colors.grey.shade500)),
            const SizedBox(height: 6),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(
                color: DairyTheme.primaryTeal.withValues(alpha: 0.08),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(t('aboutTagline'), style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: DairyTheme.primaryTeal)),
            ),

            const SizedBox(height: 28),

            // ── App Description ──
            Card(
              elevation: 2,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.info_outline_rounded, color: DairyTheme.primaryTeal, size: 20),
                        const SizedBox(width: 8),
                        Text(t('aboutHeading'), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Text(
                      t('aboutDesc'),
                      style: TextStyle(fontSize: 13, height: 1.5, color: Colors.grey.shade700),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 16),

            // ── Developer Info ──
            Card(
              elevation: 2,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.developer_mode_rounded, color: Colors.deepPurple, size: 20),
                        const SizedBox(width: 8),
                        Text(t('aboutDeveloper'), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                      ],
                    ),
                    const SizedBox(height: 12),

                    // Developer Name
                    ListTile(
                       contentPadding: EdgeInsets.zero,
                      leading: Container(
                        width: 44, height: 44,
                        decoration: BoxDecoration(
                          color: Colors.deepPurple.shade50,
                          shape: BoxShape.circle,
                        ),
                        child: Icon(Icons.person_rounded, color: Colors.deepPurple.shade400),
                      ),
                      title: Text(t('aboutDevName'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                      subtitle: Text(t('aboutDevRole'), style: const TextStyle(fontSize: 12)),
                    ),
                    const Divider(),

                    // Email
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: Container(
                        width: 44, height: 44,
                        decoration: BoxDecoration(
                          color: Colors.blue.shade50,
                          shape: BoxShape.circle,
                        ),
                        child: Icon(Icons.email_rounded, color: Colors.blue.shade400),
                      ),
                      title: const Text('all.chandansingh@gmail.com', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                      subtitle: Text(t('aboutEmailSub'), style: const TextStyle(fontSize: 11)),
                      trailing: const Icon(Icons.open_in_new_rounded, size: 16),
                      onTap: () => _sendEmail(context),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 16),

            // ── Action Buttons ──
            Card(
              elevation: 2,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              child: Column(
                children: [
                  ListTile(
                    leading: const Icon(Icons.star_rounded, color: Colors.amber),
                    title: Text(t('aboutRate'), style: const TextStyle(fontWeight: FontWeight.w600)),
                    subtitle: Text(t('aboutRateSub'), style: const TextStyle(fontSize: 11)),
                    trailing: const Icon(Icons.chevron_right_rounded),
                    onTap: () async {
                      final inAppReview = InAppReview.instance;
                      if (await inAppReview.isAvailable()) {
                        inAppReview.requestReview();
                      }
                    },
                  ),
                  const Divider(height: 0),
                  ListTile(
                    leading: const Icon(Icons.share_rounded, color: Colors.green),
                    title: Text(t('aboutShare'), style: const TextStyle(fontWeight: FontWeight.w600)),
                    subtitle: Text(t('aboutShareSub'), style: const TextStyle(fontSize: 11)),
                    trailing: const Icon(Icons.chevron_right_rounded),
                    onTap: () {
                      final shareMsg = isHi
                          ? '🌾 *प्रो किसान ऐप* डाउनलोड करें!\n\n'
                              '✅ दूध का हिसाब\n'
                              '✅ खाद कैलकुलेटर\n'
                              '✅ मौसम, समाचार, मंडी भाव\n'
                              '✅ सरकारी योजनाएं\n\n'
                              '📲 डाउनलोड करें: https://play.google.com/store/apps/details?id=com.prokisan.app'
                          : '🌾 Download *Pro Kisan App*!\n\n'
                              '✅ Milk Ledger\n'
                              '✅ Fertilizer Calculator\n'
                              '✅ Weather, News, Mandi Rates\n'
                              '✅ Govt Schemes\n\n'
                              '📲 Download: https://play.google.com/store/apps/details?id=com.prokisan.app';
                      Share.share(shareMsg);
                    },
                  ),
                  const Divider(height: 0),
                  ListTile(
                    leading: const Icon(Icons.privacy_tip_rounded, color: Colors.teal),
                    title: const Text('Privacy Policy', style: TextStyle(fontWeight: FontWeight.w600)),
                    trailing: const Icon(Icons.chevron_right_rounded),
                    onTap: () => _launchUrl('https://yourdomain.com/privacy'),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // ── Footer ──
            Text(t('appFooter'), style: TextStyle(fontSize: 11, color: Colors.grey.shade400), textAlign: TextAlign.center),
            const SizedBox(height: 4),
            Text('© 2025 ${t('aboutDevName')}', style: TextStyle(fontSize: 11, color: Colors.grey.shade400)),
            const SizedBox(height: 20),
          ],
        ),
      ),
    ),
  );
}
}
