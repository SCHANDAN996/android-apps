import 'package:flutter/material.dart';
import '../l10n/app_localizations.dart';
import 'theme/dairy_theme.dart';
import 'home_screen.dart';
import 'dashboard_screen.dart';
import 'kheti_screen.dart';
import 'more_screen.dart';
import 'pashu/pashu_screen.dart';

/// Bottom-navigation shell holding the 5 main sections.
class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _index = 0;

  late final List<Widget> _pages = const [
    DashboardScreen(),
    HomeScreen(),
    PashuScreen(),
    KhetiScreen(),
    MoreScreen(),
  ];

  String _t(String k) => AppLocalizations.get(context, k);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // SafeArea bottom: false — NavigationBar handles its own bottom inset.
      // This prevents system nav-bar from overlapping page content.
      body: SafeArea(
        bottom: false,
        child: IndexedStack(index: _index, children: _pages),
      ),
      bottomNavigationBar: SafeArea(
        child: NavigationBar(
          selectedIndex: _index,
          onDestinationSelected: (i) => setState(() => _index = i),
          indicatorColor: DairyTheme.primaryTeal.withValues(alpha: 0.15),
          destinations: [
            NavigationDestination(icon: const Icon(Icons.home_outlined), selectedIcon: const Icon(Icons.home_rounded), label: _t('navHome')),
            NavigationDestination(icon: const Icon(Icons.local_drink_outlined), selectedIcon: const Icon(Icons.local_drink_rounded), label: _t('navMilk')),
            NavigationDestination(icon: const Icon(Icons.pets_outlined), selectedIcon: const Icon(Icons.pets_rounded), label: _t('navPashu')),
            NavigationDestination(icon: const Icon(Icons.grass_outlined), selectedIcon: const Icon(Icons.grass_rounded), label: _t('navKheti')),
            NavigationDestination(icon: const Icon(Icons.menu_rounded), label: _t('navMore')),
          ],
        ),
      ),
    );
  }
}
