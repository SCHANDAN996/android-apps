import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import '../../blocs/app_cubit.dart';
import '../../l10n/app_localizations.dart';
// ignore_for_file: deprecated_member_use

/// ---------------------------------------------------------------------------
///  लाइव मौसम (Weather Screen) — World Class UI/UX Overhaul
/// ---------------------------------------------------------------------------
class WeatherScreen extends StatefulWidget {
  const WeatherScreen({super.key});

  @override
  State<WeatherScreen> createState() => _WeatherScreenState();
}

class _WeatherScreenState extends State<WeatherScreen> with SingleTickerProviderStateMixin {
  bool _isLoading = false;
  String? _errorMessage;
  String _locationName = "";

  // Current weather
  double? _temp;
  double? _windSpeed;
  int? _humidity;
  int? _weatherCode;
  double? _tempMaxToday;
  double? _tempMinToday;

  // Forecast lists
  List<Map<String, dynamic>> _hourlyForecast = [];
  List<Map<String, dynamic>> _forecast = [];

  final _searchCtrl = TextEditingController();
  late AnimationController _animCtrl;

  // ── State Code → Capital Coordinates Fallback ──────────────────────────
  static const Map<String, _StateCoord> _stateCapitals = {
    'UP': _StateCoord('लखनऊ', 'Lucknow', 26.8467, 80.9462),
    'BR': _StateCoord('पटना', 'Patna', 25.5941, 85.1376),
    'MP': _StateCoord('भोपाल', 'Bhopal', 23.2599, 77.4126),
    'RJ': _StateCoord('जयपुर', 'Jaipur', 26.9124, 75.7873),
    'HR': _StateCoord('चंडीगढ़', 'Chandigarh', 30.7333, 76.7794),
    'PB': _StateCoord('चंडीगढ़', 'Chandigarh', 30.7333, 76.7794),
    'UK': _StateCoord('देहरादून', 'Dehradun', 30.3165, 78.0322),
    'HP': _StateCoord('शिमला', 'Shimla', 31.1048, 77.1734),
    'JH': _StateCoord('रांची', 'Ranchi', 23.3441, 85.3096),
    'WB': _StateCoord('कोलकाता', 'Kolkata', 22.5726, 88.3639),
    'GJ': _StateCoord('गांधीनगर', 'Gandhinagar', 23.2156, 72.6369),
    'MH': _StateCoord('मुंबई', 'Mumbai', 19.0760, 72.8777),
    'CG': _StateCoord('रायपुर', 'Raipur', 21.2514, 81.6296),
    'OD': _StateCoord('भुवनेश्वर', 'Bhubaneswar', 20.2961, 85.8245),
    'AS': _StateCoord('गुवाहाटी', 'Guwahati', 26.1445, 91.7362),
    'KA': _StateCoord('बेंगलुरु', 'Bengaluru', 12.9716, 77.5946),
    'AP': _StateCoord('अमरावती', 'Amaravati', 16.5062, 80.6480),
    'TS': _StateCoord('हैदराबाद', 'Hyderabad', 17.3850, 78.4867),
    'TN': _StateCoord('चेन्नई', 'Chennai', 13.0827, 80.2707),
    'KL': _StateCoord('तिरुवनंतपुरम', 'Thiruvananthapuram', 8.5241, 76.9366),
    'GA': _StateCoord('पणजी', 'Panaji', 15.4909, 73.8278),
    'JK': _StateCoord('श्रीनगर', 'Srinagar', 34.0837, 74.7973),
    'DL': _StateCoord('नई दिल्ली', 'New Delhi', 28.6139, 77.2090),
  };

  // ── WMO Code mapping ───────────────────────────────────────────────────
  static const Map<int, Map<String, String>> _wmoDescription = {
    0: {'emoji': '☀️', 'desc': 'साफ आसमान (Clear Sky)'},
    1: {'emoji': '🌤️', 'desc': 'मुख्यतः साफ (Mainly Clear)'},
    2: {'emoji': '⛅', 'desc': 'आंशिक बादल (Partly Cloudy)'},
    3: {'emoji': '☁️', 'desc': 'घने बादल (Overcast)'},
    45: {'emoji': '🌫️', 'desc': 'कोहरा (Fog)'},
    48: {'emoji': '🌫️', 'desc': 'सघन कोहरा (Rime Fog)'},
    51: {'emoji': '🌧️', 'desc': 'हल्की बूंदाबांदी (Light Drizzle)'},
    53: {'emoji': '🌧️', 'desc': 'बूंदाबांदी (Moderate Drizzle)'},
    55: {'emoji': '🌧️', 'desc': 'तेज बूंदाबांदी (Dense Drizzle)'},
    61: {'emoji': '🌧️', 'desc': 'हल्की बारिश (Slight Rain)'},
    63: {'emoji': '🌧️', 'desc': 'बारिश (Moderate Rain)'},
    65: {'emoji': '🌧️', 'desc': 'तेज बारिश (Heavy Rain)'},
    80: {'emoji': '🌦️', 'desc': 'हल्की बौछारें (Slight Showers)'},
    81: {'emoji': '🌦️', 'desc': 'तेज बौछारें (Moderate Showers)'},
    82: {'emoji': '⛈️', 'desc': 'भयानक बौछारें (Violent Showers)'},
    95: {'emoji': '⛈️', 'desc': 'आंधी-तूफान (Thunderstorm)'},
    96: {'emoji': '⛈️', 'desc': 'ओलों के साथ तूफान (Storm with Hail)'},
    99: {'emoji': '⛈️', 'desc': 'भारी ओलों के साथ तूफान (Heavy Storm)'},
  };

  String _t(String k) => AppLocalizations.get(context, k);
  bool get _isHi => AppLocalizations.isHindiLike(context);

  /// WMO desc strings are stored as "हिंदी (English)". Pick the right half.
  Map<String, String> _getWmoInfo(int? code) {
    Map<String, String> raw;
    if (code == null) {
      raw = {'emoji': '🌡️', 'desc': 'मौसम की जानकारी (Weather info)'};
    } else {
      raw = _wmoDescription[code] ??
          (code >= 70 && code <= 77
              ? {'emoji': '❄️', 'desc': 'बर्फबारी (Snowfall)'}
              : {'emoji': '☁️', 'desc': 'बादल छाए हैं (Cloudy)'});
    }
    final full = raw['desc'] ?? '';
    String desc = full;
    final m = RegExp(r'^(.*?)\s*\((.*)\)\s*$').firstMatch(full);
    if (m != null) desc = _isHi ? m.group(1)!.trim() : m.group(2)!.trim();
    return {'emoji': raw['emoji'] ?? '🌡️', 'desc': desc};
  }

  @override
  void initState() {
    super.initState();
    _animCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
    
    // Auto-locate GPS or fallback to user state capital on start
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _autoLocate();
    });
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    _animCtrl.dispose();
    super.dispose();
  }

  // ── Auto location logic ────────────────────────────────────────────────
  Future<void> _autoLocate() async {
    setState(() { _isLoading = true; _errorMessage = null; });
    try {
      // Check if location services enabled
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        _useStateFallback(_isHi ? "GPS बंद है, राज्य अनुसार लोड हो रहा है" : "GPS is off, loading state weather");
        return;
      }

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          _useStateFallback(_isHi ? "लोकेशन अनुमति नहीं मिली, राज्य अनुसार लोड हो रहा है" : "Permission denied, loading state weather");
          return;
        }
      }

      if (permission == LocationPermission.deniedForever) {
        _useStateFallback(_isHi ? "लोकेशन अनुमति बंद है, राज्य अनुसार लोड हो रहा है" : "Location permission disabled, loading state weather");
        return;
      }

      // Safe low-accuracy fetch for weather coordinates
      Position pos = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(accuracy: LocationAccuracy.low),
      );
      final placeName = await _getPlaceNameFromCoords(pos.latitude, pos.longitude);
      await _fetchWeather(pos.latitude, pos.longitude, placeName);
    } catch (_) {
      _useStateFallback(_isHi ? "लोकेशन नहीं मिल सकी, राज्य अनुसार लोड हो रहा है" : "Location not found, loading state weather");
    }
  }

  // Reverse geocoding to convert GPS coordinates into city / district name
  Future<String> _getPlaceNameFromCoords(double lat, double lon) async {
    try {
      final url = Uri.parse(
          'https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=$lat&longitude=$lon&localityLanguage=en');
      final res = await http.get(url).timeout(const Duration(seconds: 4));
      if (res.statusCode == 200) {
        final data = json.decode(res.body);
        final city = (data['city'] != null && data['city'].toString().isNotEmpty)
            ? data['city'].toString()
            : ((data['locality'] != null && data['locality'].toString().isNotEmpty)
                ? data['locality'].toString()
                : data['principalSubdivision']?.toString());
        final state = data['principalSubdivision']?.toString();
        if (city != null && city.isNotEmpty) {
          if (state != null && state.isNotEmpty && city != state) {
            return '$city, $state';
          }
          return city;
        }
      }
    } catch (_) {}

    try {
      final url = Uri.parse(
          'https://nominatim.openstreetmap.org/reverse?lat=$lat&lon=$lon&format=json&accept-language=en');
      final res = await http.get(url, headers: {'User-Agent': 'ProKisanApp/1.0'}).timeout(const Duration(seconds: 4));
      if (res.statusCode == 200) {
        final data = json.decode(res.body);
        final addr = data['address'] as Map?;
        if (addr != null) {
          final place = addr['city'] ?? addr['town'] ?? addr['village'] ?? addr['county'] ?? addr['state_district'];
          final state = addr['state'];
          if (place != null && place.toString().isNotEmpty) {
            if (state != null && state.toString().isNotEmpty && place.toString() != state.toString()) {
              return '${place.toString()}, ${state.toString()}';
            }
            return place.toString();
          }
        }
      }
    } catch (_) {}

    return _t('wCurrentLoc');
  }

  void _useStateFallback(String reason) {
    final stateCode = context.read<AppCubit>().state.stateCode;
    final cap = _stateCapitals[stateCode] ?? _stateCapitals['BR']!; // Default to Patna if fallback fails
    final capName = cap.name(_isHi);
    _fetchWeather(cap.lat, cap.lon, _isHi ? '$capName (राज्य राजधानी)' : '$capName (State Capital)');
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(_isHi ? '🏘️ $reason — $capName का मौसम दिख रहा है' : '🏘️ $reason — Showing weather of $capName'),
        backgroundColor: Colors.blue.shade800,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  // ── Query Coordinates by Search ───────────────────────────────────────
  Future<void> _searchCity() async {
    final query = _searchCtrl.text.trim();
    if (query.isEmpty) return;
    setState(() { _isLoading = true; _errorMessage = null; });
    try {
      final url = Uri.parse(
          "https://geocoding-api.open-meteo.com/v1/search?name=${Uri.encodeComponent(query)}&count=1&language=en&format=json");
      final response = await http.get(url);
      if (response.statusCode != 200) throw Exception(_isHi ? "लोकेशन खोजने में समस्या आई।" : "Problem searching location.");

      final data = json.decode(response.body);
      final results = data['results'] as List?;
      if (results == null || results.isEmpty) {
        throw Exception(_isHi ? "स्थान नहीं मिला। कृपया सही नाम दर्ज करें (जैसे: Gorakhpur, Jaipur)।" : "Location not found. Please enter a valid name (e.g., Gorakhpur, Jaipur).");
      }

      final match = results.first;
      final lat = match['latitude'] as double;
      final lon = match['longitude'] as double;
      String displayName = match['name'] ?? query;
      if (match['admin1'] != null) displayName += ", ${match['admin1']}";

      await _fetchWeather(lat, lon, displayName);
    } catch (e) {
      setState(() {
        _isLoading = false;
        _errorMessage = e.toString().replaceAll("Exception:", "").trim();
      });
    }
  }

  // ── Fetch Weather (Hourly + 10 Days) ──────────────────────────────────
  Future<void> _fetchWeather(double lat, double lon, String name) async {
    setState(() { _isLoading = true; _errorMessage = null; });
    try {
      final url = Uri.parse(
          "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m&hourly=temperature_2m,weather_code&daily=weather_code,temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=10");
      
      final response = await http.get(url).timeout(const Duration(seconds: 15));
      if (response.statusCode != 200) throw Exception("सर्वर से डेटा नहीं मिल सका।");

      final data = json.decode(response.body);
      final current = data['current'];
      final daily = data['daily'];
      final hourly = data['hourly'];

      // Hourly parsing (next 8 hours)
      final List<Map<String, dynamic>> parsedHourly = [];
      final List<dynamic> hTimes = hourly['time'];
      final List<dynamic> hTemps = hourly['temperature_2m'];
      final List<dynamic> hCodes = hourly['weather_code'];
      final nowTime = DateTime.now();

      int hAdded = 0;
      for (int i = 0; i < hTimes.length; i++) {
        final t = DateTime.parse(hTimes[i]);
        if (t.isAfter(nowTime) || t.hour == nowTime.hour) {
          parsedHourly.add({
            'time': DateFormat('h:mm a').format(t),
            'temp': (hTemps[i] as num).toDouble(),
            'code': hCodes[i] as int,
          });
          hAdded++;
          if (hAdded >= 8) break;
        }
      }

      // 10-Day parsing
      final List<Map<String, dynamic>> parsedForecast = [];
      final List<dynamic> dDates = daily['time'];
      final List<dynamic> dCodes = daily['weather_code'];
      final List<dynamic> maxTemps = daily['temperature_2m_max'];
      final List<dynamic> minTemps = daily['temperature_2m_min'];

      for (int i = 0; i < dDates.length; i++) {
        parsedForecast.add({
          'date': DateTime.parse(dDates[i]),
          'code': dCodes[i] as int,
          'max': (maxTemps[i] as num).toDouble(),
          'min': (minTemps[i] as num).toDouble(),
        });
      }

      setState(() {
        _temp = (current['temperature_2m'] as num).toDouble();
        _windSpeed = (current['wind_speed_10m'] as num).toDouble();
        _humidity = current['relative_humidity_2m'] as int;
        _weatherCode = current['weather_code'] as int;

        _tempMaxToday = (maxTemps[0] as num).toDouble();
        _tempMinToday = (minTemps[0] as num).toDouble();

        _hourlyForecast = parsedHourly;
        _forecast = parsedForecast;
        _locationName = name;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
        _errorMessage = _t('wDataError');
      });
    }
  }

  // ── Dynamic Background Gradients ──────────────────────────────────────
  List<Color> _getThemeGradients() {
    if (_weatherCode == null) return [Colors.blue.shade700, Colors.blue.shade400];
    final code = _weatherCode!;

    // Rain / Storm
    if ((code >= 51 && code <= 65) || (code >= 80 && code <= 82) || (code >= 95 && code <= 99)) {
      return [const Color(0xFF1E2640), const Color(0xFF3B486F), const Color(0xFF5A6990)];
    }
    // Cloudy / Overcast / Fog
    if (code == 2 || code == 3 || code == 45 || code == 48) {
      return [const Color(0xFF506880), const Color(0xFF7E97B0), const Color(0xFFB0C4DE)];
    }
    // Sunny / Clear
    return [const Color(0xFFD87815), const Color(0xFFF0A830), const Color(0xFFFBE078)];
  }

  @override
  Widget build(BuildContext context) {
    final themeColors = _getThemeGradients();
    final info = _getWmoInfo(_weatherCode);

    // Weather cautions helper
    final showStormWarning = _forecast.any((f) => f['code'] >= 95 && f['code'] <= 99);

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: themeColors,
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // Search & GPS Bar
              _buildTopSearchBar(),

              Expanded(
                child: _isLoading
                    ? const Center(child: CircularProgressIndicator(color: Colors.white))
                    : _errorMessage != null
                        ? _buildErrorView()
                        : RefreshIndicator(
                            color: themeColors[0],
                            onRefresh: () => _fetchWeather(0, 0, _locationName), // Reloads current screen
                            child: ListView(
                              padding: const EdgeInsets.symmetric(horizontal: 16),
                              children: [
                                const SizedBox(height: 10),
                                
                                // Hero Header Card
                                _buildHeroCard(info),
                                const SizedBox(height: 16),

                                // Warnings
                                if (showStormWarning) _buildStormWarningCard(),

                                // Metrics grid
                                _buildMetricsGrid(),
                                const SizedBox(height: 20),

                                // Hourly forecast
                                _buildHourlyForecastSection(),
                                const SizedBox(height: 20),

                                // 10 Day forecast
                                _build10DaySection(),
                                const SizedBox(height: 24),
                              ],
                            ),
                          ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── Top Search Bar Widget ──────────────────────────────────────────────
  Widget _buildTopSearchBar() {
    return Padding(
      padding: const EdgeInsets.all(12.0),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.arrow_back_rounded, color: Colors.white),
            onPressed: () => Navigator.pop(context),
          ),
          Expanded(
            child: Container(
              height: 46,
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.2),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: Colors.white.withValues(alpha: 0.3)),
              ),
              child: TextField(
                controller: _searchCtrl,
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                decoration: InputDecoration(
                  hintText: _t('wSearchHint'),
                  hintStyle: TextStyle(color: Colors.white.withValues(alpha: 0.7), fontSize: 13),
                  prefixIcon: const Icon(Icons.search_rounded, color: Colors.white70),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(vertical: 8),
                ),
                onSubmitted: (_) => _searchCity(),
              ),
            ),
          ),
          const SizedBox(width: 8),
          Container(
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.2),
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white.withValues(alpha: 0.3)),
            ),
            child: IconButton(
              icon: const Icon(Icons.my_location_rounded, color: Colors.white),
              tooltip: _t('wGpsTooltip'),
              onPressed: _autoLocate,
            ),
          ),
        ],
      ),
    );
  }

  // ── Hero Temperature Card ──────────────────────────────────────────────
  Widget _buildHeroCard(Map<String, String> info) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 16),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: Colors.white.withValues(alpha: 0.2)),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.location_on_rounded, size: 18, color: Colors.white70),
              const SizedBox(width: 6),
              Text(
                _locationName,
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
              ),
            ],
          ),
          const SizedBox(height: 14),

          // Pulsing large weather emoji
          ScaleTransition(
            scale: Tween<double>(begin: 0.95, end: 1.05).animate(
              CurvedAnimation(parent: _animCtrl, curve: Curves.easeInOut),
            ),
            child: Text(
              info['emoji'] ?? '🌤️',
              style: const TextStyle(fontSize: 84),
            ),
          ),
          const SizedBox(height: 10),

          // Temperature
          Text(
            _temp != null ? '${_temp!.toStringAsFixed(0)}°' : '--°',
            style: const TextStyle(fontSize: 68, fontWeight: FontWeight.w900, color: Colors.white, height: 1),
          ),

          // Status Hindi Description
          Text(
            info['desc'] ?? '',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white70),
          ),
          const SizedBox(height: 8),

          // Low / High Temperature limits
          if (_tempMinToday != null && _tempMaxToday != null)
            Text(
              '${_t('wMax')}: ${_tempMaxToday!.toStringAsFixed(0)}°  |  ${_t('wMin')}: ${_tempMinToday!.toStringAsFixed(0)}°',
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Colors.white70),
            ),
        ],
      ),
    );
  }

  // ── Metrics Grid (Humidity, wind, feels like) ─────────────────────────
  Widget _buildMetricsGrid() {
    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisSpacing: 12,
      mainAxisSpacing: 12,
      childAspectRatio: 1.6,
      children: [
        _buildMetricItem(
          icon: Icons.water_drop_rounded,
          color: Colors.blue.shade300,
          label: _t('wHumidity'),
          value: _humidity != null ? '$_humidity%' : '--',
        ),
        _buildMetricItem(
          icon: Icons.air_rounded,
          color: Colors.teal.shade300,
          label: _t('wWind'),
          value: _windSpeed != null ? '${_windSpeed!.toStringAsFixed(1)} km/h' : '--',
        ),
        _buildMetricItem(
          icon: Icons.device_thermostat_rounded,
          color: Colors.orange.shade300,
          label: _t('wFeels'),
          value: _temp != null ? '${(_temp! - 1).toStringAsFixed(0)}°C' : '--',
        ),
        _buildMetricItem(
          icon: Icons.wb_sunny_rounded,
          color: Colors.amber.shade300,
          label: _t('wUV'),
          value: _t('wUVModerate'),
        ),
      ],
    );
  }

  Widget _buildMetricItem({required IconData icon, required Color color, required String label, required String value}) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withValues(alpha: 0.2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Row(
            children: [
              Icon(icon, size: 20, color: color),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  label,
                  style: const TextStyle(fontSize: 11, color: Colors.white70, fontWeight: FontWeight.w600),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            value,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
          ),
        ],
      ),
    );
  }

  // ── Hourly Forecast Horizontal Scroll ──────────────────────────────────
  Widget _buildHourlyForecastSection() {
    if (_hourlyForecast.isEmpty) return const SizedBox.shrink();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          _t('wHourly'),
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.white),
        ),
        const SizedBox(height: 8),
        SizedBox(
          height: 100,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: _hourlyForecast.length,
            itemBuilder: (context, index) {
              final h = _hourlyForecast[index];
              final wInfo = _getWmoInfo(h['code']);
              return Container(
                width: 75,
                margin: const EdgeInsets.only(right: 8),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.white.withValues(alpha: 0.15)),
                ),
                padding: const EdgeInsets.all(8),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(h['time'], style: const TextStyle(fontSize: 10, color: Colors.white70)),
                    const SizedBox(height: 4),
                    Text(wInfo['emoji'] ?? '🌤️', style: const TextStyle(fontSize: 20)),
                    const SizedBox(height: 4),
                    Text('${(h['temp'] as double).toStringAsFixed(0)}°',
                        style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.white)),
                  ],
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  // ── 10-Day Forecast Timeline ───────────────────────────────────────────
  Widget _build10DaySection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          _t('wForecast10'),
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.white),
        ),
        const SizedBox(height: 8),
        ..._forecast.map((f) => _buildForecastRow(f)),
      ],
    );
  }

  Widget _buildForecastRow(Map<String, dynamic> f) {
    final date = f['date'] as DateTime;
    final code = f['code'] as int;
    final min = f['min'] as double;
    final max = f['max'] as double;
    final wInfo = _getWmoInfo(code);

    final dayName = DateFormat('EEEE').format(date);
    final hindiDays = {
      'Monday': 'सोमवार', 'Tuesday': 'मंगलवार', 'Wednesday': 'बुधवार',
      'Thursday': 'गुरुवार', 'Friday': 'शुक्रवार', 'Saturday': 'शनिवार', 'Sunday': 'रविवार'
    };
    final dayLabel = _isHi ? (hindiDays[dayName] ?? dayName) : dayName;
    final isToday = date.day == DateTime.now().day;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withValues(alpha: 0.15)),
      ),
      child: Row(
        children: [
          // Day label
          Expanded(
            flex: 3,
            child: Text(
              isToday ? _t('wToday') : dayLabel,
              style: TextStyle(
                fontWeight: isToday ? FontWeight.bold : FontWeight.w600,
                fontSize: 14,
                color: isToday ? Colors.amber.shade200 : Colors.white,
              ),
            ),
          ),
          
          // Weather emoji
          Expanded(
            flex: 2,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(wInfo['emoji'] ?? '🌤️', style: const TextStyle(fontSize: 20)),
                const SizedBox(width: 4),
              ],
            ),
          ),

          // Temperature range progress visualization bar
          Expanded(
            flex: 4,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text('${min.toStringAsFixed(0)}°', style: const TextStyle(fontSize: 12, color: Colors.white70)),
                const SizedBox(width: 6),
                Expanded(
                  child: Container(
                    height: 4,
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.2),
                      borderRadius: BorderRadius.circular(2),
                    ),
                    alignment: Alignment.center,
                    child: FractionallySizedBox(
                      alignment: Alignment.center,
                      widthFactor: 0.6, // Representative range bar width
                      child: Container(
                        height: 4,
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(colors: [Colors.blue, Colors.orange]),
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 6),
                Text('${max.toStringAsFixed(0)}°', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.white)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── Storm Warning Card ──────────────────────────────────────────────────
  Widget _buildStormWarningCard() {
    return Container(
      padding: const EdgeInsets.all(12),
      margin: const EdgeInsets.only(bottom: 14),
      decoration: BoxDecoration(
        color: Colors.red.shade900.withValues(alpha: 0.7),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.red, width: 1.5),
      ),
      child: Row(
        children: [
          const Icon(Icons.thunderstorm_rounded, color: Colors.amber, size: 24),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(_t('wStormTitle'), style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
                const SizedBox(height: 2),
                Text(_t('wStormBody'), style: const TextStyle(fontSize: 12, color: Colors.white70)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── Error View ─────────────────────────────────────────────────────────
  Widget _buildErrorView() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.cloud_off_rounded, size: 64, color: Colors.white70),
            const SizedBox(height: 12),
            Text(
              _errorMessage!,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
            ),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: _autoLocate,
              icon: const Icon(Icons.refresh_rounded),
              label: Text(_t('tryAgain')),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.white, foregroundColor: Colors.blue.shade900),
            ),
          ],
        ),
      ),
    );
  }
}

// Helper class for state capital coordinates
class _StateCoord {
    final String nameHi, nameEn;
    final double lat, lon;
    const _StateCoord(this.nameHi, this.nameEn, this.lat, this.lon);

    String name(bool isHi) => isHi ? nameHi : nameEn;
}

