import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import '../blocs/dairy_product_cubit.dart';
import '../data/dairy_products.dart';
import '../db/models/dairy_product_entry.dart';
import 'theme/dairy_theme.dart';

/// डेयरी प्रोडक्ट स्क्रीन — Calculator + Ledger mode.
class DairyProductsScreen extends StatefulWidget {
  const DairyProductsScreen({super.key});

  @override
  State<DairyProductsScreen> createState() => _DairyProductsScreenState();
}

class _DairyProductsScreenState extends State<DairyProductsScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    context.read<DairyProductCubit>().loadData();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('🧀 डेयरी प्रोडक्ट'),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: Colors.white,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white70,
          tabs: const [
            Tab(icon: Icon(Icons.calculate_rounded), text: 'कैल्कुलेटर'),
            Tab(icon: Icon(Icons.book_rounded), text: 'हिसाब'),
          ],
        ),
      ),
      body: SafeArea(
        child: TabBarView(
          controller: _tabController,
          children: [
            _CalculatorTab(),
            _LedgerTab(),
          ],
        ),
      ),
    );
  }
}

/// Tab 1: Calculator — "X ली दूध से कितना बनेगा?"
class _CalculatorTab extends StatefulWidget {
  @override
  State<_CalculatorTab> createState() => _CalculatorTabState();
}

class _CalculatorTabState extends State<_CalculatorTab> {
  DairyProduct _selected = kDairyProducts.first;
  final _milkCtrl = TextEditingController();
  double _productQty = 0;
  double _totalAmount = 0;

  @override
  void dispose() {
    _milkCtrl.dispose();
    super.dispose();
  }

  void _calculate() {
    final milk = double.tryParse(_milkCtrl.text.trim()) ?? 0;
    setState(() {
      _productQty = _selected.productFromMilk(milk);
      _totalAmount = _productQty * _selected.defaultPricePerKg;
    });
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Product grid selection
          const Text('प्रोडक्ट चुनें',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 10),
          _buildProductGrid(),
          const SizedBox(height: 16),

          // Selected product info
          _buildProductInfoCard(),
          const SizedBox(height: 16),

          // Milk input
          const Text('🥛 कितना दूध है? (लीटर)',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
          const SizedBox(height: 8),
          TextField(
            controller: _milkCtrl,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(
              hintText: '10',
              suffixText: 'लीटर',
            ),
            onChanged: (_) => _calculate(),
          ),
          const SizedBox(height: 16),

          // Result
          if (_productQty > 0) _buildResultCard(),
          const SizedBox(height: 16),

          // Save entry button
          if (_productQty > 0)
            ElevatedButton.icon(
              icon: const Icon(Icons.save_rounded),
              label: const Text('आज के हिसाब में जोड़ें'),
              onPressed: () => _saveEntry(context),
            ),
        ],
      ),
    );
  }

  Widget _buildProductGrid() {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        childAspectRatio: 1.0,
        crossAxisSpacing: 8,
        mainAxisSpacing: 8,
      ),
      itemCount: kDairyProducts.length,
      itemBuilder: (context, idx) {
        final product = kDairyProducts[idx];
        final isSelected = product.id == _selected.id;
        return InkWell(
          onTap: () {
            setState(() => _selected = product);
            _calculate();
          },
          borderRadius: BorderRadius.circular(14),
          child: Container(
            decoration: BoxDecoration(
              color: isSelected
                  ? DairyTheme.primaryTeal.withOpacity(0.12)
                  : Colors.white,
              border: Border.all(
                color: isSelected ? DairyTheme.primaryTeal : Colors.grey.shade300,
                width: isSelected ? 2 : 1,
              ),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(product.icon,
                    size: 28,
                    color: isSelected ? DairyTheme.primaryTeal : Colors.grey[600]),
                const SizedBox(height: 6),
                Text(
                  product.nameHi.split(' ').first, // Short name
                  style: TextStyle(
                    fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
                    fontSize: 13,
                    color: isSelected ? DairyTheme.primaryTeal : Colors.grey[700],
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildProductInfoCard() {
    return Card(
      color: _selected.color.withOpacity(0.08),
      elevation: 0,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(_selected.icon, color: DairyTheme.primaryTeal, size: 24),
                const SizedBox(width: 10),
                Text(_selected.nameHi,
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
              ],
            ),
            const SizedBox(height: 8),
            Text(_selected.descriptionHi,
                style: TextStyle(fontSize: 13, color: Colors.grey[700], height: 1.4)),
            const SizedBox(height: 8),
            Row(
              children: [
                _infoChip('${_selected.milkToProductRatio.toStringAsFixed(0)} ली दूध → 1 kg', Colors.blue),
                const SizedBox(width: 8),
                _infoChip('₹${_selected.defaultPricePerKg.toStringAsFixed(0)}/kg', Colors.green),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _infoChip(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(text,
          style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: color)),
    );
  }

  Widget _buildResultCard() {
    final nf = NumberFormat('#,##,##0', 'en_IN');
    final milkUsed = double.tryParse(_milkCtrl.text.trim()) ?? 0;

    return Card(
      elevation: 3,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const Text('📊 अनुमानित परिणाम',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const Divider(height: 20),
            _resultRow(
              '🥛 दूध',
              '${milkUsed.toStringAsFixed(1)} लीटर',
            ),
            const SizedBox(height: 8),
            _resultRow(
              '${_selected.nameHi}',
              '${_productQty.toStringAsFixed(2)} kg',
              bold: true,
            ),
            const SizedBox(height: 8),
            _resultRow(
              '💰 अनुमानित कीमत',
              '₹${nf.format(_totalAmount)}',
              color: DairyTheme.primaryTeal,
            ),
          ],
        ),
      ),
    );
  }

  Widget _resultRow(String label, String value, {bool bold = false, Color? color}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: const TextStyle(fontSize: 15)),
        Text(value,
            style: TextStyle(
              fontSize: 16,
              fontWeight: bold ? FontWeight.bold : FontWeight.w600,
              color: color ?? Colors.grey[800],
            )),
      ],
    );
  }

  void _saveEntry(BuildContext context) {
    final milk = double.tryParse(_milkCtrl.text.trim()) ?? 0;
    if (milk <= 0) return;

    final entry = DairyProductEntry(
      productId: _selected.id,
      date: DateFormat('dd-MM-yyyy').format(DateTime.now()),
      milkUsedL: milk,
      productQtyKg: _productQty,
      pricePerKg: _selected.defaultPricePerKg,
      totalAmount: _totalAmount,
    );

    context.read<DairyProductCubit>().addEntry(entry);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('✅ ${_selected.nameHi} — ${_productQty.toStringAsFixed(2)} kg जोड़ा गया!'),
        backgroundColor: DairyTheme.primaryTeal,
        duration: const Duration(seconds: 2),
      ),
    );

    _milkCtrl.clear();
    setState(() {
      _productQty = 0;
      _totalAmount = 0;
    });
  }
}

/// Tab 2: Ledger — daily record of products made
class _LedgerTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<DairyProductCubit, DairyProductState>(
      builder: (context, state) {
        if (state is DairyProductLoading) {
          return const Center(child: CircularProgressIndicator());
        }

        if (state is DairyProductLoaded) {
          return RefreshIndicator(
            onRefresh: () => context.read<DairyProductCubit>().loadData(),
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                // Monthly summary
                _buildMonthlySummary(context, state.monthlyTotals),
                const SizedBox(height: 16),

                // Today's entries
                if (state.todayEntries.isNotEmpty) ...[
                  const Text('📅 आज बनाया',
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                  const SizedBox(height: 8),
                  ...state.todayEntries.map((e) => _buildEntryCard(context, e)),
                  const SizedBox(height: 16),
                ],

                // Monthly entries
                const Text('📋 इस महीने का हिसाब',
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                const SizedBox(height: 8),
                if (state.monthlyEntries.isEmpty)
                  Card(
                    elevation: 0,
                    color: Colors.grey.shade100,
                    child: const Padding(
                      padding: EdgeInsets.all(32),
                      child: Text(
                        'इस महीने अभी तक कोई प्रोडक्ट नहीं बनाया।\nकैल्कुलेटर टैब से एंट्री डालें।',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.grey, fontSize: 15),
                      ),
                    ),
                  )
                else
                  ...state.monthlyEntries.map((e) => _buildEntryCard(context, e)),

                SizedBox(height: MediaQuery.of(context).padding.bottom + 16),
              ],
            ),
          );
        }

        return const Center(child: Text('डेटा लोड हो रहा है...'));
      },
    );
  }

  Widget _buildMonthlySummary(BuildContext context, Map<String, double> totals) {
    final nf = NumberFormat('#,##,##0', 'en_IN');
    final milkUsed = totals['totalMilkUsed'] ?? 0.0;
    final productQty = totals['totalProductQty'] ?? 0.0;
    final totalAmount = totals['totalAmount'] ?? 0.0;

    final monthNames = ['', 'जनवरी', 'फ़रवरी', 'मार्च', 'अप्रैल', 'मई', 'जून', 'जुलाई', 'अगस्त', 'सितंबर', 'अक्टूबर', 'नवंबर', 'दिसंबर'];
    final currentMonth = monthNames[DateTime.now().month];

    return Card(
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('📊 $currentMonth का सारांश',
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const Divider(height: 16),
            Row(
              children: [
                _summaryItem('🥛 दूध इस्तेमाल', '${milkUsed.toStringAsFixed(1)} ली'),
                _summaryItem('📦 प्रोडक्ट', '${productQty.toStringAsFixed(1)} kg'),
                _summaryItem('💰 कुल बिक्री', '₹${nf.format(totalAmount)}'),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _summaryItem(String label, String value) {
    return Expanded(
      child: Column(
        children: [
          Text(value,
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16,
                  color: DairyTheme.primaryTeal)),
          const SizedBox(height: 2),
          Text(label, style: TextStyle(fontSize: 11, color: Colors.grey[600]),
              textAlign: TextAlign.center),
        ],
      ),
    );
  }

  Widget _buildEntryCard(BuildContext context, DairyProductEntry entry) {
    final product = getDairyProductById(entry.productId);
    final nf = NumberFormat('#,##,##0', 'en_IN');
    final productName = product?.nameHi ?? entry.productId;
    final icon = product?.icon ?? Icons.category_rounded;

    return Card(
      margin: const EdgeInsets.symmetric(vertical: 4),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: (product?.color ?? Colors.grey).withOpacity(0.15),
          child: Icon(icon, color: DairyTheme.primaryTeal),
        ),
        title: Text(
          '$productName — ${entry.productQtyKg.toStringAsFixed(2)} kg',
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Text(
          '${entry.date} | दूध: ${entry.milkUsedL.toStringAsFixed(1)} ली | ₹${entry.pricePerKg.toStringAsFixed(0)}/kg',
          style: TextStyle(fontSize: 12, color: Colors.grey[600]),
        ),
        trailing: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(
              '₹${nf.format(entry.totalAmount)}',
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15,
                  color: DairyTheme.primaryTeal),
            ),
          ],
        ),
        onLongPress: () {
          showDialog(
            context: context,
            builder: (ctx) => AlertDialog(
              title: const Text('हटाएं?'),
              content: Text('$productName की यह एंट्री हटा दें?'),
              actions: [
                TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('नहीं')),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.red[700]),
                  onPressed: () {
                    if (entry.id != null) {
                      context.read<DairyProductCubit>().deleteEntry(entry.id!);
                    }
                    Navigator.pop(ctx);
                  },
                  child: const Text('हाँ, हटाएं'),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
