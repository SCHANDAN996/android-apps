import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../../data/pashu_calc.dart';
import '../../l10n/app_localizations.dart';
import '../theme/dairy_theme.dart';

class PashuScreen extends StatefulWidget {
  const PashuScreen({super.key});

  @override
  State<PashuScreen> createState() => _PashuScreenState();
}

class _PashuScreenState extends State<PashuScreen> {
  int _tool = 0; // 0 = gaabhin, 1 = aahar

  String _t(String k) => AppLocalizations.get(context, k);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_t('pashuTitle'))),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Expanded(child: _toolChip(0, _t('gaabhinCalc'), Icons.event_rounded)),
                const SizedBox(width: 10),
                Expanded(child: _toolChip(1, _t('aaharCalc'), Icons.restaurant_rounded)),
              ],
            ),
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
              child: _tool == 0 ? const _GaabhinCalc() : const _AaharCalc(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _toolChip(int idx, String label, IconData icon) {
    final sel = _tool == idx;
    return GestureDetector(
      onTap: () => setState(() => _tool = idx),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: sel ? DairyTheme.primaryTeal : Colors.white,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: sel ? DairyTheme.primaryTeal : Colors.grey.shade300),
        ),
        child: Column(
          children: [
            Icon(icon, color: sel ? Colors.white : DairyTheme.primaryTeal),
            const SizedBox(height: 4),
            Text(label,
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                    color: sel ? Colors.white : DairyTheme.textDark)),
          ],
        ),
      ),
    );
  }
}

String _fmtDate(DateTime d) =>
    '${d.day.toString().padLeft(2, '0')}-${d.month.toString().padLeft(2, '0')}-${d.year}';

String _daysFromNow(DateTime d, BuildContext context) {
  final today = DateTime.now();
  final diff = DateTime(d.year, d.month, d.day)
      .difference(DateTime(today.year, today.month, today.day))
      .inDays;
  final hi = Localizations.localeOf(context).languageCode == 'hi';
  if (diff > 0) return hi ? '$diff दिन बाद' : 'in $diff days';
  if (diff == 0) return hi ? 'आज' : 'today';
  return hi ? '${-diff} दिन पहले' : '${-diff} days ago';
}

class _GaabhinCalc extends StatefulWidget {
  const _GaabhinCalc();
  @override
  State<_GaabhinCalc> createState() => _GaabhinCalcState();
}

class _GaabhinCalcState extends State<_GaabhinCalc> {
  bool _isCow = true;
  DateTime? _aiDate;
  PashuMilestones? _result;

  String _t(String k) => AppLocalizations.get(context, k);

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final d = await showDatePicker(
      context: context,
      initialDate: _aiDate ?? now,
      firstDate: DateTime(now.year - 2),
      lastDate: now,
    );
    if (d != null) setState(() => _aiDate = d);
  }

  void _calc() {
    if (_aiDate == null) return;
    setState(() => _result = gaabhinMilestones(_aiDate!, isCow: _isCow));
  }

  void _share() {
    final r = _result;
    if (r == null) return;
    final text = '🐄 ${_t('gaabhinCalc')} — प्रो किसान\n'
        '${_t('animalType')}: ${_isCow ? _t('cow') : _t('buffalo')}\n'
        '${_t('aiDate')}: ${_fmtDate(_aiDate!)}\n'
        '${_t('expectedDelivery')}: ${_fmtDate(r.expectedDelivery)}\n'
        '${_t('pregCheck')}: ${_fmtDate(r.pregnancyCheck)}\n'
        '${_t('dryOff')}: ${_fmtDate(r.dryOff)}';
    Share.share(text);
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const SizedBox(height: 8),
        Text(_t('animalType'), style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(child: _animalBtn(true, _t('cow'), '🐄')),
            const SizedBox(width: 12),
            Expanded(child: _animalBtn(false, _t('buffalo'), '🐃')),
          ],
        ),
        const SizedBox(height: 16),
        OutlinedButton.icon(
          icon: const Icon(Icons.calendar_today_rounded),
          label: Text(_aiDate == null ? _t('selectDate') : '${_t('aiDate')}: ${_fmtDate(_aiDate!)}'),
          onPressed: _pickDate,
          style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 16)),
        ),
        const SizedBox(height: 14),
        ElevatedButton(onPressed: _aiDate == null ? null : _calc, child: Text(_t('calculate'))),
        if (_result != null) ...[
          const SizedBox(height: 20),
          _resultCard(_t('expectedDelivery'), _result!.expectedDelivery, Icons.child_care_rounded, DairyTheme.primaryTeal),
          _resultCard(_t('pregCheck'), _result!.pregnancyCheck, Icons.health_and_safety_rounded, Colors.blue),
          _resultCard(_t('nextHeat'), _result!.nextHeat, Icons.loop_rounded, Colors.orange),
          _resultCard(_t('dryOff'), _result!.dryOff, Icons.no_drinks_rounded, Colors.brown),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            icon: const Icon(Icons.share),
            label: Text(_t('shareText')),
            onPressed: _share,
          ),
        ],
        const SizedBox(height: 16),
        _disclaimer(_t('vetDisclaimer')),
      ],
    );
  }

  Widget _animalBtn(bool cow, String label, String emoji) {
    final sel = _isCow == cow;
    return GestureDetector(
      onTap: () => setState(() => _isCow = cow),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: sel ? DairyTheme.primaryTeal.withValues(alpha: 0.12) : Colors.white,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: sel ? DairyTheme.primaryTeal : Colors.grey.shade300, width: sel ? 2 : 1),
        ),
        child: Column(
          children: [
            Text(emoji, style: const TextStyle(fontSize: 28)),
            const SizedBox(height: 4),
            Text(label, style: const TextStyle(fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }

  Widget _resultCard(String label, DateTime date, IconData icon, Color color) {
    return Card(
      child: ListTile(
        leading: Icon(icon, color: color),
        title: Text(label, style: const TextStyle(fontSize: 14)),
        subtitle: Text(_fmtDate(date), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        trailing: Text(_daysFromNow(date, context),
            style: TextStyle(color: color, fontWeight: FontWeight.w600)),
      ),
    );
  }
}

class _AaharCalc extends StatefulWidget {
  const _AaharCalc();
  @override
  State<_AaharCalc> createState() => _AaharCalcState();
}

class _AaharCalcState extends State<_AaharCalc> {
  final _milkCtrl = TextEditingController();
  bool _latePreg = false;
  double? _dana;

  String _t(String k) => AppLocalizations.get(context, k);

  @override
  void dispose() {
    _milkCtrl.dispose();
    super.dispose();
  }

  void _calc() {
    final milk = double.tryParse(_milkCtrl.text.trim()) ?? 0;
    if (milk <= 0) return;
    setState(() => _dana = aaharDanaKgPerDay(milkLitresPerDay: milk, latePregnancy: _latePreg));
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const SizedBox(height: 8),
        TextField(
          controller: _milkCtrl,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: InputDecoration(labelText: _t('milkPerDay')),
          onChanged: (_) => _calc(),
        ),
        const SizedBox(height: 8),
        CheckboxListTile(
          contentPadding: EdgeInsets.zero,
          value: _latePreg,
          title: Text(_t('latePreg')),
          controlAffinity: ListTileControlAffinity.leading,
          onChanged: (v) {
            setState(() => _latePreg = v ?? false);
            _calc();
          },
        ),
        const SizedBox(height: 8),
        ElevatedButton(onPressed: _calc, child: Text(_t('calculate'))),
        if (_dana != null) ...[
          const SizedBox(height: 20),
          Card(
            color: DairyTheme.primaryTeal,
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  Text(_t('danaResult'), style: const TextStyle(color: Colors.white70, fontSize: 15)),
                  const SizedBox(height: 6),
                  Text('${_dana!.toStringAsFixed(1)} ${_t('kgPerDay')}',
                      style: const TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.bold)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text(_t('fodderNote'), style: Theme.of(context).textTheme.bodySmall),
        ],
        const SizedBox(height: 16),
        _disclaimer(_t('vetDisclaimer')),
      ],
    );
  }
}

Widget _disclaimer(String text) => Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.amber.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          const Icon(Icons.info_outline, size: 18, color: Colors.orange),
          const SizedBox(width: 8),
          Expanded(child: Text(text, style: const TextStyle(fontSize: 12))),
        ],
      ),
    );
