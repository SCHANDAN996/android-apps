import 'package:flutter/material.dart';
import '../l10n/app_localizations.dart';
import 'theme/dairy_theme.dart';
import 'khaad/khaad_screen.dart';

/// खेती tab — खाद-बीज calculator (live) + weather/mandi (coming soon).
class KhetiScreen extends StatelessWidget {
  const KhetiScreen({super.key});

  String _t(BuildContext c, String k) => AppLocalizations.get(c, k);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_t(context, 'navKheti'))),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: ListTile(
              leading: const CircleAvatar(
                backgroundColor: DairyTheme.primaryTeal,
                child: Icon(Icons.grass_rounded, color: Colors.white),
              ),
              title: Text(_t(context, 'khaadTitle'),
                  style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text(_t(context, 'selectCrop')),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(
                  context, MaterialPageRoute(builder: (_) => const KhaadScreen())),
            ),
          ),
          const SizedBox(height: 8),
          Card(
            child: ListTile(
              leading: const CircleAvatar(
                backgroundColor: Colors.orange,
                child: Icon(Icons.wb_sunny_rounded, color: Colors.white),
              ),
              title: Text(_t(context, 'moreWeather'),
                  style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: const Text('लाइव मौसम और 10 दिनों का पूर्वानुमान'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.pushNamed(context, '/weather'),
            ),
          ),
          _soon(context, Icons.trending_up_rounded, _t(context, 'mandiSoon'), Colors.blue),
        ],
      ),
    );
  }

  Widget _soon(BuildContext context, IconData icon, String text, Color color) {
    return Card(
      child: ListTile(
        leading: Icon(icon, color: color),
        title: Text(text, style: const TextStyle(fontSize: 14)),
        trailing: const Icon(Icons.hourglass_empty_rounded, size: 16, color: Colors.grey),
      ),
    );
  }
}
