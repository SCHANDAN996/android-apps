/// Crop fertilizer + seed recommendations.
/// npk = [N, P2O5, K2O] kg per hectare. Source: general ICAR/state-university
/// style recommendations — the app always shows a "verify locally" disclaimer.
class Crop {
  final String id;
  final String hi;
  final String en;
  final List<double> npkMin;  // [N, P, K] kg/ha — minimum dose
  final List<double> npk;     // [N, P, K] kg/ha — recommended dose
  final List<double> npkMax;  // [N, P, K] kg/ha — maximum dose
  final double seedKgHa;
  final String splitsHi;
  final String splitsEn;
  final String season;
  final String seasonEn;

  const Crop({
    required this.id,
    required this.hi,
    required this.en,
    required this.npkMin,
    required this.npk,
    required this.npkMax,
    required this.seedKgHa,
    required this.splitsHi,
    required this.splitsEn,
    required this.season,
    required this.seasonEn,
  });

  /// Localised name: Hindi/Bhojpuri users see [hi], others see [en].
  String name(bool isHindi) => isHindi ? hi : en;
  String splits(bool isHindi) => isHindi ? splitsHi : splitsEn;
  String seasonName(bool isHindi) => isHindi ? season : seasonEn;

  double get n => npk[0];
  double get p => npk[1];
  double get k => npk[2];

  double get nMin => npkMin[0];
  double get pMin => npkMin[1];
  double get kMin => npkMin[2];

  double get nMax => npkMax[0];
  double get pMax => npkMax[1];
  double get kMax => npkMax[2];
}

/// NPK nutrient descriptions in simple Hindi for farmers.
class NutrientInfo {
  final String symbol;
  final String nameHi;
  final String nameEn;
  final String descHi;
  final String descEn;
  final String fertilizer;
  final String emoji;

  const NutrientInfo({
    required this.symbol,
    required this.nameHi,
    required this.nameEn,
    required this.descHi,
    required this.descEn,
    required this.fertilizer,
    required this.emoji,
  });

  String name(bool isHindi) => isHindi ? nameHi : nameEn;
  String desc(bool isHindi) => isHindi ? descHi : descEn;
}

const List<NutrientInfo> kNutrientInfo = [
  NutrientInfo(
    symbol: 'N',
    nameHi: 'नाइट्रोजन',
    nameEn: 'Nitrogen',
    descHi: 'पौधे को हरा-भरा और लंबा बनाता है। पत्तियों का विकास करता है।',
    descEn: 'Makes the plant green and tall. Grows the leaves.',
    fertilizer: 'यूरिया',
    emoji: '🌿',
  ),
  NutrientInfo(
    symbol: 'P',
    nameHi: 'फॉस्फोरस',
    nameEn: 'Phosphorus',
    descHi: 'जड़ें मज़बूत करता है, फूल और बीज बनाता है।',
    descEn: 'Strengthens roots, forms flowers and seeds.',
    fertilizer: 'DAP',
    emoji: '🧪',
  ),
  NutrientInfo(
    symbol: 'K',
    nameHi: 'पोटाश',
    nameEn: 'Potash',
    descHi: 'फल मीठा और बड़ा बनाता है, बीमारी से बचाता है।',
    descEn: 'Makes fruit sweet and big, protects from disease.',
    fertilizer: 'MOP',
    emoji: '🔶',
  ),
];

/// 3-tier dose values: कम से कम (~65-70% of recommended),
/// recommended (ICAR standard), ज्यादा से ज्यादा (~125-130% of recommended).
const String _allBasal = 'पूरा उर्वरक बुवाई के समय।';
const String _allBasalEn = 'Apply all fertilizer at sowing.';

const List<Crop> kCrops = [
  Crop(id: 'wheat', hi: 'गेहूं', en: 'Wheat', npkMin: [80, 40, 25], npk: [120, 60, 40], npkMax: [150, 80, 60], seedKgHa: 100, season: 'रबी', seasonEn: 'Rabi', splitsHi: 'N: आधा बुवाई पर, चौथाई पहली सिंचाई, चौथाई दूसरी सिंचाई। P व K: पूरा बुवाई के समय।', splitsEn: 'N: half at sowing, 1/4 at first irrigation, 1/4 at second. P & K: full at sowing.'),
  Crop(id: 'paddy', hi: 'धान', en: 'Paddy (Rice)', npkMin: [80, 40, 40], npk: [120, 60, 60], npkMax: [150, 80, 80], seedKgHa: 20, season: 'खरीफ', seasonEn: 'Kharif', splitsHi: 'N: तीन बार (रोपाई, कल्ले फूटते, बाली आते)। P व K: पूरा रोपाई पर।', splitsEn: 'N: in 3 splits (transplanting, tillering, panicle). P & K: full at transplanting.'),
  Crop(id: 'maize', hi: 'मक्का', en: 'Maize', npkMin: [80, 40, 25], npk: [120, 60, 40], npkMax: [150, 80, 60], seedKgHa: 20, season: 'खरीफ/रबी', seasonEn: 'Kharif/Rabi', splitsHi: 'N: तीन भाग में। P व K: पूरा बुवाई पर।', splitsEn: 'N: in 3 splits. P & K: full at sowing.'),
  Crop(id: 'mustard', hi: 'सरसों', en: 'Mustard', npkMin: [60, 25, 25], npk: [80, 40, 40], npkMax: [100, 50, 50], seedKgHa: 5, season: 'रबी', seasonEn: 'Rabi', splitsHi: 'N: आधा बुवाई, आधा पहली सिंचाई। P व K: पूरा बुवाई पर।', splitsEn: 'N: half at sowing, half at first irrigation. P & K: full at sowing.'),
  Crop(id: 'potato', hi: 'आलू', en: 'Potato', npkMin: [120, 60, 70], npk: [180, 80, 100], npkMax: [220, 100, 130], seedKgHa: 2500, season: 'रबी', seasonEn: 'Rabi', splitsHi: 'N: आधा बुवाई, आधा मिट्टी चढ़ाते समय। P व K: पूरा बुवाई पर। (बीज = कंद)', splitsEn: 'N: half at sowing, half at earthing-up. P & K: full at sowing. (seed = tubers)'),
  Crop(id: 'gram', hi: 'चना', en: 'Gram (Chickpea)', npkMin: [15, 40, 15], npk: [20, 60, 20], npkMax: [25, 80, 30], seedKgHa: 80, season: 'रबी', seasonEn: 'Rabi', splitsHi: _allBasal, splitsEn: _allBasalEn),
  Crop(id: 'lentil', hi: 'मसूर', en: 'Lentil', npkMin: [15, 30, 15], npk: [20, 40, 20], npkMax: [25, 50, 25], seedKgHa: 45, season: 'रबी', seasonEn: 'Rabi', splitsHi: _allBasal, splitsEn: _allBasalEn),
  Crop(id: 'pigeonpea', hi: 'अरहर', en: 'Pigeon Pea (Arhar)', npkMin: [15, 35, 15], npk: [25, 50, 25], npkMax: [30, 60, 30], seedKgHa: 15, season: 'खरीफ', seasonEn: 'Kharif', splitsHi: _allBasal, splitsEn: _allBasalEn),
  Crop(id: 'sugarcane', hi: 'गन्ना', en: 'Sugarcane', npkMin: [100, 40, 40], npk: [150, 60, 60], npkMax: [200, 80, 80], seedKgHa: 0, season: 'सालभर', seasonEn: 'Year-round', splitsHi: 'N: तीन भाग में। P व K: पूरा बुवाई पर।', splitsEn: 'N: in 3 splits. P & K: full at planting.'),
  Crop(id: 'bajra', hi: 'बाजरा', en: 'Pearl Millet (Bajra)', npkMin: [60, 25, 25], npk: [80, 40, 40], npkMax: [100, 50, 50], seedKgHa: 4, season: 'खरीफ', seasonEn: 'Kharif', splitsHi: 'N: आधा बुवाई, आधा पहली सिंचाई। P व K: पूरा बुवाई पर।', splitsEn: 'N: half at sowing, half at first irrigation. P & K: full at sowing.'),
  Crop(id: 'jowar', hi: 'ज्वार', en: 'Sorghum (Jowar)', npkMin: [60, 25, 25], npk: [80, 40, 40], npkMax: [100, 50, 50], seedKgHa: 8, season: 'खरीफ', seasonEn: 'Kharif', splitsHi: 'N: आधा बुवाई, आधा 30 दिन बाद। P व K: पूरा बुवाई पर।', splitsEn: 'N: half at sowing, half after 30 days. P & K: full at sowing.'),
  Crop(id: 'groundnut', hi: 'मूंगफली', en: 'Groundnut', npkMin: [15, 40, 25], npk: [20, 60, 40], npkMax: [25, 80, 50], seedKgHa: 100, season: 'खरीफ', seasonEn: 'Kharif', splitsHi: _allBasal, splitsEn: _allBasalEn),
  Crop(id: 'soybean', hi: 'सोयाबीन', en: 'Soybean', npkMin: [20, 40, 25], npk: [30, 60, 40], npkMax: [40, 80, 50], seedKgHa: 75, season: 'खरीफ', seasonEn: 'Kharif', splitsHi: _allBasal, splitsEn: _allBasalEn),
  Crop(id: 'onion', hi: 'प्याज', en: 'Onion', npkMin: [70, 35, 35], npk: [100, 50, 50], npkMax: [130, 65, 65], seedKgHa: 8, season: 'रबी', seasonEn: 'Rabi', splitsHi: 'N: तीन भाग में। P व K: पूरा रोपाई पर।', splitsEn: 'N: in 3 splits. P & K: full at transplanting.'),
  Crop(id: 'tomato', hi: 'टमाटर', en: 'Tomato', npkMin: [80, 40, 40], npk: [120, 60, 60], npkMax: [150, 80, 80], seedKgHa: 0.4, season: 'सालभर', seasonEn: 'Year-round', splitsHi: 'N: तीन भाग में। P व K: पूरा रोपाई पर।', splitsEn: 'N: in 3 splits. P & K: full at transplanting.'),

  // ---- 15 new crops (South/East/West India + cash & horticulture) ----
  Crop(id: 'ragi', hi: 'रागी (मंडुआ)', en: 'Finger Millet (Ragi)', npkMin: [40, 20, 20], npk: [50, 30, 25], npkMax: [70, 40, 30], seedKgHa: 10, season: 'खरीफ', seasonEn: 'Kharif', splitsHi: 'N: आधा बुवाई, आधा 25-30 दिन बाद। P व K: पूरा बुवाई पर।', splitsEn: 'N: half at sowing, half after 25-30 days. P & K: full at sowing.'),
  Crop(id: 'barley', hi: 'जौ', en: 'Barley', npkMin: [40, 20, 15], npk: [60, 30, 20], npkMax: [80, 40, 30], seedKgHa: 90, season: 'रबी', seasonEn: 'Rabi', splitsHi: 'N: आधा बुवाई, आधा पहली सिंचाई। P व K: पूरा बुवाई पर।', splitsEn: 'N: half at sowing, half at first irrigation. P & K: full at sowing.'),
  Crop(id: 'moong', hi: 'मूंग', en: 'Green Gram (Moong)', npkMin: [10, 30, 15], npk: [20, 40, 20], npkMax: [25, 50, 25], seedKgHa: 20, season: 'खरीफ/ज़ायद', seasonEn: 'Kharif/Zaid', splitsHi: _allBasal, splitsEn: _allBasalEn),
  Crop(id: 'urad', hi: 'उड़द', en: 'Black Gram (Urad)', npkMin: [10, 30, 15], npk: [20, 40, 20], npkMax: [25, 50, 25], seedKgHa: 20, season: 'खरीफ', seasonEn: 'Kharif', splitsHi: _allBasal, splitsEn: _allBasalEn),
  Crop(id: 'sesame', hi: 'तिल', en: 'Sesame (Til)', npkMin: [30, 15, 15], npk: [40, 20, 20], npkMax: [50, 25, 25], seedKgHa: 5, season: 'खरीफ', seasonEn: 'Kharif', splitsHi: 'N: आधा बुवाई, आधा 30 दिन बाद। P व K: पूरा बुवाई पर।', splitsEn: 'N: half at sowing, half after 30 days. P & K: full at sowing.'),
  Crop(id: 'cotton', hi: 'कपास', en: 'Cotton', npkMin: [80, 30, 30], npk: [120, 60, 60], npkMax: [160, 80, 80], seedKgHa: 15, season: 'खरीफ', seasonEn: 'Kharif', splitsHi: 'N: तीन भाग में (बुवाई, फूल, बॉल)। P व K: पूरा बुवाई पर।', splitsEn: 'N: in 3 splits (sowing, flowering, boll). P & K: full at sowing.'),
  Crop(id: 'turmeric', hi: 'हल्दी', en: 'Turmeric', npkMin: [40, 30, 60], npk: [60, 50, 100], npkMax: [80, 60, 120], seedKgHa: 2000, season: 'खरीफ', seasonEn: 'Kharif', splitsHi: 'N व K: तीन भाग में। P: पूरा रोपाई पर। (बीज = कंद)', splitsEn: 'N & K: in 3 splits. P: full at planting. (seed = rhizomes)'),
  Crop(id: 'ginger', hi: 'अदरक', en: 'Ginger', npkMin: [50, 30, 30], npk: [75, 50, 50], npkMax: [100, 60, 60], seedKgHa: 1500, season: 'खरीफ', seasonEn: 'Kharif', splitsHi: 'N: दो-तीन भाग में। P व K: पूरा रोपाई पर।', splitsEn: 'N: in 2-3 splits. P & K: full at planting.'),
  Crop(id: 'chilli', hi: 'मिर्च', en: 'Chilli', npkMin: [60, 30, 30], npk: [100, 50, 50], npkMax: [120, 60, 60], seedKgHa: 1, season: 'सालभर', seasonEn: 'Year-round', splitsHi: 'N: तीन भाग में। P व K: पूरा रोपाई पर।', splitsEn: 'N: in 3 splits. P & K: full at transplanting.'),
  Crop(id: 'cabbage', hi: 'पत्ता गोभी', en: 'Cabbage', npkMin: [80, 40, 40], npk: [120, 60, 60], npkMax: [150, 80, 80], seedKgHa: 0.5, season: 'रबी', seasonEn: 'Rabi', splitsHi: 'N: दो भाग में। P व K: पूरा रोपाई पर।', splitsEn: 'N: in 2 splits. P & K: full at transplanting.'),
  Crop(id: 'brinjal', hi: 'बैंगन', en: 'Brinjal (Eggplant)', npkMin: [70, 35, 35], npk: [100, 50, 50], npkMax: [130, 60, 60], seedKgHa: 0.4, season: 'सालभर', seasonEn: 'Year-round', splitsHi: 'N: तीन भाग में। P व K: पूरा रोपाई पर।', splitsEn: 'N: in 3 splits. P & K: full at transplanting.'),
  Crop(id: 'okra', hi: 'भिंडी', en: 'Okra (Lady Finger)', npkMin: [40, 20, 20], npk: [60, 30, 30], npkMax: [80, 40, 40], seedKgHa: 8, season: 'ज़ायद/खरीफ', seasonEn: 'Zaid/Kharif', splitsHi: 'N: दो भाग में। P व K: पूरा बुवाई पर।', splitsEn: 'N: in 2 splits. P & K: full at sowing.'),
  Crop(id: 'banana', hi: 'केला', en: 'Banana', npkMin: [150, 60, 200], npk: [200, 100, 300], npkMax: [250, 120, 350], seedKgHa: 0, season: 'सालभर', seasonEn: 'Year-round', splitsHi: 'N व K: कई भागों में (हर महीने)। P: पूरा रोपाई पर।', splitsEn: 'N & K: in many splits (monthly). P: full at planting.'),
  Crop(id: 'coconut', hi: 'नारियल', en: 'Coconut', npkMin: [300, 150, 600], npk: [500, 320, 1200], npkMax: [700, 400, 1400], seedKgHa: 0, season: 'सालभर', seasonEn: 'Year-round', splitsHi: 'प्रति पेड़ साल में दो बार (g/पेड़)। मानसून पूर्व व बाद।', splitsEn: 'Per palm, twice a year (g/palm). Pre- and post-monsoon.'),
  Crop(id: 'blackpepper', hi: 'काली मिर्च', en: 'Black Pepper', npkMin: [50, 25, 100], npk: [100, 40, 140], npkMax: [140, 55, 270], seedKgHa: 0, season: 'सालभर', seasonEn: 'Year-round', splitsHi: 'प्रति बेल दो भागों में (मई व सितंबर)।', splitsEn: 'Per vine in 2 splits (May & September).'),
];

/// Fertilizer bag sizes (kg per bag).
const double kUreaBagKg = 45;
const double kDapBagKg = 50;
const double kMopBagKg = 50;

/// Result of a fertilizer-dose calculation.
class KhaadResult {
  final double ureaKg;
  final double dapKg;
  final double mopKg;
  const KhaadResult(this.ureaKg, this.dapKg, this.mopKg);

  double get ureaBags => ureaKg / kUreaBagKg;
  double get dapBags => dapKg / kDapBagKg;
  double get mopBags => mopKg / kMopBagKg;
}

/// 3-tier result — minimum, recommended, maximum.
class KhaadResult3Tier {
  final KhaadResult min;
  final KhaadResult recommended;
  final KhaadResult max;
  const KhaadResult3Tier(this.min, this.recommended, this.max);
}

/// Compute urea/DAP/MOP for a given N, P2O5, K2O requirement (already scaled to area).
/// DAP supplies P (46%) and some N (18%); urea supplies the remaining N (46%);
/// MOP supplies K (60%).
KhaadResult computeKhaad({required double n, required double p, required double k}) {
  final dap = p / 0.46;
  final nFromDap = dap * 0.18;
  var urea = (n - nFromDap) / 0.46;
  if (urea < 0) urea = 0;
  final mop = k / 0.60;
  return KhaadResult(
    _round05(urea),
    _round05(dap),
    _round05(mop),
  );
}

/// Compute all 3 tiers at once.
KhaadResult3Tier computeKhaad3Tier({
  required Crop crop,
  required double areaHa,
}) {
  return KhaadResult3Tier(
    computeKhaad(n: crop.nMin * areaHa, p: crop.pMin * areaHa, k: crop.kMin * areaHa),
    computeKhaad(n: crop.n * areaHa, p: crop.p * areaHa, k: crop.k * areaHa),
    computeKhaad(n: crop.nMax * areaHa, p: crop.pMax * areaHa, k: crop.kMax * areaHa),
  );
}

double _round05(double v) => (v * 2).round() / 2.0;
