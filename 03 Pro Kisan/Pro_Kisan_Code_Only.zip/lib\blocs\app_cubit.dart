import 'package:flutter_bloc/flutter_bloc.dart';
import '../db/dao/settings_dao.dart';

/// Global app state — holds mode, language, rate configuration, and reminders.
class AppState {
  final String mode; // 'kisan' or 'doodhwala'
  final String language; // 'hi' or 'en'
  final String rateType; // 'flat' or 'fat'
  final double flatRate;
  final double ratePerFatPoint;
  final bool isFirstRun;
  final bool isLoading;
  final String stateCode; // e.g. 'UP'
  final List<String> occupations; // ['dudh','pashu','kheti']

  // Reminder settings — Customizable
  final bool morningReminderEnabled;
  final String morningReminderTime; // format: "HH:mm"
  final bool eveningReminderEnabled;
  final String eveningReminderTime; // format: "HH:mm"

  const AppState({
    this.mode = 'kisan',
    this.language = 'hi',
    this.rateType = 'flat',
    this.flatRate = 60.0,
    this.ratePerFatPoint = 6.8,
    this.isFirstRun = true,
    this.isLoading = true,
    this.stateCode = 'UP',
    this.occupations = const [],
    this.morningReminderEnabled = true,
    this.morningReminderTime = '08:30',
    this.eveningReminderEnabled = true,
    this.eveningReminderTime = '20:30',
  });

  AppState copyWith({
    String? mode,
    String? language,
    String? rateType,
    double? flatRate,
    double? ratePerFatPoint,
    bool? isFirstRun,
    bool? isLoading,
    String? stateCode,
    List<String>? occupations,
    bool? morningReminderEnabled,
    String? morningReminderTime,
    bool? eveningReminderEnabled,
    String? eveningReminderTime,
  }) {
    return AppState(
      mode: mode ?? this.mode,
      language: language ?? this.language,
      rateType: rateType ?? this.rateType,
      flatRate: flatRate ?? this.flatRate,
      ratePerFatPoint: ratePerFatPoint ?? this.ratePerFatPoint,
      isFirstRun: isFirstRun ?? this.isFirstRun,
      isLoading: isLoading ?? this.isLoading,
      stateCode: stateCode ?? this.stateCode,
      occupations: occupations ?? this.occupations,
      morningReminderEnabled: morningReminderEnabled ?? this.morningReminderEnabled,
      morningReminderTime: morningReminderTime ?? this.morningReminderTime,
      eveningReminderEnabled: eveningReminderEnabled ?? this.eveningReminderEnabled,
      eveningReminderTime: eveningReminderTime ?? this.eveningReminderTime,
    );
  }

  bool get isKisanMode => mode == 'kisan';
  bool get isDoodhwalaMode => mode == 'doodhwala';
  bool get isFatBased => rateType == 'fat';
}

/// Cubit that manages global app configuration.
class AppCubit extends Cubit<AppState> {
  final SettingsDao _settingsDao = SettingsDao();

  AppCubit() : super(const AppState());

  /// Load all settings from database on app start.
  Future<void> loadSettings() async {
    try {
      final mode = await _settingsDao.getMode();
      final language = await _settingsDao.getLanguage();
      final rateType = await _settingsDao.getRateType();
      final flatRate = await _settingsDao.getFlatRate();
      final ratePerFatPoint = await _settingsDao.getRatePerFatPoint();
      final isFirstRun = await _settingsDao.isFirstRun();
      final stateCode = await _settingsDao.getStateCode();
      final occupations = await _settingsDao.getOccupations();

      final morningEnabled = await _settingsDao.isMorningReminderEnabled();
      final morningTime = await _settingsDao.getMorningReminderTime();
      final eveningEnabled = await _settingsDao.isEveningReminderEnabled();
      final eveningTime = await _settingsDao.getEveningReminderTime();

      emit(AppState(
        mode: mode,
        language: language,
        rateType: rateType,
        flatRate: flatRate,
        ratePerFatPoint: ratePerFatPoint,
        isFirstRun: isFirstRun,
        isLoading: false,
        stateCode: stateCode,
        occupations: occupations,
        morningReminderEnabled: morningEnabled,
        morningReminderTime: morningTime,
        eveningReminderEnabled: eveningEnabled,
        eveningReminderTime: eveningTime,
      ));
    } catch (_) {
      // Fall back to defaults but STOP loading so the UI can proceed.
      emit(const AppState(isLoading: false, isFirstRun: true));
    }
  }

  /// Set the user's state (राज्य).
  Future<void> setStateCode(String code) async {
    await _settingsDao.setStateCode(code);
    emit(state.copyWith(stateCode: code));
  }

  /// Set the user's occupations (dudh/pashu/kheti).
  Future<void> setOccupations(List<String> occ) async {
    await _settingsDao.setOccupations(occ);
    emit(state.copyWith(occupations: occ));
  }

  /// Switch between किसान and दूधवाला mode.
  Future<void> setMode(String mode) async {
    await _settingsDao.setMode(mode);
    emit(state.copyWith(mode: mode));
  }

  /// Change app language.
  Future<void> setLanguage(String langCode) async {
    await _settingsDao.setLanguage(langCode);
    emit(state.copyWith(language: langCode));
  }

  /// Update flat rate.
  Future<void> setFlatRate(double rate) async {
    await _settingsDao.setFlatRate(rate);
    emit(state.copyWith(flatRate: rate));
  }

  /// Update rate per fat point.
  Future<void> setRatePerFatPoint(double rate) async {
    await _settingsDao.setRatePerFatPoint(rate);
    emit(state.copyWith(ratePerFatPoint: rate));
  }

  /// Switch rate type (flat / fat-based).
  Future<void> setRateType(String type) async {
    await _settingsDao.setRateType(type);
    emit(state.copyWith(rateType: type));
  }

  /// Update morning reminder configuration.
  Future<void> updateMorningReminder({bool? enabled, String? time}) async {
    if (enabled != null) {
      await _settingsDao.setMorningReminderEnabled(enabled);
    }
    if (time != null) {
      await _settingsDao.setMorningReminderTime(time);
    }
    emit(state.copyWith(
      morningReminderEnabled: enabled ?? state.morningReminderEnabled,
      morningReminderTime: time ?? state.morningReminderTime,
    ));
  }

  /// Update evening reminder configuration.
  Future<void> updateEveningReminder({bool? enabled, String? time}) async {
    if (enabled != null) {
      await _settingsDao.setEveningReminderEnabled(enabled);
    }
    if (time != null) {
      await _settingsDao.setEveningReminderTime(time);
    }
    emit(state.copyWith(
      eveningReminderEnabled: enabled ?? state.eveningReminderEnabled,
      eveningReminderTime: time ?? state.eveningReminderTime,
    ));
  }

  /// Mark first run as complete (after mode selection).
  Future<void> completeFirstRun() async {
    await _settingsDao.setFirstRunComplete();
    emit(state.copyWith(isFirstRun: false));
  }
}
