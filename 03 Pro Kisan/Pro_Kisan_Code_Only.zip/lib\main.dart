import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'blocs/app_cubit.dart';
import 'blocs/entry_cubit.dart';
import 'blocs/customer_cubit.dart';
import 'blocs/report_cubit.dart';
import 'blocs/backup_cubit.dart';
import 'blocs/dairy_product_cubit.dart';
import 'db/models/customer.dart';
import 'db/models/milk_entry.dart';
import 'l10n/app_localizations.dart';
import 'services/ad_service.dart';
import 'services/notification_service.dart';
import 'ui/splash_screen.dart';
import 'ui/onboarding_screen.dart';
import 'ui/main_shell.dart';
import 'ui/home_screen.dart';
import 'ui/entry_screen.dart';
import 'ui/customer_screen.dart';
import 'ui/customer_detail_screen.dart';
import 'ui/report_screen.dart';
import 'ui/settings_screen.dart';
import 'ui/dairy_products_screen.dart';
import 'ui/weather_screen.dart';
import 'ui/news_screen.dart';
import 'ui/yojana_screen.dart';
import 'ui/mandi_screen.dart';
import 'ui/sujhav_screen.dart';
import 'ui/about_screen.dart';
import 'ui/helpline_screen.dart';
import 'ui/theme/dairy_theme.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize notification service database/timezone details
  await NotificationService.instance.init();

  // NOTE (diagnostic): Ads init is deliberately deferred out of startup while
  // we confirm the app opens. Ads are re-enabled from the first screen after
  // the UI has loaded, so a native ads issue can never block app launch.
  // AdService.instance.init() is now called lazily (see below).
  _initAdsInBackground();

  runApp(const DudhKaHisabApp());
}

/// Initialise ads AFTER the app has started, on a later frame, fully guarded.
void _initAdsInBackground() {
  WidgetsBinding.instance.addPostFrameCallback((_) async {
    await Future.delayed(const Duration(seconds: 2));
    try {
      await AdService.instance.init();
    } catch (_) {}
  });
}

class DudhKaHisabApp extends StatelessWidget {
  const DudhKaHisabApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider<AppCubit>(
          create: (context) => AppCubit()..loadSettings(),
        ),
        BlocProvider<EntryCubit>(
          create: (context) => EntryCubit(),
        ),
        BlocProvider<CustomerCubit>(
          create: (context) => CustomerCubit(),
        ),
        BlocProvider<ReportCubit>(
          create: (context) => ReportCubit(),
        ),
        BlocProvider<BackupCubit>(
          create: (context) => BackupCubit(),
        ),
        BlocProvider<DairyProductCubit>(
          create: (context) => DairyProductCubit(),
        ),
      ],
      child: BlocBuilder<AppCubit, AppState>(
        builder: (context, state) {
          return MaterialApp(
            title: 'प्रो किसान',
            debugShowCheckedModeBanner: false,
            theme: DairyTheme.lightTheme,
            locale: Locale(state.language),
            supportedLocales: AppLocalizations.supportedLocales,
            localizationsDelegates: const [
              AppLocalizationsDelegate(),
              FallbackMaterialLocalizationsDelegate(),
              FallbackCupertinoLocalizationsDelegate(),
              GlobalMaterialLocalizations.delegate,
              GlobalWidgetsLocalizations.delegate,
              GlobalCupertinoLocalizations.delegate,
            ],
            initialRoute: '/',
            onGenerateRoute: (settings) {
              switch (settings.name) {
                case '/':
                  return MaterialPageRoute(builder: (_) => const SplashScreen());
                case '/onboarding':
                  return MaterialPageRoute(builder: (_) => const OnboardingScreen());
                case '/shell':
                  return MaterialPageRoute(builder: (_) => const MainShell());
                case '/home':
                  return MaterialPageRoute(builder: (_) => const HomeScreen());
                case '/entry':
                  final args = settings.arguments as MilkEntry?;
                  return MaterialPageRoute(builder: (_) => EntryScreen(editEntry: args));
                case '/customers':
                  return MaterialPageRoute(builder: (_) => const CustomerScreen());
                case '/customer_detail':
                  final args = settings.arguments as Customer;
                  return MaterialPageRoute(builder: (_) => CustomerDetailScreen(customer: args));
                case '/report':
                  return MaterialPageRoute(builder: (_) => const ReportScreen());
                case '/settings':
                  return MaterialPageRoute(builder: (_) => const SettingsScreen());
                case '/dairy_products':
                  return MaterialPageRoute(builder: (_) => const DairyProductsScreen());
                case '/weather':
                  return MaterialPageRoute(builder: (_) => const WeatherScreen());
                case '/news':
                  return MaterialPageRoute(builder: (_) => const NewsScreen());
                case '/yojana':
                  return MaterialPageRoute(builder: (_) => const YojanaScreen());
                case '/mandi':
                  return MaterialPageRoute(builder: (_) => const MandiScreen());
                case '/sujhav':
                  return MaterialPageRoute(builder: (_) => const SujhavScreen());
                case '/about':
                  return MaterialPageRoute(builder: (_) => const AboutScreen());
                case '/helpline':
                  return MaterialPageRoute(builder: (_) => const HelplineScreen());
                default:
                  return MaterialPageRoute(builder: (_) => const SplashScreen());
              }
            },
          );
        },
      ),
    );
  }
}
