import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';
import '../blocs/customer_cubit.dart';
import '../db/models/customer.dart';
import '../l10n/app_localizations.dart';
import 'theme/dairy_theme.dart';

/// Launch phone dialer.
Future<void> _launchPhone(String phone) async {
  final uri = Uri.parse('tel:$phone');
  if (await canLaunchUrl(uri)) {
    await launchUrl(uri);
  }
}

/// Open WhatsApp chat.
Future<void> _launchWhatsApp(String phone) async {
  final cleaned = phone.replaceAll(RegExp(r'[^0-9]'), '');
  final number = cleaned.startsWith('91') ? cleaned : '91$cleaned';
  final uri = Uri.parse('https://wa.me/$number');
  if (await canLaunchUrl(uri)) {
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }
}

class CustomerScreen extends StatefulWidget {
  const CustomerScreen({super.key});

  @override
  State<CustomerScreen> createState() => _CustomerScreenState();
}

class _CustomerScreenState extends State<CustomerScreen> {
  String _searchQuery = '';

  @override
  void initState() {
    super.initState();
    context.read<CustomerCubit>().loadCustomers();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(AppLocalizations.get(context, 'customers')),
      ),
      body: SafeArea(
        child: Column(
          children: [
          // Search bar — Issue 5
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'ग्राहक खोजें (नाम / नंबर)',
                prefixIcon: const Icon(Icons.search_rounded),
                filled: true,
                fillColor: Colors.white,
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide(color: Colors.grey.shade300),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide(color: Colors.grey.shade300),
                ),
              ),
              onChanged: (val) => setState(() => _searchQuery = val.trim().toLowerCase()),
            ),
          ),
          Expanded(
            child: BlocBuilder<CustomerCubit, CustomerState>(
              builder: (context, state) {
                if (state is CustomerLoading) {
                  return const Center(child: CircularProgressIndicator());
                }

                if (state is CustomerListLoaded) {
                  var list = state.customers;

                  // Filter by search
                  if (_searchQuery.isNotEmpty) {
                    list = list.where((c) {
                      return c.name.toLowerCase().contains(_searchQuery) ||
                          (c.phone ?? '').contains(_searchQuery);
                    }).toList();
                  }

                  if (list.isEmpty) {
                    return Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.people_outline_rounded, size: 64, color: Colors.grey[400]),
                          const SizedBox(height: 12),
                          Text(
                            _searchQuery.isNotEmpty ? 'कोई ग्राहक नहीं मिला' : 'कोई ग्राहक नहीं है।',
                            style: const TextStyle(fontSize: 18, color: Colors.grey),
                          ),
                          if (_searchQuery.isEmpty) ...[
                            const SizedBox(height: 8),
                            const Text('नीचे + बटन से ग्राहक जोड़ें',
                                style: TextStyle(fontSize: 14, color: Colors.grey)),
                          ],
                        ],
                      ),
                    );
                  }

                  final nf = NumberFormat('#,##,##0', 'en_IN');

                  return ListView.builder(
                    padding: const EdgeInsets.fromLTRB(12, 8, 12, 80),
                    itemCount: list.length,
                    itemBuilder: (context, idx) {
                      final customer = list[idx];
                      final due = state.dues[customer.id] ?? 0.0;
                      return _buildCustomerCard(context, customer, due, nf);
                    },
                  );
                }

                return const SizedBox.shrink();
              },
            ),
          ),
        ],
      ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        icon: const Icon(Icons.person_add_rounded, color: Colors.white),
        label: Text(AppLocalizations.get(context, 'addCustomer'),
            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        backgroundColor: Theme.of(context).primaryColor,
        onPressed: () => _showAddEditSheet(context),
      ),
    );
  }

  /// Full-width rich customer card — Issue 5 redesign
  Widget _buildCustomerCard(
    BuildContext context,
    Customer customer,
    double due,
    NumberFormat nf,
  ) {
    final isDue = due > 0;
    final isAdv = due < 0;
    final dueColor = isDue
        ? Colors.red[800]
        : isAdv
            ? Colors.green[800]
            : Colors.grey[600];
    final dueText = isDue
        ? '₹${nf.format(due.abs())} बाकी'
        : isAdv
            ? '₹${nf.format(due.abs())} एडवांस'
            : 'हिसाब बराबर';
    final hasPhone = customer.phone != null && customer.phone!.isNotEmpty;

    return Card(
      margin: const EdgeInsets.symmetric(vertical: 5),
      child: InkWell(
        onTap: () {
          Navigator.pushNamed(
            context,
            '/customer_detail',
            arguments: customer,
          ).then((_) {
            context.read<CustomerCubit>().loadCustomers();
          });
        },
        borderRadius: BorderRadius.circular(18),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Row 1: Name + Due badge
              Row(
                children: [
                  CircleAvatar(
                    backgroundColor: DairyTheme.primaryTeal.withOpacity(0.12),
                    child: Text(
                      customer.name.isNotEmpty ? customer.name[0].toUpperCase() : '?',
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                        color: DairyTheme.primaryTeal,
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          customer.name,
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                        ),
                        if (hasPhone)
                          Text(
                            customer.phone!,
                            style: TextStyle(fontSize: 14, color: Colors.grey[600]),
                          ),
                        if (customer.address != null && customer.address!.isNotEmpty)
                          Text(
                            '📍 ${customer.address}',
                            style: TextStyle(fontSize: 13, color: Colors.grey[500]),
                          ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: dueColor?.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      dueText,
                      style: TextStyle(
                        color: dueColor,
                        fontWeight: FontWeight.bold,
                        fontSize: 13,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              // Row 2: Rate info
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.grey.shade50,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    Icon(Icons.local_drink_rounded, size: 16, color: DairyTheme.milkAccent),
                    const SizedBox(width: 6),
                    Text(
                      'रोज: ${customer.defaultQtyL.toStringAsFixed(1)} ली',
                      style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(width: 16),
                    Icon(Icons.currency_rupee_rounded, size: 14, color: Colors.grey[600]),
                    Text(
                      customer.rateType == 'flat'
                          ? '₹${customer.flatRate.toStringAsFixed(0)}/ली (फ्लैट)'
                          : '₹${customer.ratePerFatPoint.toStringAsFixed(1)}/फैट (फैट आधारित)',
                      style: TextStyle(fontSize: 13, color: Colors.grey[700]),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 10),
              // Row 3: Action buttons
              Row(
                children: [
                  if (hasPhone) ...[
                    _actionChip(
                      icon: Icons.call_rounded,
                      label: 'कॉल',
                      color: Colors.green[700]!,
                      onTap: () => _makeCall(customer.phone!),
                    ),
                    const SizedBox(width: 8),
                    _actionChip(
                      icon: Icons.message_rounded,
                      label: 'WhatsApp',
                      color: const Color(0xFF25D366),
                      onTap: () => _openWhatsApp(customer.phone!),
                    ),
                    const SizedBox(width: 8),
                  ],
                  _actionChip(
                    icon: Icons.edit_note_rounded,
                    label: 'सुधारें',
                    color: Colors.blue[700]!,
                    onTap: () => _showAddEditSheet(context, customer: customer),
                  ),
                  const Spacer(),
                  _actionChip(
                    icon: Icons.delete_outline_rounded,
                    label: 'हटाएं',
                    color: Colors.red[700]!,
                    onTap: () => _confirmDeactivate(context, customer),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _actionChip({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          border: Border.all(color: color.withOpacity(0.3)),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 16, color: color),
            const SizedBox(width: 4),
            Text(label, style: TextStyle(fontSize: 12, color: color, fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }

  void _makeCall(String phone) async {
    try {
      _launchPhone(phone);
    } catch (_) {}
  }

  void _openWhatsApp(String phone) async {
    try {
      _launchWhatsApp(phone);
    } catch (_) {}
  }

  /// Full-screen bottom sheet for add/edit — Issue 5 (replaces small dialog)
  void _showAddEditSheet(BuildContext context, {Customer? customer}) {
    final nameController = TextEditingController(text: customer?.name ?? '');
    final phoneController = TextEditingController(text: customer?.phone ?? '');
    final addressController = TextEditingController(text: customer?.address ?? '');
    final flatRateController = TextEditingController(text: customer?.flatRate.toString() ?? '60');
    final fatRateController = TextEditingController(text: customer?.ratePerFatPoint.toString() ?? '6.8');
    final qtyController = TextEditingController(text: customer?.defaultQtyL.toString() ?? '1.0');
    String rateType = customer?.rateType ?? 'flat';

    final isEdit = customer != null;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        return StatefulBuilder(
          builder: (context, setStateSheet) {
            return Padding(
              padding: EdgeInsets.only(
                bottom: MediaQuery.of(ctx).viewInsets.bottom,
              ),
              child: Container(
                constraints: BoxConstraints(
                  maxHeight: MediaQuery.of(context).size.height * 0.85,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Handle bar
                    Container(
                      width: 48,
                      height: 5,
                      margin: const EdgeInsets.only(top: 12, bottom: 8),
                      decoration: BoxDecoration(
                        color: Colors.grey.shade300,
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    // Title
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                      child: Row(
                        children: [
                          Icon(
                            isEdit ? Icons.edit_rounded : Icons.person_add_rounded,
                            color: DairyTheme.primaryTeal,
                          ),
                          const SizedBox(width: 10),
                          Text(
                            isEdit ? 'ग्राहक सुधारें' : AppLocalizations.get(context, 'addCustomer'),
                            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                    ),
                    const Divider(),
                    // Form
                    Flexible(
                      child: SingleChildScrollView(
                        padding: const EdgeInsets.fromLTRB(20, 8, 20, 20),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            // Name
                            _buildFieldLabel('👤 नाम *'),
                            const SizedBox(height: 6),
                            TextField(
                              controller: nameController,
                              decoration: const InputDecoration(hintText: 'ग्राहक का नाम'),
                              textCapitalization: TextCapitalization.words,
                            ),
                            const SizedBox(height: 16),
                            // Phone
                            _buildFieldLabel('📱 मोबाइल नंबर'),
                            const SizedBox(height: 6),
                            TextField(
                              controller: phoneController,
                              keyboardType: TextInputType.phone,
                              decoration: const InputDecoration(hintText: '9876543210'),
                            ),
                            const SizedBox(height: 16),
                            // Address
                            _buildFieldLabel('🏠 पता / गाँव (वैकल्पिक)'),
                            const SizedBox(height: 6),
                            TextField(
                              controller: addressController,
                              decoration: const InputDecoration(hintText: 'गाँव या मोहल्ला'),
                            ),
                            const SizedBox(height: 16),
                            // Default quantity
                            _buildFieldLabel('🥛 रोज कितना दूध (लीटर)'),
                            const SizedBox(height: 6),
                            TextField(
                              controller: qtyController,
                              keyboardType: const TextInputType.numberWithOptions(decimal: true),
                              decoration: const InputDecoration(hintText: '5.0'),
                            ),
                            const SizedBox(height: 16),
                            // Rate type
                            _buildFieldLabel('💰 रेट का तरीका'),
                            const SizedBox(height: 8),
                            Row(
                              children: [
                                Expanded(
                                  child: GestureDetector(
                                    onTap: () => setStateSheet(() => rateType = 'flat'),
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(vertical: 14),
                                      decoration: BoxDecoration(
                                        color: rateType == 'flat'
                                            ? DairyTheme.primaryTeal.withOpacity(0.12)
                                            : Colors.grey.shade50,
                                        border: Border.all(
                                          color: rateType == 'flat'
                                              ? DairyTheme.primaryTeal
                                              : Colors.grey.shade300,
                                          width: rateType == 'flat' ? 2 : 1,
                                        ),
                                        borderRadius: BorderRadius.circular(12),
                                      ),
                                      child: Column(
                                        children: [
                                          Icon(
                                            Icons.straighten_rounded,
                                            color: rateType == 'flat' ? DairyTheme.primaryTeal : Colors.grey,
                                          ),
                                          const SizedBox(height: 4),
                                          Text(
                                            'फ्लैट रेट',
                                            style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              color: rateType == 'flat' ? DairyTheme.primaryTeal : Colors.grey[700],
                                            ),
                                          ),
                                          Text(
                                            '₹ प्रति लीटर',
                                            style: TextStyle(fontSize: 11, color: Colors.grey[500]),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: GestureDetector(
                                    onTap: () => setStateSheet(() => rateType = 'fat'),
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(vertical: 14),
                                      decoration: BoxDecoration(
                                        color: rateType == 'fat'
                                            ? DairyTheme.primaryTeal.withOpacity(0.12)
                                            : Colors.grey.shade50,
                                        border: Border.all(
                                          color: rateType == 'fat'
                                              ? DairyTheme.primaryTeal
                                              : Colors.grey.shade300,
                                          width: rateType == 'fat' ? 2 : 1,
                                        ),
                                        borderRadius: BorderRadius.circular(12),
                                      ),
                                      child: Column(
                                        children: [
                                          Icon(
                                            Icons.water_drop_rounded,
                                            color: rateType == 'fat' ? DairyTheme.primaryTeal : Colors.grey,
                                          ),
                                          const SizedBox(height: 4),
                                          Text(
                                            'फैट आधारित',
                                            style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              color: rateType == 'fat' ? DairyTheme.primaryTeal : Colors.grey[700],
                                            ),
                                          ),
                                          Text(
                                            '₹ प्रति फैट पॉइंट',
                                            style: TextStyle(fontSize: 11, color: Colors.grey[500]),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 16),
                            // Rate value
                            if (rateType == 'flat') ...[
                              _buildFieldLabel('₹ प्रति लीटर रेट'),
                              const SizedBox(height: 6),
                              TextField(
                                controller: flatRateController,
                                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                                decoration: const InputDecoration(
                                  hintText: '60',
                                  prefixText: '₹ ',
                                ),
                              ),
                            ] else ...[
                              _buildFieldLabel('₹ प्रति फैट पॉइंट रेट'),
                              const SizedBox(height: 6),
                              TextField(
                                controller: fatRateController,
                                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                                decoration: const InputDecoration(
                                  hintText: '6.8',
                                  prefixText: '₹ ',
                                  helperText: 'उदा: 6.5 फैट × ₹6.8 = ₹44.20/ली',
                                ),
                              ),
                            ],
                            const SizedBox(height: 24),
                            // Save button
                            ElevatedButton.icon(
                              style: ElevatedButton.styleFrom(
                                minimumSize: const Size.fromHeight(56),
                              ),
                              icon: const Icon(Icons.check_circle_rounded),
                              label: Text(
                                isEdit ? 'सुरक्षित करें' : 'ग्राहक जोड़ें',
                                style: const TextStyle(fontSize: 18),
                              ),
                              onPressed: () {
                                final name = nameController.text.trim();
                                if (name.isEmpty) {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                      content: Text('कृपया नाम डालें'),
                                      backgroundColor: Colors.orange,
                                    ),
                                  );
                                  return;
                                }

                                final phone = phoneController.text.trim();
                                final address = addressController.text.trim();
                                final qty = double.tryParse(qtyController.text) ?? 1.0;
                                final flatRate = double.tryParse(flatRateController.text) ?? 0.0;
                                final fatRate = double.tryParse(fatRateController.text) ?? 6.8;

                                final updated = Customer(
                                  id: customer?.id,
                                  name: name,
                                  phone: phone.isEmpty ? null : phone,
                                  address: address.isEmpty ? null : address,
                                  defaultQtyL: qty,
                                  rateType: rateType,
                                  flatRate: flatRate,
                                  ratePerFatPoint: fatRate,
                                );

                                if (isEdit) {
                                  context.read<CustomerCubit>().updateCustomer(updated);
                                } else {
                                  context.read<CustomerCubit>().addCustomer(updated);
                                }
                                Navigator.pop(ctx);
                              },
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildFieldLabel(String text) {
    return Text(
      text,
      style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15),
    );
  }

  void _confirmDeactivate(BuildContext context, Customer customer) {
    showDialog(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          title: Text(AppLocalizations.get(context, 'warning')),
          content: Text('क्या आप सच में ${customer.name} को हटाना चाहते हैं?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: Text(AppLocalizations.get(context, 'no')),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red[700]),
              onPressed: () {
                if (customer.id != null) {
                  context.read<CustomerCubit>().deactivateCustomer(customer.id!);
                }
                Navigator.pop(ctx);
              },
              child: Text(AppLocalizations.get(context, 'yes')),
            ),
          ],
        );
      },
    );
  }
}
