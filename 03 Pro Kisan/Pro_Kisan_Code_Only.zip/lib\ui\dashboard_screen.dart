import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../blocs/app_cubit.dart';
import '../data/india_states.dart';
import '../l10n/app_localizations.dart';
import 'theme/dairy_theme.dart';
import 'pashu/pashu_screen.dart';
import 'khaad/khaad_screen.dart';

/// घर — premium home dashboard.
class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  String _t(BuildContext c, String k) => AppLocalizations.get(c, k);

  static const _hiMonths = [
    '', 'जनवरी', 'फ़रवरी', 'मार्च', 'अप्रैल', 'मई', 'जून',
    'जुलाई', 'अगस्त', 'सितंबर', 'अक्टूबर', 'नवंबर', 'दिसंबर'
  ];

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppCubit>().state;
    final stateName = stateByCode(state.stateCode).hi;
    final now = DateTime.now();
    final dateStr = '${now.day} ${_hiMonths[now.month]} ${now.year}';

    return Scaffold(
      backgroundColor: DairyTheme.creamBg,
      body: CustomScrollView(
        slivers: [
          // Gradient header
          SliverToBoxAdapter(
            child: Container(
              padding: const EdgeInsets.fromLTRB(20, 56, 20, 26),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [DairyTheme.primaryTeal, DairyTheme.secondaryTeal],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.vertical(bottom: Radius.circular(28)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('प्रो किसान',
                          style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w800)),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.18),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Row(
                          children: [
                            const Icon(Icons.location_on, color: Colors.white, size: 15),
                            const SizedBox(width: 3),
                            Text(stateName, style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600)),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 18),
                  Text(_t(context, 'dashGreeting'),
                      style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 4),
                  Text(dateStr, style: TextStyle(color: Colors.white.withValues(alpha: 0.85), fontSize: 14)),
                ],
              ),
            ),
          ),

          SliverPadding(
            padding: EdgeInsets.fromLTRB(16, 22, 16, 24 + MediaQuery.of(context).padding.bottom),
            sliver: SliverList(
              delegate: SliverChildListDelegate([
                _sectionTitle(context, _t(context, 'quickTools')),
                const SizedBox(height: 12),
                Row(
                  children: [
                    _tool(context, _t(context, 'navMilk'), Icons.local_drink_rounded, DairyTheme.milkAccent,
                        () => Navigator.pushNamed(context, '/entry')),
                    const SizedBox(width: 12),
                    _tool(context, _t(context, 'navPashu'), Icons.pets_rounded, DairyTheme.accentBrown,
                        () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PashuScreen()))),
                    const SizedBox(width: 12),
                    _tool(context, _t(context, 'navKheti'), Icons.grass_rounded, DairyTheme.khetiAccent,
                        () => Navigator.push(context, MaterialPageRoute(builder: (_) => const KhaadScreen()))),
                  ],
                ),
                const SizedBox(height: 26),
                _sectionTitle(context, _t(context, 'agriServices')),
                const SizedBox(height: 12),
                Card(
                  child: ListTile(
                    contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                    leading: Container(
                      width: 42,
                      height: 42,
                      decoration: BoxDecoration(color: DairyTheme.amber.withValues(alpha: 0.14), shape: BoxShape.circle),
                      child: const Icon(Icons.wb_sunny_rounded, color: DairyTheme.amber, size: 22),
                    ),
                    title: Text(_t(context, 'moreWeather'), style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
                    trailing: Icon(Icons.chevron_right_rounded, color: Colors.grey.shade400),
                    onTap: () => Navigator.pushNamed(context, '/weather'),
                  ),
                ),
                Card(
                  child: ListTile(
                    contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                    leading: Container(
                      width: 42,
                      height: 42,
                      decoration: BoxDecoration(color: Colors.blue.shade600.withValues(alpha: 0.14), shape: BoxShape.circle),
                      child: Icon(Icons.trending_up_rounded, color: Colors.blue.shade600, size: 22),
                    ),
                    title: Text(_t(context, 'mandiSoon'), style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
                    trailing: Icon(Icons.chevron_right_rounded, color: Colors.grey.shade400),
                    onTap: () => Navigator.pushNamed(context, '/mandi'),
                  ),
                ),
                Card(
                  child: ListTile(
                    contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                    leading: Container(
                      width: 42,
                      height: 42,
                      decoration: BoxDecoration(color: Colors.purple.shade400.withValues(alpha: 0.14), shape: BoxShape.circle),
                      child: Icon(Icons.account_balance_rounded, color: Colors.purple.shade400, size: 22),
                    ),
                    title: Text(_t(context, 'yojanaSoon'), style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
                    trailing: Icon(Icons.chevron_right_rounded, color: Colors.grey.shade400),
                    onTap: () => Navigator.pushNamed(context, '/yojana'),
                  ),
                ),
                Card(
                  child: ListTile(
                    contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                    leading: Container(
                      width: 42,
                      height: 42,
                      decoration: BoxDecoration(color: Colors.teal.shade600.withValues(alpha: 0.14), shape: BoxShape.circle),
                      child: Icon(Icons.article_rounded, color: Colors.teal.shade600, size: 22),
                    ),
                    title: Text(_t(context, 'moreNews'), style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
                    trailing: Icon(Icons.chevron_right_rounded, color: Colors.grey.shade400),
                    onTap: () => Navigator.pushNamed(context, '/news'),
                  ),
                ),
                Card(
                  child: ListTile(
                    contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                    leading: Container(
                      width: 42,
                      height: 42,
                      decoration: BoxDecoration(color: Colors.red.shade600.withValues(alpha: 0.14), shape: BoxShape.circle),
                      child: Icon(Icons.phone_in_talk_rounded, color: Colors.red.shade600, size: 22),
                    ),
                    title: Text(AppLocalizations.get(context, 'dashHelplines'), style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
                    trailing: Icon(Icons.chevron_right_rounded, color: Colors.grey.shade400),
                    onTap: () => Navigator.pushNamed(context, '/helpline'),
                  ),
                ),
              ]),
            ),
          ),
        ],
      ),
    );
  }

  Widget _sectionTitle(BuildContext context, String text) => Text(text,
      style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: DairyTheme.textDark));

  Widget _tool(BuildContext context, String label, IconData icon, Color color, VoidCallback onTap) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Card(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 6),
            child: Column(
              children: [
                Container(
                  width: 54,
                  height: 54,
                  decoration: BoxDecoration(
                    color: color.withValues(alpha: 0.14),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(icon, color: color, size: 28),
                ),
                const SizedBox(height: 10),
                Text(label, textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
