import 'package:flutter/material.dart';
import '../l10n/app_localizations.dart';
import 'settings_screen.dart';

/// और tab — settings + upcoming online sections.
class MoreScreen extends StatelessWidget {
  const MoreScreen({super.key});

  String _t(BuildContext c, String k) => AppLocalizations.get(c, k);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_t(context, 'navMore'))),
      body: ListView(
        children: [
          _tile(context, Icons.settings_rounded, _t(context, 'settings'),
              () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen()))),
          const Divider(height: 1),
          _tile(context, Icons.account_balance_rounded, _t(context, 'moreYojana'),
              () => Navigator.pushNamed(context, '/yojana')),
          _tile(context, Icons.trending_up_rounded, _t(context, 'moreMandi'),
              () => Navigator.pushNamed(context, '/mandi')),
          _tile(context, Icons.article_rounded, _t(context, 'moreNews'),
              () => Navigator.pushNamed(context, '/news')),
          _tile(context, Icons.wb_sunny_rounded, _t(context, 'moreWeather'),
              () => Navigator.pushNamed(context, '/weather')),
          const Divider(height: 1),
          _tile(context, Icons.lightbulb_rounded, _t(context, 'moreSujhav'),
              () => Navigator.pushNamed(context, '/sujhav')),
          _tile(context, Icons.phone_in_talk_rounded, _t(context, 'moreHelpline'),
              () => Navigator.pushNamed(context, '/helpline')),
          _tile(context, Icons.info_rounded, _t(context, 'moreAbout'),
              () => Navigator.pushNamed(context, '/about')),
        ],
      ),
    );
  }

  Widget _tile(BuildContext context, IconData icon, String title, VoidCallback onTap) {
    return ListTile(
      leading: Icon(icon),
      title: Text(title),
      trailing: const Icon(Icons.chevron_right),
      onTap: onTap,
    );
  }
}
