import 'dart:convert';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../db/dao/customer_dao.dart';
import '../db/dao/entry_dao.dart';
import '../db/dao/payment_dao.dart';
import '../db/dao/settings_dao.dart';
import '../db/dairy_database.dart';

class BackupService {
  final CustomerDao _customerDao = CustomerDao();
  final EntryDao _entryDao = EntryDao();
  final PaymentDao _paymentDao = PaymentDao();
  final SettingsDao _settingsDao = SettingsDao();

  static const String _backupVersion = "1.0.0";
  static const String _autobackupFileName = "pro_kisan_autobackup.json";

  /// Generate Backup JSON Payload Map
  Future<Map<String, dynamic>> _generateBackupPayload() async {
    final customers = await _customerDao.getAllCustomers();
    final entries = await _entryDao.getAllEntries();
    final payments = await _paymentDao.getAllPayments();
    final settings = await _settingsDao.getAllSettings();

    return {
      "version": _backupVersion,
      "timestamp": DateTime.now().toIso8601String(),
      "customerCount": customers.length,
      "entryCount": entries.length,
      "customers": customers.map((c) => c.toMap()).toList(),
      "entries": entries.map((e) => e.toMap()).toList(),
      "payments": payments.map((p) => p.toMap()).toList(),
      "settings": settings,
    };
  }

  /// Silent Auto-Save to Public Documents Backup Folder `/Documents/ProKisan_Backups/`
  Future<bool> autoSaveToPublicFolder() async {
    try {
      final payload = await _generateBackupPayload();
      final jsonString = jsonEncode(payload);

      // Save to external documents directory
      Directory? extDir = await getExternalStorageDirectory();
      List<Directory> targetDirs = [];
      
      // Add primary external documents path if available
      if (extDir != null) {
        final docsFolder = Directory('${extDir.path}/ProKisan_Backups');
        if (!await docsFolder.exists()) {
          await docsFolder.create(recursive: true);
        }
        targetDirs.add(docsFolder);
      }

      // Add Android Public Documents path if accessible
      final publicDocs = Directory('/storage/emulated/0/Documents/ProKisan_Backups');
      try {
        if (!await publicDocs.exists()) {
          await publicDocs.create(recursive: true);
        }
        targetDirs.add(publicDocs);
      } catch (_) {}

      for (var dir in targetDirs) {
        final file = File('${dir.path}/$_autobackupFileName');
        await file.writeAsString(jsonString);
      }

      await _settingsDao.setValue('last_auto_backup', DateTime.now().toIso8601String());
      return true;
    } catch (_) {
      return false;
    }
  }

  /// Scan for existing backup file in public documents or external dir
  Future<Map<String, dynamic>?> detectExistingBackup() async {
    try {
      List<String> pathsToSearch = [];
      final publicDocs = Directory('/storage/emulated/0/Documents/ProKisan_Backups/$_autobackupFileName');
      pathsToSearch.add(publicDocs.path);

      Directory? extDir = await getExternalStorageDirectory();
      if (extDir != null) {
        pathsToSearch.add('${extDir.path}/ProKisan_Backups/$_autobackupFileName');
      }

      for (var path in pathsToSearch) {
        final file = File(path);
        if (await file.exists()) {
          final content = await file.readAsString();
          final data = jsonDecode(content) as Map<String, dynamic>;
          if (data.containsKey("version") && data.containsKey("customers")) {
            data['filePath'] = path;
            return data;
          }
        }
      }
    } catch (_) {}
    return null;
  }

  /// 1-Click Restore from Detected Backup Data Payload
  Future<bool> restoreFromDetectedBackup(Map<String, dynamic> data) async {
    try {
      final db = await DairyDatabase.instance.database;

      await db.transaction((txn) async {
        // Clear existing tables
        await txn.delete('entries');
        await txn.delete('payments');
        await txn.delete('customers');
        await txn.delete('settings');

        // Restore Settings
        if (data.containsKey("settings")) {
          final settings = Map<String, dynamic>.from(data["settings"]);
          for (final entry in settings.entries) {
            await txn.insert('settings', {
              'key': entry.key,
              'value': entry.value.toString(),
            });
          }
        }

        // Restore Customers
        if (data.containsKey("customers")) {
          final customersList = List<Map<String, dynamic>>.from(data["customers"]);
          for (final rawCustomer in customersList) {
            await txn.insert('customers', rawCustomer);
          }
        }

        // Restore Entries
        if (data.containsKey("entries")) {
          final entriesList = List<Map<String, dynamic>>.from(data["entries"]);
          for (final rawEntry in entriesList) {
            await txn.insert('entries', rawEntry);
          }
        }

        // Restore Payments
        if (data.containsKey("payments")) {
          final paymentsList = List<Map<String, dynamic>>.from(data["payments"]);
          for (final rawPayment in paymentsList) {
            await txn.insert('payments', rawPayment);
          }
        }
      });
      return true;
    } catch (_) {
      return false;
    }
  }

  /// Exports all data to a JSON string and triggers sharing sheet.
  Future<bool> exportBackup() async {
    try {
      final payload = await _generateBackupPayload();
      final jsonString = jsonEncode(payload);

      final tempDir = await getTemporaryDirectory();
      final file = File('${tempDir.path}/pro_kisan_backup.json');
      await file.writeAsString(jsonString);

      // Also auto-save to public folder on export
      await autoSaveToPublicFolder();

      final result = await Share.shareXFiles(
        [XFile(file.path, mimeType: 'application/json')],
        subject: 'प्रो किसान बहीखाता बैकअप फाइल',
      );
      return result.status == ShareResultStatus.success || result.status == ShareResultStatus.dismissed;
    } catch (e) {
      return false;
    }
  }

  /// Imports database from a selected JSON file.
  Future<String> importBackup() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['json'],
      );

      if (result == null || result.files.single.path == null) {
        return "कोई फाइल चुनी नहीं गई";
      }

      final file = File(result.files.single.path!);
      final content = await file.readAsString();
      final data = jsonDecode(content) as Map<String, dynamic>;

      if (!data.containsKey("version")) {
        return "गलत फाइल प्रारूप (प्रारूप वर्शन नहीं मिला)";
      }

      final success = await restoreFromDetectedBackup(data);
      if (success) {
        return "सफलतापूर्वक डेटा रीस्टोर हो गया!";
      } else {
        return "त्रुटि: रीस्टोर विफल रहा";
      }
    } catch (e) {
      return "त्रुटि: रीस्टोर विफल रहा (${e.toString()})";
    }
  }

  /// Get last backup timestamp string
  Future<String?> getLastBackupTimestamp() async {
    return await _settingsDao.getValue('last_auto_backup');
  }
}
