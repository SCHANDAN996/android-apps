import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'theme/dairy_theme.dart';
import '../l10n/app_localizations.dart';
// ignore_for_file: deprecated_member_use

/// ---------------------------------------------------------------------------
///  मंडी भाव — MSP Comparison + State/District/Mandi Filters
/// ---------------------------------------------------------------------------
class MandiScreen extends StatefulWidget {
  const MandiScreen({super.key});

  @override
  State<MandiScreen> createState() => _MandiScreenState();
}

class _MandiScreenState extends State<MandiScreen> {
  String? _selectedState;
  String? _selectedDistrict;
  String _searchQuery = '';

  String _t(String k) => AppLocalizations.get(context, k);
  bool get _isHi => AppLocalizations.isHindiLike(context);

  // Hindi→English display maps (data logic still keys off the Hindi names).
  static const Map<String, String> _stateEn = {
    'उत्तर प्रदेश': 'Uttar Pradesh', 'मध्य प्रदेश': 'Madhya Pradesh', 'बिहार': 'Bihar',
    'राजस्थान': 'Rajasthan', 'हरियाणा': 'Haryana', 'पंजाब': 'Punjab', 'महाराष्ट्र': 'Maharashtra',
    'पश्चिम बंगाल': 'West Bengal', 'तेलंगाना': 'Telangana', 'आंध्र प्रदेश': 'Andhra Pradesh',
    'कर्नाटक': 'Karnataka', 'तमिलनाडु': 'Tamil Nadu', 'गुजरात': 'Gujarat', 'छत्तीसगढ़': 'Chhattisgarh',
    'झारखंड': 'Jharkhand', 'उत्तराखंड': 'Uttarakhand', 'केरल': 'Kerala', 'ओडिशा': 'Odisha',
    'असम': 'Assam', 'जम्मू और कश्मीर': 'Jammu & Kashmir',
  };
  static const Map<String, String> _cropEn = {
    'गेहूं': 'Wheat', 'धान (Common)': 'Paddy (Common)', 'धान (Grade A)': 'Paddy (Grade A)',
    'मक्का': 'Maize', 'चना': 'Gram', 'सरसों': 'Mustard', 'सोयाबीन': 'Soybean', 'मूंगफली': 'Groundnut',
    'अरहर (तूर)': 'Pigeon Pea (Tur)', 'मसूर': 'Lentil', 'बाजरा': 'Pearl Millet', 'ज्वार': 'Sorghum',
    'जौ': 'Barley', 'मूंग': 'Green Gram', 'उड़द': 'Black Gram', 'आलू': 'Potato', 'प्याज': 'Onion', 'टमाटर': 'Tomato',
    'रागी': 'Ragi', 'तिल': 'Sesame', 'कपास': 'Cotton', 'हल्दी': 'Turmeric', 'अदरक': 'Ginger', 'मिर्च': 'Chilli',
    'पत्ता गोभी': 'Cabbage', 'भिंडी': 'Okra', 'बैंगन': 'Brinjal', 'केला': 'Banana', 'नारियल': 'Coconut',
    'काली मिर्च': 'Black Pepper', 'लहसुन': 'Garlic', 'फूलगोभी': 'Cauliflower', 'मूली': 'Radish', 'गाजर': 'Carrot', 'धनिया': 'Coriander',
  };
  static const Map<String, String> _districtEn = {
    // UP
    'लखनऊ': 'Lucknow', 'कानपुर': 'Kanpur', 'आगरा': 'Agra', 'वाराणसी': 'Varanasi',
    'गोरखपुर': 'Gorakhpur', 'बरेली': 'Bareilly', 'मेरठ': 'Meerut', 'प्रयागराज': 'Prayagraj',
    'अलीगढ़': 'Aligarh', 'झाँसी': 'Jhansi',
    // MP
    'इंदौर': 'Indore', 'भोपाल': 'Bhopal', 'जबलपुर': 'Jabalpur', 'ग्वालियर': 'Gwalior',
    'उज्जैन': 'Ujjain', 'सागर': 'Sagar', 'रीवा': 'Rewa', 'सतना': 'Satna',
    'छिंदवाड़ा': 'Chhindwara', 'रतलाम': 'Ratlam',
    // BR
    'पटना': 'Patna', 'गया': 'Gaya', 'मुजफ्फरपुर': 'Muzaffarpur', 'भागलपुर': 'Bhagalpur',
    'दरभंगा': 'Darbhanga', 'पूर्णिया': 'Purnia', 'सहरसा': 'Saharsa', 'बेगूसराय': 'Begusarai',
    'आरा': 'Ara', 'बिहारशरीफ': 'Bihar Sharif',
    // RJ
    'जयपुर': 'Jaipur', 'जोधपुर': 'Jodhpur', 'कोटा': 'Kota', 'उदयपुर': 'Udaipur',
    'अजमेर': 'Ajmer', 'बीकानेर': 'Bikaner', 'श्रीगंगानगर': 'Sriganganagar', 'अलवर': 'Alwar',
    'भरतपुर': 'Bharatpur', 'सीकर': 'Sikar',
    // HR
    'करनाल': 'Karnal', 'हिसार': 'Hisar', 'सिरसा': 'Sirsa', 'रोहतक': 'Rohtak',
    'पानीपत': 'Panipat', 'अंबाला': 'Ambala', 'कुरुक्षेत्र': 'Kurukshetra', 'जींद': 'Jind',
    'सोनीपत': 'Sonipat', 'फरीदाबाद': 'Faridabad',
    // PB
    'लुधियाना': 'Ludhiana', 'अमृतसर': 'Amritsar', 'पटियाला': 'Patiala', 'जालंधर': 'Jalandhar',
    'बठिंडा': 'Bathinda', 'मोगा': 'Moga', 'होशियारपुर': 'Hoshiarpur', 'पठानकोट': 'Pathankot',
    'गुरदासपुर': 'Gurdaspur', 'संगरूर': 'Sangrur',
    // MH
    'पुणे': 'Pune', 'नागपुर': 'Nagpur', 'नासिक': 'Nashik', 'औरंगाबाद': 'Aurangabad',
    'सोलापुर': 'Solapur', 'कोल्हापुर': 'Kolhapur', 'अमरावती': 'Amravati', 'अकोला': 'Akola',
    'जलगाँव': 'Jalgaon', 'लातूर': 'Latur',
    // WB
    'कोलकाता': 'Kolkata', 'हावड़ा': 'Howrah', 'बर्धमान': 'Bardhaman', 'मेदिनीपुर': 'Medinipur',
    'मुर्शिदाबाद': 'Murshidabad', 'सिलीगुड़ी': 'Siliguri', 'मालदा': 'Malda', 'दार्जिलिंग': 'Darjeeling',
    'हुगली': 'Hooghly', 'कूचबिहार': 'Cooch Behar',
    // TS
    'हैदराबाद': 'Hyderabad', 'वारंगल': 'Warangal', 'करीमनगर': 'Karimnagar', 'खम्मम': 'Khammam',
    'निजामाबाद': 'Nizamabad', 'महबूबनगर': 'Mahabubnagar', 'नलगोंडा': 'Nalgonda', 'आदिलाबाद': 'Adilabad',
    // AP
    'विशाखापत्तनम': 'Visakhapatnam', 'विजयवाड़ा': 'Vijayawada', 'गुंटूर': 'Guntur', 'नेल्लोर': 'Nellore',
    'कुरनूल': 'Kurnool', 'राजमहेंद्रवरम': 'Rajamahendravaram', 'तिरुपति': 'Tirupati', 'कडपा': 'Kadapa',
    // KA
    'बेंगलुरु': 'Bengaluru', 'हुबली-धारवाड़': 'Hubli-Dharwad', 'मैसूर': 'Mysore', 'बेलगाम': 'Belgaum',
    'मंगलौर': 'Mangalore', 'गुलबर्गा': 'Gulbarga', 'दावणगेरे': 'Davanagere', 'शिमोगा': 'Shimoga',
    // TN
    'चेन्नई': 'Chennai', 'कोयंबटूर': 'Coimbatore', 'मदुरै': 'Madurai', 'त्रिची': 'Trichy',
    'सलेम': 'Salem', 'तिरुनेलवेली': 'Tirunelveli', 'वेल्लोर': 'Vellore', 'तंजावुर': 'Thanjavur',
    // GJ
    'अहमदाबाद': 'Ahmedabad', 'सूरत': 'Surat', 'वडोदरा': 'Vadodara', 'राजकोट': 'Rajkot',
    'जामनगर': 'Jamnagar', 'जूनागढ़': 'Junagadh', 'आणंद': 'Anand', 'मेहसाणा': 'Mehsana',
    'भुज': 'Bhuj',
    // CG
    'रायपुर': 'Raipur', 'बिलासपुर': 'Bilaspur', 'दुर्ग': 'Durg', 'भिलाई': 'Bhilai',
    'राजनांदगांव': 'Rajnandgaon', 'कोरबा': 'Korba', 'रायगढ़': 'Raigarh', 'जगदलपुर': 'Jagdalpur',
    // JH
    'रांची': 'Ranchi', 'जमशेदपुर': 'Jamshedpur', 'धनबाद': 'Dhanbad', 'बोकारो': 'Bokaro',
    'हजारीबाग': 'Hazaribagh', 'देवघर': 'Deoghar', 'गिरिडीह': 'Giridih', 'दुमका': 'Dumka',
    // UK
    'देहरादून': 'Dehradun', 'हरिद्वार': 'Haridwar', 'हल्द्वानी': 'Haldwani', 'रुड़की': 'Roorkee',
    'रुद्रपुर': 'Rudrapur', 'काशीपुर': 'Kashipur', 'अल्मोड़ा': 'Almora', 'पिथौरागढ़': 'Pithoragarh',
    // KL
    'तिरुवनंतपुरम': 'Thiruvananthapuram', 'कोच्चि': 'Kochi', 'कोझिकोड': 'Kozhikode', 'त्रिशूर': 'Thrissur',
    'कोल्लम': 'Kollam', 'अलाप्पुझा': 'Alappuzha', 'पलक्कड़': 'Palakkad', 'कन्नूर': 'Kannur',
    // OD
    'भुवनेश्वर': 'Bhubaneswar', 'कटक': 'Cuttack', 'राउरकेला': 'Rourkela', 'संबलेपुर': 'Sambalpur',
    'ब्रह्मपुर': 'Berhampur', 'पुरी': 'Puri', 'बालासोर': 'Balasore', 'भद्रक': 'Bhadrak',
    // AS
    'गुवाहाटी': 'Guwahati', 'डिब्रूगढ़': 'Dibrugarh', 'सिलचर': 'Silchar', 'जोरहाट': 'Jorhat',
    'नागांव': 'Nagaon', 'तिनसुकिया': 'Tinsukia', 'तेजपुर': 'Tezpur', 'धुबरी': 'Dhubri',
    // JK
    'श्रीनगर': 'Srinagar', 'जम्मू': 'Jammu', 'अनंतनाग': 'Anantnag', 'बारामूला': 'Baramulla',
    'कठुआ': 'Kathua', 'सांबा': 'Samba', 'उधमपुर': 'Udhampur', 'पुंछ': 'Poonch',
  };
  String _stateName(String hi) => _isHi ? hi : (_stateEn[hi] ?? hi);
  String _cropName(String hi) => _isHi ? hi : (_cropEn[hi] ?? hi);
  String _districtName(String hi) => _isHi ? hi : (_districtEn[hi] ?? hi);

  // ── MSP Rates 2024-25 (Government of India official) ──────────────────
  static const Map<String, double> mspRates = {
    'गेहूं': 2275,
    'धान (Common)': 2300,
    'धान (Grade A)': 2320,
    'मक्का': 2225,
    'चना': 5440,
    'सरसों': 5650,
    'सोयाबीन': 4892,
    'मूंगफली': 6377,
    'अरहर (तूर)': 7000,
    'मसूर': 6425,
    'बाजरा': 2625,
    'ज्वार': 3371,
    'जौ': 1850,
    'मूंग': 8558,
    'उड़द': 6950,
    'रागी': 4290,
    'तिल': 8300,
    'कपास': 7120,
  };

  // ── State → District mapping ──────────────────────────────────────────
  static const Map<String, List<String>> _stateDistricts = {
    'उत्तर प्रदेश': ['लखनऊ', 'कानपुर', 'आगरा', 'वाराणसी', 'गोरखपुर', 'बरेली', 'मेरठ', 'प्रयागराज', 'अलीगढ़', 'झाँसी'],
    'मध्य प्रदेश': ['इंदौर', 'भोपाल', 'जबलपुर', 'ग्वालियर', 'उज्जैन', 'सागर', 'रीवा', 'सतना', 'छिंदवाड़ा', 'रतलाम'],
    'बिहार': ['पटना', 'गया', 'मुजफ्फरपुर', 'भागलपुर', 'दरभंगा', 'पूर्णिया', 'सहरसा', 'बेगूसराय', 'आरा', 'बिहारशरीफ'],
    'राजस्थान': ['जयपुर', 'जोधपुर', 'कोटा', 'उदयपुर', 'अजमेर', 'बीकानेर', 'श्रीगंगानगर', 'अलवर', 'भरतपुर', 'सीकर'],
    'हरियाणा': ['करनाल', 'हिसार', 'सिरसा', 'रोहतक', 'पानीपत', 'अंबाला', 'कुरुक्षेत्र', 'जींद', 'सोनीपत', 'फरीदाबाद'],
    'पंजाब': ['लुधियाना', 'अमृतसर', 'पटियाला', 'जालंधर', 'बठिंडा', 'मोगा', 'होशियारपुर', 'पठानकोट', 'गुरदासपुर', 'संगरूर'],
    'महाराष्ट्र': ['पुणे', 'नागपुर', 'नासिक', 'औरंगाबाद', 'सोलापुर', 'कोल्हापुर', 'अमरावती', 'अकोला', 'जलगाँव', 'लातूर'],
    'पश्चिम बंगाल': ['कोलकाता', 'हावड़ा', 'बर्धमान', 'मेदिनीपुर', 'मुर्शिदाबाद', 'सिलीगुड़ी', 'मालदा', 'दार्जिलिंग', 'हुगली', 'कूचबिहार'],
    'तेलंगाना': ['हैदराबाद', 'वारंगल', 'करीमनगर', 'खम्मम', 'निजामाबाद', 'महबूबनगर', 'नलगोंडा', 'आदिलाबाद'],
    'आंध्र प्रदेश': ['विशाखापत्तनम', 'विजयवाड़ा', 'गुंटूर', 'नेल्लोर', 'कुरनूल', 'राजमहेंद्रवरम', 'तिरुपति', 'कडपा'],
    'कर्नाटक': ['बेंगलुरु', 'हुबली-धारवाड़', 'मैसूर', 'बेलगाम', 'मंगलौर', 'गुलबर्गा', 'दावणगेरे', 'शिमोगा'],
    'तमिलनाडु': ['चेन्नई', 'कोयंबटूर', 'मदुरै', 'त्रिची', 'सलेम', 'तिरुनेलवेली', 'वेल्लोर', 'तंजावुर'],
    'गुजरात': ['अहमदाबाद', 'सूरत', 'वडोदरा', 'राजकोट', 'जामनगर', 'जूनागढ़', 'आणंद', 'मेहसाणा', 'भुज'],
    'छत्तीसगढ़': ['रायपुर', 'बिलासपुर', 'दुर्ग', 'भिलाई', 'राजनांदगांव', 'कोरबा', 'रायगढ़', 'जगदलपुर'],
    'झारखंड': ['रांची', 'जमशेदपुर', 'धनबाद', 'बोकारो', 'हजारीबाग', 'देवघर', 'गिरिडीह', 'दुमका'],
    'उत्तराखंड': ['देहरादून', 'हरिद्वार', 'हल्द्वानी', 'रुड़की', 'रुद्रपुर', 'काशीपुर', 'अल्मोड़ा', 'पिथौरागढ़'],
    'केरल': ['तिरुवनंतपुरम', 'कोच्चि', 'कोझिकोड', 'त्रिशूर', 'कोल्लम', 'अलाप्पुझा', 'पलक्कड़', 'कन्नूर'],
    'ओडिशा': ['भुवनेश्वर', 'कटक', 'राउरकेला', 'संबलेपुर', 'ब्रह्मपुर', 'पुरी', 'बालासोर', 'भद्रक'],
    'असम': ['गुवाहाटी', 'डिब्रूगढ़', 'सिलचर', 'जोरहाट', 'नागांव', 'तिनसुकिया', 'तेजपुर', 'धुबरी'],
    'जम्मू और कश्मीर': ['श्रीनगर', 'जम्मू', 'अनंतनाग', 'बारामूला', 'कठुआ', 'सांबा', 'उधमपुर', 'पुंछ'],
  };

  // ── Representative Mandi Prices (sample data — refreshed structure) ───
  // In a production app, this would come from data.gov.in API
  late List<_MandiRate> _allRates;

  @override
  void initState() {
    super.initState();
    _allRates = _generateSampleRates();
  }

  List<_MandiRate> _generateSampleRates() {
    // Generate representative rates for major crops across states
    final List<_MandiRate> rates = [];
    final crops = [
      _CropPrice('गेहूं', mspRates['गेहूं'] ?? 2275, [2200, 2350, 2290]),
      _CropPrice('धान (Common)', mspRates['धान (Common)'] ?? 2300, [2250, 2400, 2320]),
      _CropPrice('मक्का', mspRates['मक्का'] ?? 2225, [2100, 2300, 2180]),
      _CropPrice('चना', mspRates['चना'] ?? 5440, [5200, 5800, 5500]),
      _CropPrice('सरसों', mspRates['सरसों'] ?? 5650, [5500, 6200, 5800]),
      _CropPrice('सोयाबीन', mspRates['सोयाबीन'] ?? 4892, [4700, 5100, 4900]),
      _CropPrice('अरहर (तूर)', mspRates['अरहर (तूर)'] ?? 7000, [6800, 7500, 7100]),
      _CropPrice('मसूर', mspRates['मसूर'] ?? 6425, [6200, 6800, 6500]),
      _CropPrice('बाजरा', mspRates['बाजरा'] ?? 2625, [2500, 2750, 2600]),
      _CropPrice('ज्वार', mspRates['ज्वार'] ?? 3371, [3200, 3500, 3350]),
      _CropPrice('जौ', mspRates['जौ'] ?? 1850, [1700, 1950, 1800]),
      _CropPrice('मूंग', mspRates['मूंग'] ?? 8558, [8000, 8900, 8500]),
      _CropPrice('उड़द', mspRates['उड़द'] ?? 6950, [6500, 7200, 6800]),
      _CropPrice('आलू', 0, [800, 1500, 1100]),
      _CropPrice('प्याज', 0, [1200, 2500, 1800]),
      _CropPrice('टमाटर', 0, [600, 2000, 1200]),
      _CropPrice('रागी', mspRates['रागी'] ?? 4290, [4100, 4500, 4300]),
      _CropPrice('तिल', mspRates['तिल'] ?? 8300, [8000, 8600, 8250]),
      _CropPrice('कपास', mspRates['कपास'] ?? 7120, [6800, 7400, 7100]),
      _CropPrice('हल्दी', 0, [6500, 7500, 7000]),
      _CropPrice('अदरक', 0, [4000, 6000, 5000]),
      _CropPrice('मिर्च', 0, [8000, 12000, 10000]),
      _CropPrice('पत्ता गोभी', 0, [800, 1500, 1100]),
      _CropPrice('भिंडी', 0, [1500, 3000, 2200]),
      _CropPrice('बैंगन', 0, [1000, 2000, 1500]),
      _CropPrice('केला', 0, [1500, 2500, 2000]),
      _CropPrice('नारियल', 0, [2000, 3000, 2500]),
      _CropPrice('काली मिर्च', 0, [45000, 55000, 50000]),
      _CropPrice('लहसुन', 0, [8000, 15000, 12000]),
      _CropPrice('फूलगोभी', 0, [1000, 2500, 1800]),
      _CropPrice('मूली', 0, [500, 1200, 800]),
      _CropPrice('गाजर', 0, [800, 1800, 1200]),
      _CropPrice('धनिया', 0, [5000, 8000, 6500]),
    ];

    for (final entry in _stateDistricts.entries) {
      final state = entry.key;
      for (final district in entry.value) {
        for (final crop in crops) {
          // Add slight variance per district
          final hash = (state.hashCode + district.hashCode + crop.name.hashCode).abs();
          final variance = (hash % 200) - 100; // -100 to +100
          rates.add(_MandiRate(
            state: state,
            district: district,
            mandi: '$district ${_isHi ? 'मंडी' : 'Mandi'}',
            commodity: crop.name,
            minPrice: crop.prices[0] + variance,
            maxPrice: crop.prices[1] + variance,
            modalPrice: crop.prices[2] + variance,
            msp: crop.msp,
          ));
        }
      }
    }
    return rates;
  }

  List<_MandiRate> get _filteredRates {
    var list = _allRates;
    if (_selectedState != null) {
      list = list.where((r) => r.state == _selectedState).toList();
    }
    if (_selectedDistrict != null) {
      list = list.where((r) => r.district == _selectedDistrict).toList();
    }
    if (_searchQuery.isNotEmpty) {
      final q = _searchQuery.toLowerCase();
      list = list.where((r) {
        final commodityEng = _cropEn[r.commodity]?.toLowerCase() ?? '';
        final commodityHin = r.commodity.toLowerCase();
        return commodityHin.contains(q) || commodityEng.contains(q);
      }).toList();
    }
    return list;
  }

  List<String> get _availableDistricts {
    if (_selectedState == null) return [];
    return _stateDistricts[_selectedState] ?? [];
  }

  @override
  Widget build(BuildContext context) {
    final filtered = _filteredRates;

    return Scaffold(
      appBar: AppBar(
        title: Text(_t('moreMandi')),
        backgroundColor: Colors.blue.shade800,
        foregroundColor: Colors.white,
      ),
      body: SafeArea(
        child: Column(
          children: [
          // ── Filters ──
          Container(
            color: Colors.blue.shade50,
            padding: const EdgeInsets.all(12),
            child: Column(
              children: [
                // State & District Dropdowns
                Row(
                  children: [
                    Expanded(
                      child: DropdownButtonFormField<String>(
                        value: _selectedState,
                        decoration: InputDecoration(
                          labelText: _t('mandiStateLabel'),
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                          contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                          filled: true,
                          fillColor: Colors.white,
                          isDense: true,
                        ),
                        items: _stateDistricts.keys.map((s) => DropdownMenuItem(value: s, child: Text(_stateName(s), style: const TextStyle(fontSize: 13)))).toList(),
                        onChanged: (v) => setState(() { _selectedState = v; _selectedDistrict = null; }),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: DropdownButtonFormField<String>(
                        value: _selectedDistrict,
                        decoration: InputDecoration(
                          labelText: _t('mandiDistrictLabel'),
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                          contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                          filled: true,
                          fillColor: Colors.white,
                          isDense: true,
                        ),
                        items: _availableDistricts.map((d) => DropdownMenuItem(value: d, child: Text(_districtName(d), style: const TextStyle(fontSize: 13)))).toList(),
                        onChanged: (v) => setState(() { _selectedDistrict = v; }),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                // Crop Search Bar
                TextField(
                  onChanged: (v) => setState(() { _searchQuery = v; }),
                  decoration: InputDecoration(
                    hintText: _t('mandiSearchHint'),
                    hintStyle: const TextStyle(fontSize: 13),
                    prefixIcon: const Icon(Icons.search_rounded, size: 20),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 12),
                    fillColor: Colors.white,
                    filled: true,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                    isDense: true,
                  ),
                ),
              ],
            ),
          ),

          // ── MSP Legend ──
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            color: Colors.grey.shade100,
            child: Row(
              children: [
                Container(width: 10, height: 10, decoration: BoxDecoration(color: Colors.green, borderRadius: BorderRadius.circular(2))),
                const SizedBox(width: 4),
                Text(_t('mspAbove'), style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Colors.green)),
                const SizedBox(width: 16),
                Container(width: 10, height: 10, decoration: BoxDecoration(color: Colors.red, borderRadius: BorderRadius.circular(2))),
                const SizedBox(width: 4),
                Text(_t('mspBelow'), style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Colors.red)),
                const SizedBox(width: 16),
                Container(width: 10, height: 10, decoration: BoxDecoration(color: Colors.grey, borderRadius: BorderRadius.circular(2))),
                const SizedBox(width: 4),
                Text(_t('mspNA'), style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Colors.grey)),
                const Spacer(),
                Text('${filtered.length} ${_t('mandiResults')}', style: TextStyle(fontSize: 11, color: Colors.grey.shade600)),
              ],
            ),
          ),

          // ── Rate Cards ──
          Expanded(
            child: filtered.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.search_off_rounded, size: 64, color: Colors.grey.shade300),
                        const SizedBox(height: 12),
                        Text(_t('mandiNoResult'), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 4),
                        Text(_t('mandiNoResultHint'), style: TextStyle(color: Colors.grey.shade500)),
                      ],
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.all(12),
                    itemCount: filtered.length + 1,
                    itemBuilder: (context, index) {
                      if (index == 0) {
                        return Card(
                          color: Colors.orange.shade50,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                            side: BorderSide(color: Colors.orange.shade200, width: 0.5),
                          ),
                          margin: const EdgeInsets.only(bottom: 10),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                            child: Row(
                              children: [
                                Icon(Icons.info_outline_rounded, color: Colors.orange.shade800, size: 18),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    _t('mandiDisclaimer'),
                                    style: TextStyle(
                                      fontSize: 11,
                                      fontWeight: FontWeight.w600,
                                      color: Colors.orange.shade900,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      }
                      return _buildRateCard(filtered[index - 1]);
                    },
                  ),
          ),
        ],
      ),
      ),
    );
  }

  Widget _buildRateCard(_MandiRate rate) {
    final hasMsp = rate.msp > 0;
    final diff = hasMsp ? rate.modalPrice - rate.msp : 0.0;
    final isAboveMsp = diff >= 0;

    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Top row: Commodity + MSP Badge
            Row(
              children: [
                Expanded(
                  child: Text(
                    _cropName(rate.commodity),
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                  ),
                ),
                if (hasMsp)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: isAboveMsp ? Colors.green.shade50 : Colors.red.shade50,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: isAboveMsp ? Colors.green : Colors.red, width: 0.5),
                    ),
                    child: Text(
                      isAboveMsp
                          ? (_isHi ? '▲ MSP से ₹${diff.abs().toStringAsFixed(0)} ऊपर' : '▲ ₹${diff.abs().toStringAsFixed(0)} above MSP')
                          : (_isHi ? '▼ MSP से ₹${diff.abs().toStringAsFixed(0)} कम ⚠️' : '▼ ₹${diff.abs().toStringAsFixed(0)} below MSP ⚠️'),
                      style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                        color: isAboveMsp ? Colors.green.shade800 : Colors.red.shade800,
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 4),

            // Location
            Text(
              '📍 ${_districtName(rate.district)} ${_isHi ? 'मंडी' : 'Mandi'}, ${_districtName(rate.district)} (${_stateName(rate.state)})',
              style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
            ),
            const Divider(height: 16),

            // Prices Row
            Row(
              children: [
                _priceColumn(_t('pMin'), rate.minPrice, Colors.orange),
                _priceColumn(_t('pMax'), rate.maxPrice, Colors.blue),
                _priceColumn(_t('pModal'), rate.modalPrice, DairyTheme.primaryTeal),
                if (hasMsp)
                  _priceColumn('MSP', rate.msp, Colors.purple),
              ],
            ),

            const SizedBox(height: 8),

            // Share Button
            Align(
              alignment: Alignment.centerRight,
              child: TextButton.icon(
                onPressed: () {
                  final shareMsg = _isHi
                      ? '📊 *मंडी भाव (Pro Kisan)*\n\n'
                        '🌾 *${rate.commodity}*\n'
                        '📍 ${_districtName(rate.district)} मंडी, ${_districtName(rate.district)}\n\n'
                        '💰 न्यूनतम: ₹${rate.minPrice.toStringAsFixed(0)}/क्विंटल\n'
                        '💰 अधिकतम: ₹${rate.maxPrice.toStringAsFixed(0)}/क्विंटल\n'
                        '💰 मॉडल भाव: ₹${rate.modalPrice.toStringAsFixed(0)}/क्विंटल\n'
                        '${hasMsp ? "🏷️ MSP: ₹${rate.msp.toStringAsFixed(0)}/क्विंटल\n" : ""}\n'
                        '📲 *प्रो किसान ऐप* से भेजा गया'
                      : '📊 *Mandi Rates (Pro Kisan)*\n\n'
                        '🌾 *${_cropName(rate.commodity)}*\n'
                        '📍 ${_districtName(rate.district)} Mandi, ${_districtName(rate.district)}\n\n'
                        '💰 Min: ₹${rate.minPrice.toStringAsFixed(0)}/quintal\n'
                        '💰 Max: ₹${rate.maxPrice.toStringAsFixed(0)}/quintal\n'
                        '💰 Modal: ₹${rate.modalPrice.toStringAsFixed(0)}/quintal\n'
                        '${hasMsp ? "🏷️ MSP: ₹${rate.msp.toStringAsFixed(0)}/quintal\n" : ""}\n'
                        '📲 Sent via *Pro Kisan App*';
                  Share.share(shareMsg);
                },
                icon: const Icon(Icons.share_rounded, size: 16, color: Colors.green),
                label: Text(_t('mandiShareBtn'), style: const TextStyle(fontSize: 12, color: Colors.green, fontWeight: FontWeight.bold)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _priceColumn(String label, double price, Color color) {
    return Expanded(
      child: Column(
        children: [
          Text(label, style: TextStyle(fontSize: 10, color: Colors.grey.shade600)),
          const SizedBox(height: 2),
          Text(
            '₹${price.toStringAsFixed(0)}',
            style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: color),
          ),
          Text(_t('perQuintal'), style: TextStyle(fontSize: 9, color: Colors.grey.shade500)),
        ],
      ),
    );
  }
}

// ── Data Models ────────────────────────────────────────────────────────────
class _MandiRate {
  final String state, district, mandi, commodity;
  final double minPrice, maxPrice, modalPrice, msp;

  const _MandiRate({
    required this.state, required this.district, required this.mandi,
    required this.commodity, required this.minPrice, required this.maxPrice,
    required this.modalPrice, required this.msp,
  });
}

class _CropPrice {
  final String name;
  final double msp;
  final List<double> prices; // [min, max, modal]

  const _CropPrice(this.name, this.msp, this.prices);
}
