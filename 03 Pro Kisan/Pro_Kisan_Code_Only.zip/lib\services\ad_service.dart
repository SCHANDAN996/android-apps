import 'package:flutter/material.dart';

/// DIAGNOSTIC STUB — google_mobile_ads temporarily removed to find the launch
/// crash on Vivo Y21. Same public API as before, so the rest of the app keeps
/// compiling; every method is a safe no-op. Ads will be re-added carefully
/// once the app is confirmed to open.
class AdService {
  static final AdService instance = AdService._internal();
  factory AdService() => instance;
  AdService._internal();

  Future<void> init() async {
    // no-op
  }

  Widget getBannerAdWidget() => const SizedBox.shrink();

  void loadInterstitialAd() {
    // no-op
  }

  void showInterstitialAd(VoidCallback onDismissed) {
    onDismissed();
  }
}
