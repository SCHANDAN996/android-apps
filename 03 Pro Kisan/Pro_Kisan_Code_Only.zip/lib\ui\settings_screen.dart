import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../blocs/app_cubit.dart';
import '../../blocs/backup_cubit.dart';
import '../../blocs/entry_cubit.dart';
import '../../blocs/customer_cubit.dart';
import '../../l10n/app_localizations.dart';
import '../../services/notification_service.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  static const Map<String, String> _languages = {
    'hi': 'हिन्दी (Hindi)',
    'en': 'English',
    'bho': 'भोजपुरी (Bhojpuri)',
    'mr': 'मराठी (Marathi)',
    'bn': 'বাংলা (Bengali)',
    'te': 'తెలుగు (Telugu)',
    'ta': 'தமிழ் (Tamil)',
    'gu': 'ગુજરાતી (Gujarati)',
    'kn': 'ಕನ್ನಡ (Kannada)',
    'pa': 'ਪੰਜਾਬੀ (Punjabi)',
  };

  @override
  Widget build(BuildContext context) {
    return MultiBlocListener(
      listeners: [
        BlocListener<BackupCubit, BackupState>(
          listener: (context, state) {
            if (state is BackupSuccess) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text(state.message), backgroundColor: Colors.green),
              );
              // Reload all state if database imported
              if (state.message.contains("रीस्टोर")) {
                context.read<AppCubit>().loadSettings();
                context.read<EntryCubit>().loadHomeData();
                context.read<CustomerCubit>().loadCustomers();
              }
            } else if (state is BackupFailure) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text(state.error), backgroundColor: Colors.red),
              );
            }
          },
        ),
      ],
      child: Scaffold(
        appBar: AppBar(
          title: Text(AppLocalizations.get(context, 'settings')),
        ),
        body: SafeArea(
          child: BlocBuilder<AppCubit, AppState>(
            builder: (context, state) {
              return ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  _buildHeader(context, AppLocalizations.get(context, 'selectMode')),
                  _buildModeTile(context, state),
                  const SizedBox(height: 16),
                  _buildHeader(context, AppLocalizations.get(context, 'rateType')),
                  _buildRateTypeTile(context, state),
                  const SizedBox(height: 16),
                  _buildHeader(context, AppLocalizations.get(context, 'rate')),
                  _buildRateValueFields(context, state),
                  const SizedBox(height: 16),
                  _buildHeader(context, AppLocalizations.get(context, 'language')),
                  _buildLanguageTile(context, state),
                  const SizedBox(height: 16),
                  _buildHeader(context, AppLocalizations.get(context, 'backupRestore')),
                  _buildBackupRestoreTile(context),
                  const SizedBox(height: 16),
                  _buildHeader(context, AppLocalizations.get(context, 'remindHeader')),
                  _buildReminderTile(context, state),
                  const SizedBox(height: 24),
                  _buildMoreAppsSection(context),
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context, String title) {
    return Padding(
      padding: const EdgeInsets.only(left: 8, bottom: 8),
      child: Text(
        title,
        style: Theme.of(context).textTheme.titleMedium?.copyWith(
              color: Theme.of(context).primaryColor,
              fontWeight: FontWeight.bold,
            ),
      ),
    );
  }

  Widget _buildModeTile(BuildContext context, AppState state) {
    final appCubit = context.read<AppCubit>();
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Row(
          children: [
            Expanded(
              child: ListTile(
                title: Text(
                  state.isKisanMode
                      ? AppLocalizations.get(context, 'kisanMode')
                      : AppLocalizations.get(context, 'doodhwalaMode'),
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                subtitle: Text(
                  state.isKisanMode
                      ? AppLocalizations.get(context, 'kisanModeDesc')
                      : AppLocalizations.get(context, 'doodhwalaModeDesc'),
                ),
              ),
            ),
            Switch(
              value: state.isDoodhwalaMode,
              onChanged: (val) {
                _showModeWarning(context, val ? 'doodhwala' : 'kisan', appCubit);
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRateTypeTile(BuildContext context, AppState state) {
    final appCubit = context.read<AppCubit>();
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Row(
          children: [
            Text(
              AppLocalizations.get(context, 'rateType'),
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
            const Spacer(),
            DropdownButton<String>(
              value: state.rateType,
              items: [
                DropdownMenuItem(
                  value: 'flat',
                  child: Text(AppLocalizations.get(context, 'flat')),
                ),
                DropdownMenuItem(
                  value: 'fat',
                  child: Text(AppLocalizations.get(context, 'fatBased')),
                ),
              ],
              onChanged: (val) {
                if (val != null) {
                  appCubit.setRateType(val);
                }
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRateValueFields(BuildContext context, AppState state) {
    final appCubit = context.read<AppCubit>();
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            if (!state.isFatBased)
              TextFormField(
                initialValue: state.flatRate.toString(),
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: InputDecoration(
                  labelText: AppLocalizations.get(context, 'flatRateLabel'),
                  prefixText: '₹ ',
                ),
                onChanged: (val) {
                  final parsed = double.tryParse(val);
                  if (parsed != null && parsed >= 0) {
                    appCubit.setFlatRate(parsed);
                  }
                },
              )
            else
              TextFormField(
                initialValue: state.ratePerFatPoint.toString(),
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: InputDecoration(
                  labelText: AppLocalizations.get(context, 'ratePerFat'),
                  prefixText: '₹ ',
                ),
                onChanged: (val) {
                  final parsed = double.tryParse(val);
                  if (parsed != null && parsed >= 0) {
                    appCubit.setRatePerFatPoint(parsed);
                  }
                },
              ),
            const SizedBox(height: 8),
            Row(
              children: [
                Icon(Icons.info_outline_rounded, size: 16, color: Colors.grey[500]),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    AppLocalizations.get(context, 'rateHint'),
                    style: TextStyle(fontSize: 12, color: Colors.grey[500]),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLanguageTile(BuildContext context, AppState state) {
    return Card(
      child: ListTile(
        leading: Icon(Icons.language_rounded, color: Theme.of(context).primaryColor),
        title: Text(AppLocalizations.get(context, 'language')),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              _languages[state.language] ?? 'English',
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
            const Icon(Icons.arrow_drop_down),
          ],
        ),
        onTap: () {
          _showLanguagePicker(context, state.language);
        },
      ),
    );
  }

  Widget _buildBackupRestoreTile(BuildContext context) {
    final backupCubit = context.read<BackupCubit>();
    final isHi = AppLocalizations.isHindiLike(context);

    return Card(
      child: Column(
        children: [
          // Auto-Backup Safety Card
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Colors.green.shade50,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
            ),
            child: Row(
              children: [
                const Icon(Icons.shield_rounded, color: Colors.green, size: 28),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        AppLocalizations.get(context, 'autoBackupTitle'),
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: Colors.green),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        isHi
                            ? "ऑटो-सेव फोल्डर: Documents/ProKisan_Backups/"
                            : "Auto-Save Folder: Documents/ProKisan_Backups/",
                        style: TextStyle(fontSize: 11, color: Colors.grey.shade700),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const Divider(height: 1),

          // 1-Click Auto Detect Restore Button
          ListTile(
            leading: const Icon(Icons.find_in_page_rounded, color: Colors.teal, size: 24),
            title: Text(
              AppLocalizations.get(context, 'searchBackupBtn'),
              style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.teal),
            ),
            subtitle: Text(
              isHi
                ? "डिवाइस स्टोरेज से 1-क्लिक में पुराना बैकअप रिस्टोर करें"
                : "Restore previous backup from device storage in 1-click",
              style: const TextStyle(fontSize: 12),
            ),
            onTap: () async {
              final ok = await backupCubit.runAutoDetectRestore();
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(
                      ok
                        ? AppLocalizations.get(context, 'restoreSuccessAlert')
                        : AppLocalizations.get(context, 'restoreNotFoundAlert'),
                    ),
                    behavior: SnackBarBehavior.floating,
                  ),
                );
              }
            },
          ),
          const Divider(height: 1),

          // Export Manual JSON
          ListTile(
            leading: const Icon(Icons.share_rounded, color: Colors.blue),
            title: Text(AppLocalizations.get(context, 'backup')),
            subtitle: Text(AppLocalizations.get(context, 'backupSub')),
            onTap: () => backupCubit.runExport(),
          ),
          const Divider(height: 1),

          // Import Manual JSON
          ListTile(
            leading: const Icon(Icons.file_open_rounded, color: Colors.green),
            title: Text(AppLocalizations.get(context, 'restore')),
            subtitle: Text(AppLocalizations.get(context, 'restoreSub')),
            onTap: () => backupCubit.runImport(),
          ),
          const Divider(height: 1),

          // Uninstall Safety Warning Card
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.amber.shade50,
              borderRadius: const BorderRadius.vertical(bottom: Radius.circular(12)),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(Icons.warning_amber_rounded, color: Colors.amber, size: 20),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    AppLocalizations.get(context, 'uninstallSafetyWarning'),
                    style: TextStyle(fontSize: 11, color: Colors.amber.shade900, height: 1.3),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMoreAppsSection(BuildContext context) {
    return Card(
      elevation: 0,
      color: Colors.grey.shade100,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text(
              '${AppLocalizations.get(context, 'appName')} v1.0.0',
              style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.grey),
            ),
            const SizedBox(height: 8),
            Text(
              AppLocalizations.get(context, 'appFooter'),
              style: const TextStyle(color: Colors.grey, fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }

  void _showModeWarning(BuildContext context, String targetMode, AppCubit appCubit) {
    showDialog(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          title: Text(AppLocalizations.get(context, 'warning')),
          content: Text(AppLocalizations.get(context, 'modeChangeWarning')),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: Text(AppLocalizations.get(context, 'no')),
            ),
            ElevatedButton(
              onPressed: () {
                appCubit.setMode(targetMode);
                Navigator.pop(ctx);
              },
              child: Text(AppLocalizations.get(context, 'yes')),
            ),
          ],
        );
      },
    );
  }

  void _showLanguagePicker(BuildContext context, String currentLang) {
    final appCubit = context.read<AppCubit>();
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 48,
                height: 5,
                margin: const EdgeInsets.only(top: 12, bottom: 8),
                decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              Expanded(
                child: ListView(
                  children: _languages.entries.map((entry) {
                    final isSelected = entry.key == currentLang;
                    return ListTile(
                      title: Text(
                        entry.value,
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                          color: isSelected ? Theme.of(context).primaryColor : null,
                        ),
                      ),
                      trailing: isSelected
                          ? Icon(Icons.check_circle_rounded, color: Theme.of(context).primaryColor)
                          : null,
                      onTap: () {
                        appCubit.setLanguage(entry.key);
                        Navigator.pop(ctx);
                      },
                    );
                  }).toList(),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildReminderTile(BuildContext context, AppState state) {
    final appCubit = context.read<AppCubit>();

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          children: [
            // Morning Reminder Row
            ListTile(
              leading: Icon(Icons.wb_sunny_rounded, color: Colors.orange[800]),
              title: Text(
                AppLocalizations.get(context, 'remindMorning'),
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Text(
                state.morningReminderEnabled
                    ? '${AppLocalizations.get(context, 'remindTimeLabel')}: ${state.morningReminderTime}'
                    : AppLocalizations.get(context, 'remindDisabled'),
              ),
              trailing: Switch(
                value: state.morningReminderEnabled,
                onChanged: (val) async {
                  if (val) {
                    final granted = await NotificationService.instance.requestPermissions();
                    if (!granted) {
                      if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(AppLocalizations.get(context, 'remindPermission')),
                            backgroundColor: Colors.orange,
                          ),
                        );
                      }
                      return;
                    }
                  }
                  await appCubit.updateMorningReminder(enabled: val);
                  await NotificationService.instance.scheduleDailyReminders(
                    morningEnabled: val,
                    morningTime: state.morningReminderTime,
                    eveningEnabled: state.eveningReminderEnabled,
                    eveningTime: state.eveningReminderTime,
                  );
                },
              ),
              onTap: state.morningReminderEnabled
                  ? () => _selectReminderTime(context, true, state.morningReminderTime, state)
                  : null,
            ),
            const Divider(),
            // Evening Reminder Row
            ListTile(
              leading: Icon(Icons.nights_stay_rounded, color: Colors.indigo[800]),
              title: Text(
                AppLocalizations.get(context, 'remindEvening'),
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Text(
                state.eveningReminderEnabled
                    ? '${AppLocalizations.get(context, 'remindTimeLabel')}: ${state.eveningReminderTime}'
                    : AppLocalizations.get(context, 'remindDisabled'),
              ),
              trailing: Switch(
                value: state.eveningReminderEnabled,
                onChanged: (val) async {
                  if (val) {
                    final granted = await NotificationService.instance.requestPermissions();
                    if (!granted) {
                      if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(AppLocalizations.get(context, 'remindPermission')),
                            backgroundColor: Colors.orange,
                          ),
                        );
                      }
                      return;
                    }
                  }
                  await appCubit.updateEveningReminder(enabled: val);
                  await NotificationService.instance.scheduleDailyReminders(
                    morningEnabled: state.morningReminderEnabled,
                    morningTime: state.morningReminderTime,
                    eveningEnabled: val,
                    eveningTime: state.eveningReminderTime,
                  );
                },
              ),
              onTap: state.eveningReminderEnabled
                  ? () => _selectReminderTime(context, false, state.eveningReminderTime, state)
                  : null,
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _selectReminderTime(
    BuildContext context,
    bool isMorning,
    String currentTime,
    AppState state,
  ) async {
    final parts = currentTime.split(':');
    final hour = int.tryParse(parts[0]) ?? (isMorning ? 8 : 20);
    final minute = int.tryParse(parts[1]) ?? 30;

    final selectedTime = await showTimePicker(
      context: context,
      initialTime: TimeOfDay(hour: hour, minute: minute),
      helpText: AppLocalizations.get(context, isMorning ? 'remindPickMorning' : 'remindPickEvening'),
    );

    if (selectedTime != null) {
      final hourStr = selectedTime.hour.toString().padLeft(2, '0');
      final minStr = selectedTime.minute.toString().padLeft(2, '0');
      final formattedTime = '$hourStr:$minStr';

      final appCubit = context.read<AppCubit>();
      if (isMorning) {
        await appCubit.updateMorningReminder(time: formattedTime);
        await NotificationService.instance.scheduleDailyReminders(
          morningEnabled: state.morningReminderEnabled,
          morningTime: formattedTime,
          eveningEnabled: state.eveningReminderEnabled,
          eveningTime: state.eveningReminderTime,
        );
      } else {
        await appCubit.updateEveningReminder(time: formattedTime);
        await NotificationService.instance.scheduleDailyReminders(
          morningEnabled: state.morningReminderEnabled,
          morningTime: state.morningReminderTime,
          eveningEnabled: state.eveningReminderEnabled,
          eveningTime: formattedTime,
        );
      }
    }
  }
}
