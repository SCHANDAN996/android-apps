import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:xml/xml.dart' as xml;
import '../db/dao/news_dao.dart';

class NewsService {
  final NewsDao _newsDao = NewsDao();

  static const List<Map<String, String>> _sources = [
    {
      'name': 'Live Hindustan',
      'url': 'https://api.livehindustan.com/feeds/rss/budget/farmers/rssfeed.xml',
    },
    {
      'name': 'Krishi Jagran',
      'url': 'https://hindi.krishijagran.com/feeds/rss/',
    },
    {
      'name': 'Krishi Sewa',
      'url': 'https://www.krishisewa.com/articles.feed?type=rss',
    },
  ];

  /// Fetch all news from multiple RSS feeds, merge, deduplicate, cache, & fallback to SQLite
  Future<List<Map<String, String>>> fetchAllNews() async {
    final List<Map<String, String>> allParsedNews = [];

    // Parallel fetch from all RSS sources
    await Future.wait(_sources.map((src) async {
      try {
        final response = await http
            .get(Uri.parse(src['url']!))
            .timeout(const Duration(seconds: 8));
        if (response.statusCode == 200) {
          final items = _parseRssFeed(response.bodyBytes, src['name']!);
          allParsedNews.addAll(items);
        }
      } catch (_) {
        // Individual feed timeout/fail safe
      }
    }));

    if (allParsedNews.isNotEmpty) {
      // Deduplicate by title/link
      final Map<String, Map<String, String>> uniqueMap = {};
      for (var item in allParsedNews) {
        final key = item['title']?.trim().toLowerCase() ?? item['link'] ?? '';
        if (key.isNotEmpty && !uniqueMap.containsKey(key)) {
          uniqueMap[key] = item;
        }
      }

      final List<Map<String, String>> uniqueList = uniqueMap.values.toList();
      
      // Save fresh news to SQLite cache
      await _newsDao.cacheNews(uniqueList);
      return uniqueList;
    }

    // Fallback: If offline or all HTTP requests fail, load from SQLite cache
    return await _newsDao.getCachedNews();
  }

  /// Parse XML RSS body bytes into news map items
  List<Map<String, String>> _parseRssFeed(List<int> bodyBytes, String sourceName) {
    final List<Map<String, String>> list = [];
    try {
      final decodedBody = utf8.decode(bodyBytes, allowMalformed: true);
      final document = xml.XmlDocument.parse(decodedBody);
      final items = document.findAllElements('item');

      for (var item in items) {
        final title = item.findElements('title').firstOrNull?.innerText ?? '';
        final description = item.findElements('description').firstOrNull?.innerText ?? '';
        final pubDate = item.findElements('pubDate').firstOrNull?.innerText ?? '';
        final link = item.findElements('link').firstOrNull?.innerText ?? '';

        // Extract image url from media:content or enclosure or img in description
        String imageUrl = '';
        final mediaContent = item.findElements('media:content').firstOrNull;
        if (mediaContent != null) {
          imageUrl = mediaContent.getAttribute('url') ?? '';
        }

        if (imageUrl.isEmpty) {
          final enclosure = item.findElements('enclosure').firstOrNull;
          if (enclosure != null && (enclosure.getAttribute('type')?.contains('image') ?? false)) {
            imageUrl = enclosure.getAttribute('url') ?? '';
          }
        }

        if (imageUrl.isEmpty) {
          final imgMatch = RegExp(r'<img[^>]+src="([^">]+)"', caseSensitive: false).firstMatch(description);
          if (imgMatch != null) {
            imageUrl = imgMatch.group(1) ?? '';
          }
        }

        // Clean HTML tags from description
        final cleanDesc = description.replaceAll(RegExp(r'<[^>]*>|&nbsp;'), '').trim();

        if (title.isNotEmpty) {
          final category = _autoTagCategory(title, cleanDesc);
          list.add({
            'title': title,
            'desc': cleanDesc.length > 150 ? '${cleanDesc.substring(0, 150)}...' : cleanDesc,
            'fullDesc': cleanDesc,
            'date': _formatFeedDate(pubDate),
            'link': link,
            'image': imageUrl,
            'source': sourceName,
            'category': category,
          });
        }
      }
    } catch (_) {}
    return list;
  }

  /// Auto categorize news based on title/description keywords
  String _autoTagCategory(String title, String desc) {
    final text = '$title $desc'.toLowerCase();
    if (text.contains('योजना') || text.contains('सब्सिडी') || text.contains('सरकार') || text.contains('scheme') || text.contains('pm-kisan')) {
      return 'schemes';
    }
    if (text.contains('मंडी') || text.contains('भाव') || text.contains('दर') || text.contains('msp') || text.contains('price') || text.contains('बाजार')) {
      return 'mandi_price';
    }
    if (text.contains('मौसम') || text.contains('बारिश') || text.contains('ओला') || text.contains('मौसम') || text.contains('weather') || text.contains('alert')) {
      return 'weather_alert';
    }
    if (text.contains('पशु') || text.contains('गाय') || text.contains('भैंस') || text.contains('दूध') || text.contains('डेयरी') || text.contains('dairy')) {
      return 'livestock_dairy';
    }
    if (text.contains('तकनीक') || text.contains('यंत्र') || text.contains('ड्रोन') || text.contains('ट्रैक्टर') || text.contains('ड्रिप') || text.contains('जैविक')) {
      return 'tech_innovation';
    }
    return 'all';
  }

  String _formatFeedDate(String rawDate) {
    try {
      final parts = rawDate.split(' ');
      if (parts.length >= 4) {
        return "${parts[1]} ${parts[2]} ${parts[3]}";
      }
      return rawDate;
    } catch (_) {
      return rawDate;
    }
  }
}
