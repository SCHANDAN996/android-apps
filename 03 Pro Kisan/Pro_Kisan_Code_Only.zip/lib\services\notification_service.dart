import 'dart:io';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tz;
import 'package:timezone/timezone.dart' as tz;

/// Service to handle local scheduled reminders for milk entries.
class NotificationService {
  static final NotificationService instance = NotificationService._internal();
  factory NotificationService() => instance;
  NotificationService._internal();

  final FlutterLocalNotificationsPlugin _notificationsPlugin =
      FlutterLocalNotificationsPlugin();

  bool _initialized = false;

  /// Initialize local notifications and timezone DB
  Future<void> init() async {
    if (_initialized) return;

    // 1. Initialize timezone database
    tz.initializeTimeZones();
    try {
      tz.setLocalLocation(tz.getLocation('Asia/Kolkata'));
    } catch (_) {}

    // 2. Setup Android and iOS initialization settings
    const AndroidInitializationSettings androidSettings =
        AndroidInitializationSettings('@mipmap/ic_launcher');

    const DarwinInitializationSettings iosSettings = DarwinInitializationSettings(
      requestAlertPermission: false,
      requestBadgePermission: false,
      requestSoundPermission: false,
    );

    const InitializationSettings initSettings = InitializationSettings(
      android: androidSettings,
      iOS: iosSettings,
    );

    // 3. Initialize plugin
    await _notificationsPlugin.initialize(
      initSettings,
      onDidReceiveNotificationResponse: (NotificationResponse details) {
        // Can handle app launch when notification is tapped
      },
    );

    _initialized = true;
  }

  /// Request permissions on Android 13+ and iOS
  Future<bool> requestPermissions() async {
    await init();
    if (Platform.isAndroid) {
      final androidImplementation =
          _notificationsPlugin.resolvePlatformSpecificImplementation<
              AndroidFlutterLocalNotificationsPlugin>();
      if (androidImplementation != null) {
        final granted = await androidImplementation.requestNotificationsPermission();
        return granted ?? false;
      }
    } else if (Platform.isIOS) {
      final iosImplementation =
          _notificationsPlugin.resolvePlatformSpecificImplementation<
              IOSFlutterLocalNotificationsPlugin>();
      if (iosImplementation != null) {
        final granted = await iosImplementation.requestPermissions(
          alert: true,
          badge: true,
          sound: true,
        );
        return granted ?? false;
      }
    }
    return true;
  }

  /// Cancel all scheduled reminders
  Future<void> cancelAllReminders() async {
    await init();
    await _notificationsPlugin.cancel(101); // Morning reminder ID
    await _notificationsPlugin.cancel(102); // Evening reminder ID
  }

  /// Schedule daily notifications at specific times
  Future<void> scheduleDailyReminders({
    required bool morningEnabled,
    required String morningTime, // "HH:mm"
    required bool eveningEnabled,
    required String eveningTime, // "HH:mm"
  }) async {
    await init();
    await cancelAllReminders(); // Clear old scheduled reminders first

    const AndroidNotificationDetails androidDetails = AndroidNotificationDetails(
      'milk_entry_reminder_channel',
      'दूध एंट्री रिमाइंडर',
      channelDescription: 'दूध की सुबह और शाम की एंट्री दर्ज करने की याद दिलाता है।',
      importance: Importance.max,
      priority: Priority.high,
      playSound: true,
    );

    const DarwinNotificationDetails iosDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
    );

    const NotificationDetails platformDetails = NotificationDetails(
      android: androidDetails,
      iOS: iosDetails,
    );

    // Schedule Morning Reminder
    if (morningEnabled) {
      final morningParts = morningTime.split(':');
      final hour = int.tryParse(morningParts[0]) ?? 8;
      final minute = int.tryParse(morningParts[1]) ?? 30;

      await _scheduleDailyNotification(
        id: 101,
        title: '☀️ सुबह के दूध का हिसाब!',
        body: 'आज सुबह के दूध की एंट्री दर्ज करना न भूलें। ऐप खोलें और एंट्री करें।',
        hour: hour,
        minute: minute,
        notificationDetails: platformDetails,
      );
    }

    // Schedule Evening Reminder
    if (eveningEnabled) {
      final eveningParts = eveningTime.split(':');
      final hour = int.tryParse(eveningParts[0]) ?? 20;
      final minute = int.tryParse(eveningParts[1]) ?? 30;

      await _scheduleDailyNotification(
        id: 102,
        title: '🌙 शाम के दूध का हिसाब!',
        body: 'आज शाम के दूध की एंट्री दर्ज करना न भूलें। ऐप खोलें और हिसाब पूरा करें।',
        hour: hour,
        minute: minute,
        notificationDetails: platformDetails,
      );
    }
  }

  /// Helper to schedule a daily recurring notification at a specific hour/minute
  Future<void> _scheduleDailyNotification({
    required int id,
    required String title,
    required String body,
    required int hour,
    required int minute,
    required NotificationDetails notificationDetails,
  }) async {
    final now = tz.TZDateTime.now(tz.local);
    var scheduledDate = tz.TZDateTime(
      tz.local,
      now.year,
      now.month,
      now.day,
      hour,
      minute,
    );

    // If the scheduled time has already passed today, schedule it for tomorrow
    if (scheduledDate.isBefore(now)) {
      scheduledDate = scheduledDate.add(const Duration(days: 1));
    }

    await _notificationsPlugin.zonedSchedule(
      id,
      title,
      body,
      scheduledDate,
      notificationDetails,
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      matchDateTimeComponents: DateTimeComponents.time, // Daily recurring matching time
    );
  }
}
