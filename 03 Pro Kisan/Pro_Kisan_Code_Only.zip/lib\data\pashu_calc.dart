/// Pure cattle-calculation helpers (गाभिन / आहार). No DB, easy to unit-test.

/// Gestation days.
const int kCowGestationDays = 283;
const int kBuffaloGestationDays = 310;
const int kHeatCycleDays = 21;
const int kPregCheckDays = 75;
const int kDryOffBeforeDeliveryDays = 60;

class PashuMilestones {
  final DateTime expectedDelivery;
  final DateTime nextHeat;      // if not conceived, watch this date
  final DateTime pregnancyCheck;
  final DateTime dryOff;

  const PashuMilestones({
    required this.expectedDelivery,
    required this.nextHeat,
    required this.pregnancyCheck,
    required this.dryOff,
  });
}

/// From an AI/service date, compute the full timeline. [isCow] false = buffalo.
PashuMilestones gaabhinMilestones(DateTime aiDate, {required bool isCow}) {
  final gestation = isCow ? kCowGestationDays : kBuffaloGestationDays;
  final delivery = aiDate.add(Duration(days: gestation));
  return PashuMilestones(
    expectedDelivery: delivery,
    nextHeat: aiDate.add(const Duration(days: kHeatCycleDays)),
    pregnancyCheck: aiDate.add(const Duration(days: kPregCheckDays)),
    dryOff: delivery.subtract(const Duration(days: kDryOffBeforeDeliveryDays)),
  );
}

/// Concentrate (दाना) feed in kg/day.
/// Rule of thumb: milk_L / 2.5 + 1.5 (maintenance); +1 kg if in late pregnancy.
double aaharDanaKgPerDay({required double milkLitresPerDay, bool latePregnancy = false}) {
  var dana = (milkLitresPerDay / 2.5) + 1.5;
  if (latePregnancy) dana += 1.0;
  return (dana * 10).round() / 10.0; // one decimal
}
