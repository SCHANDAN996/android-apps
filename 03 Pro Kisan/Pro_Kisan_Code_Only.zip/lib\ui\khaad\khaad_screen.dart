import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../blocs/app_cubit.dart';
import '../../data/crops.dart';
import '../../data/india_states.dart';
import '../../data/land_units.dart';
import '../../l10n/app_localizations.dart';
import '../theme/dairy_theme.dart';

class KhaadScreen extends StatefulWidget {
  const KhaadScreen({super.key});

  @override
  State<KhaadScreen> createState() => _KhaadScreenState();
}

class _KhaadScreenState extends State<KhaadScreen> {
  Crop _crop = kCrops.first;
  final _areaCtrl = TextEditingController();
  String _unit = 'bigha';

  KhaadResult3Tier? _result;
  double _seedKg = 0;
  String _splits = '';

  String _t(String k) => AppLocalizations.get(context, k);
  bool get _isHi => AppLocalizations.isHindiLike(context);

  // Units offered (bigha/katha are state-aware).
  List<Map<String, String>> get _units => [
        {'code': 'bigha', 'label': _t('bigha')},
        {'code': 'katha', 'label': _t('katha')},
        {'code': 'acre', 'label': _t('unitAcre')},
        {'code': 'hectare', 'label': _t('unitHectare')},
        {'code': 'guntha', 'label': _t('unitGuntha')},
        {'code': 'sqm', 'label': _t('unitSqm')},
        {'code': 'sqft', 'label': _t('unitSqft')},
      ];

  @override
  void dispose() {
    _areaCtrl.dispose();
    super.dispose();
  }

  void _calc() {
    final area = double.tryParse(_areaCtrl.text.trim()) ?? 0;
    if (area <= 0) {
      setState(() => _result = null);
      return;
    }
    final stateCode = context.read<AppCubit>().state.stateCode;
    final bighaSqFt = stateByCode(stateCode).bighaSqFt;
    final ha = toHectares(value: area, unitCode: _unit, bighaSqFt: bighaSqFt);

    setState(() {
      _result = computeKhaad3Tier(crop: _crop, areaHa: ha);
      _seedKg = _crop.seedKgHa * ha;
      _splits = _crop.splits(_isHi);
    });
  }

  // Crop emojis mapping
  static const Map<String, String> _cropEmojis = {
    'wheat': '🌾',
    'paddy': '🌾',
    'maize': '🌽',
    'mustard': '🟡',
    'potato': '🥔',
    'gram': '🟤',
    'lentil': '🍲',
    'pigeonpea': '🌱',
    'sugarcane': '🎋',
    'bajra': '🌾',
    'jowar': '🌾',
    'groundnut': '🥜',
    'soybean': '🌿',
    'onion': '🧅',
    'tomato': '🍅',
  };

  void _adjustArea(double delta) {
    final currentVal = double.tryParse(_areaCtrl.text.trim()) ?? 0.0;
    final newVal = (currentVal + delta).clamp(0.0, 999.0);
    setState(() {
      _areaCtrl.text = newVal == 0 ? '' : newVal.toStringAsFixed(1);
    });
    _calc();
  }

  Widget _buildQuickActionBtn(double delta, String label) {
    return Padding(
      padding: const EdgeInsets.only(right: 6),
      child: ActionChip(
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
        label: Text(
          label,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 13,
            color: DairyTheme.primaryTeal,
          ),
        ),
        backgroundColor: Colors.white,
        side: BorderSide(color: DairyTheme.primaryTeal.withOpacity(0.3)),
        onPressed: () => _adjustArea(delta),
      ),
    );
  }

  Widget _buildCropHorizontalSelector() {
    return SizedBox(
      height: 110,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: kCrops.length,
        itemBuilder: (context, index) {
          final crop = kCrops[index];
          final isSelected = crop.id == _crop.id;
          final emoji = _cropEmojis[crop.id] ?? '🌾';

          return GestureDetector(
            onTap: () {
              setState(() {
                _crop = crop;
              });
              _calc();
            },
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              width: 95,
              margin: const EdgeInsets.only(right: 10, top: 4, bottom: 4, left: 2),
              decoration: BoxDecoration(
                color: isSelected ? DairyTheme.primaryTeal.withOpacity(0.08) : Colors.white,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: isSelected ? DairyTheme.primaryTeal : Colors.grey.shade300,
                  width: isSelected ? 2.5 : 1,
                ),
                boxShadow: isSelected
                    ? [
                        BoxShadow(
                          color: DairyTheme.primaryTeal.withOpacity(0.15),
                          blurRadius: 4,
                          offset: const Offset(0, 2),
                        )
                      ]
                    : null,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(emoji, style: const TextStyle(fontSize: 28)),
                  const SizedBox(height: 4),
                  Text(
                    crop.name(_isHi),
                    style: TextStyle(
                      fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
                      fontSize: 14,
                      color: isSelected ? DairyTheme.primaryTeal : Colors.grey[800],
                    ),
                    textAlign: TextAlign.center,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 2),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: isSelected
                          ? DairyTheme.primaryTeal.withOpacity(0.12)
                          : Colors.grey.shade100,
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      crop.seasonName(_isHi),
                      style: TextStyle(
                        fontSize: 10,
                        fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                        color: isSelected ? DairyTheme.primaryTeal : Colors.grey[600],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_t('khaadTitle'))),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
            // Crop selection
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(_t('selectCrop'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                Text(
                  '${_t('khaadChosen')}: ${_crop.name(_isHi)}',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                    color: DairyTheme.primaryTeal,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            _buildCropHorizontalSelector(),
            const SizedBox(height: 20),

            // Land area input
            Card(
              elevation: 1,
              child: Padding(
                padding: const EdgeInsets.all(14.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(_t('landArea'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          flex: 3,
                          child: TextField(
                            controller: _areaCtrl,
                            keyboardType: const TextInputType.numberWithOptions(decimal: true),
                            decoration: const InputDecoration(
                              hintText: '0',
                              contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                            ),
                            onChanged: (_) => _calc(),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          flex: 2,
                          child: DropdownButtonFormField<String>(
                            value: _unit,
                            decoration: const InputDecoration(
                              contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                            ),
                            items: _units
                                .map((u) => DropdownMenuItem(value: u['code'], child: Text(u['label']!)))
                                .toList(),
                            onChanged: (v) {
                              if (v != null) {
                                setState(() => _unit = v);
                                _calc();
                              }
                            },
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    // Quick Action Chips
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: [
                          _buildQuickActionBtn(-1.0, '-1.0'),
                          _buildQuickActionBtn(-0.5, '-0.5'),
                          _buildQuickActionBtn(0.5, '+0.5'),
                          _buildQuickActionBtn(1.0, '+1.0'),
                          _buildQuickActionBtn(5.0, '+5.0'),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              icon: const Icon(Icons.calculate_rounded),
              onPressed: _calc,
              label: Text(_t('calculate')),
            ),

            // Results — 3-tier system
            if (_result != null) ..._buildResult3Tier(),

            const SizedBox(height: 16),
            _disclaimer(_t('khaadDisclaimer')),
          ],
        ),
      ),
      ),
    );
  }

  /// Build the 3-tier result cards with Hindi NPK descriptions
  List<Widget> _buildResult3Tier() {
    final r = _result!;
    final tierColors = [Colors.amber[700]!, DairyTheme.primaryTeal, Colors.red[700]!];
    final tierLabels = [_t('tierLow'), _t('tierRight'), _t('tierHigh')];
    final tierDesc = [_t('tierLowDesc'), _t('tierRightDesc'), _t('tierHighDesc')];
    final tiers = [r.min, r.recommended, r.max];

    return [
      const SizedBox(height: 24),

      // Section title
      Row(
        children: [
          Icon(Icons.science_rounded, size: 20, color: DairyTheme.primaryTeal),
          const SizedBox(width: 8),
          Text(_t('khaadHowMuch'),
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
        ],
      ),
      const SizedBox(height: 4),
      Text(
        _t('khaadHowMuchHint'),
        style: TextStyle(fontSize: 13, color: Colors.grey[600]),
      ),
      const SizedBox(height: 12),

      // 3-tier cards
      for (int i = 0; i < 3; i++) ...[
        _buildTierCard(
          label: tierLabels[i],
          description: tierDesc[i],
          result: tiers[i],
          color: tierColors[i],
          isRecommended: i == 1,
        ),
        if (i < 2) const SizedBox(height: 8),
      ],

      // Seed info (Second)
      if (_seedKg > 0) ...[
        const SizedBox(height: 16),
        Card(
          color: Colors.blue.withOpacity(0.06),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                const Icon(Icons.grain_rounded, color: Colors.brown, size: 22),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(_t('seedAmount'), style: const TextStyle(fontWeight: FontWeight.bold)),
                      const SizedBox(height: 4),
                      Text(
                        '${_seedKg.toStringAsFixed(1)} ${_t('kg')}',
                        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.brown),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ],

      // How to apply (Third)
      const SizedBox(height: 12),
      Card(
        color: DairyTheme.primaryTeal.withOpacity(0.04),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: DairyTheme.primaryTeal.withOpacity(0.12)),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(Icons.calendar_month_rounded, size: 20, color: DairyTheme.primaryTeal),
                  const SizedBox(width: 8),
                  Text(
                    _t('howToApply'),
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              ..._buildSplitSchedule(),
            ],
          ),
        ),
      ),

      const SizedBox(height: 24),

      // NPK explanation cards (Bottom)
      ..._buildNutrientExplanations(),
    ];
  }

  List<Widget> _buildSplitSchedule() {
    final cleanSplits = _splits.trim();
    if (cleanSplits.isEmpty) return const [];

    // Split by full stops '।' or '.'
    final parts = cleanSplits
        .split(RegExp(r'[।.]'))
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty)
        .toList();

    final end = _isHi ? '।' : '.';
    return parts.map((part) {
      String formattedText = part;
      IconData icon = Icons.check_circle_outline_rounded;
      Color iconColor = DairyTheme.primaryTeal;

      if (part.startsWith('N:')) {
        formattedText = _isHi ? part.replaceFirst('N:', '🌿 यूरिया (नाइट्रोजन):') : '🌿 $part';
        icon = Icons.spa_rounded;
        iconColor = Colors.green;
      } else if (part.startsWith('P व K:') || part.startsWith('P & K:')) {
        formattedText = _isHi ? part.replaceFirst('P व K:', '🧪 DAP व पोटाश (DAP & MOP):') : '🧪 $part';
        icon = Icons.science_rounded;
        iconColor = Colors.orange;
      } else if (part.startsWith('P:')) {
        formattedText = _isHi ? part.replaceFirst('P:', '🧪 DAP (फॉस्फोरस):') : '🧪 $part';
        icon = Icons.science_rounded;
        iconColor = Colors.orange;
      } else if (part.startsWith('K:')) {
        formattedText = _isHi ? part.replaceFirst('K:', '🔶 पोटाश (MOP):') : '🔶 $part';
        icon = Icons.grid_goldenratio_rounded;
        iconColor = Colors.red;
      } else if (part.contains('पूरा उर्वरक') || part.toLowerCase().contains('all fertilizer')) {
        icon = Icons.calendar_today_rounded;
        iconColor = Colors.blue;
      }

      return Padding(
        padding: const EdgeInsets.only(bottom: 8.0),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, size: 18, color: iconColor),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                '$formattedText$end',
                style: const TextStyle(
                  fontSize: 14,
                  height: 1.4,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ],
        ),
      );
    }).toList();
  }

  /// NPK explanation cards — simple Hindi for farmers
  List<Widget> _buildNutrientExplanations() {
    return [
      Row(
        children: [
          const Icon(Icons.info_outline_rounded, size: 18, color: DairyTheme.primaryTeal),
          const SizedBox(width: 8),
          Text(_t('whatInFert'),
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        ],
      ),
      const SizedBox(height: 8),
      ...kNutrientInfo.map((info) => Padding(
            padding: const EdgeInsets.only(bottom: 6),
            child: Card(
              elevation: 0,
              color: Colors.grey.shade50,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(info.emoji, style: const TextStyle(fontSize: 22)),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            '${info.name(_isHi)} (${info.symbol})',
                            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            info.desc(_isHi),
                            style: TextStyle(fontSize: 13, color: Colors.grey[700], height: 1.3),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            _isHi ? '✅ ${info.fertilizer} से मिलता है' : '✅ From ${info.fertilizer}',
                            style: TextStyle(fontSize: 12, color: DairyTheme.primaryTeal, fontWeight: FontWeight.w600),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          )),
    ];
  }

  /// Individual tier card (कम/सही/ज्यादा)
  Widget _buildTierCard({
    required String label,
    required String description,
    required KhaadResult result,
    required Color color,
    bool isRecommended = false,
  }) {
    return Card(
      elevation: isRecommended ? 3 : 1,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: isRecommended
            ? BorderSide(color: DairyTheme.primaryTeal, width: 2)
            : BorderSide.none,
      ),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Row(
              children: [
                Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(color: color, shape: BoxShape.circle),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    label,
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 15,
                      color: isRecommended ? DairyTheme.primaryTeal : Colors.grey[800],
                    ),
                  ),
                ),
                if (isRecommended)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: DairyTheme.primaryTeal.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      _t('recommendedBadge'),
                      style: const TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.bold,
                        color: DairyTheme.primaryTeal,
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 2),
            Text(description, style: TextStyle(fontSize: 12, color: Colors.grey[600])),
            const Divider(height: 16),
            // Fertilizer rows
            _fertRow3(_t('ureaFull'), result.ureaKg, result.ureaBags, color),
            const SizedBox(height: 6),
            _fertRow3(_t('dapFull'), result.dapKg, result.dapBags, color),
            const SizedBox(height: 6),
            _fertRow3(_t('mopFull'), result.mopKg, result.mopBags, color),
          ],
        ),
      ),
    );
  }

  Widget _fertRow3(String name, double kg, double bags, Color color) {
    return Row(
      children: [
        Expanded(
          flex: 3,
          child: Text(name, style: const TextStyle(fontSize: 14)),
        ),
        Expanded(
          flex: 2,
          child: Text(
            '${kg.toStringAsFixed(1)} ${_t('kg')}',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: color),
            textAlign: TextAlign.right,
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          flex: 2,
          child: Text(
            '(${bags.toStringAsFixed(1)} ${_t('bags')})',
            style: TextStyle(fontSize: 13, color: Colors.grey[600]),
            textAlign: TextAlign.right,
          ),
        ),
      ],
    );
  }
}

Widget _disclaimer(String text) => Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.amber.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          const Icon(Icons.info_outline, size: 18, color: Colors.orange),
          const SizedBox(width: 8),
          Expanded(child: Text(text, style: const TextStyle(fontSize: 12))),
        ],
      ),
    );
