import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../blocs/app_cubit.dart';
import 'theme/dairy_theme.dart';

/// Loading/router screen. Navigates to onboarding (first run) or the main
/// shell once settings finish loading. Handles the race where settings load
/// BEFORE this widget subscribes (which previously left the app stuck here).
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  bool _navigated = false;

  void _go(AppState state) {
    if (_navigated) return;
    _navigated = true;
    Navigator.pushReplacementNamed(
      context,
      state.isFirstRun ? '/onboarding' : '/shell',
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<AppCubit, AppState>(
      listener: (context, state) {
        if (!state.isLoading) _go(state);
      },
      builder: (context, state) {
        // If loading already finished before we subscribed, navigate next frame.
        if (!state.isLoading && !_navigated) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (mounted) _go(state);
          });
        }
        return Scaffold(
          body: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 110,
                  height: 110,
                  decoration: const BoxDecoration(
                    color: DairyTheme.primaryTeal,
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.agriculture_rounded, size: 64, color: Colors.white),
                ),
                const SizedBox(height: 20),
                const Text('प्रो किसान',
                    style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold, color: DairyTheme.primaryTeal)),
                const SizedBox(height: 24),
                const CircularProgressIndicator(),
              ],
            ),
          ),
        );
      },
    );
  }
}
